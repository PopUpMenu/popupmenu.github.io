﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; 5_8_(3)
; Discretionary Ligatures
; -------------------------------------------
PostMessage, 0x111, 3339, , , ahk_class Photoshop
; -------------------------------------------
#NoTrayIcon
ExitApp
