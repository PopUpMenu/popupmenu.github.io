﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; 4_1_(4)
; Group from Layers...
; -------------------------------------------
PostMessage, 0x111, 2956, , , ahk_class Photoshop
; -------------------------------------------
#NoTrayIcon
ExitApp
