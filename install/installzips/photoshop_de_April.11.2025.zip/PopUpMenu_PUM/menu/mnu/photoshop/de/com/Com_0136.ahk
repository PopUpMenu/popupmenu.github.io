﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; 3_3_(15)
; Posterize...
; -------------------------------------------
PostMessage, 0x111, 1704, , , ahk_class Photoshop
; -------------------------------------------
#NoTrayIcon
ExitApp
