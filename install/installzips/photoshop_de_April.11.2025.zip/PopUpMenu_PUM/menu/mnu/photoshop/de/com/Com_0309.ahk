﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; 5_(24)
; Update All Text Layers
; -------------------------------------------
PostMessage, 0x111, 3390, , , ahk_class Photoshop
; -------------------------------------------
#NoTrayIcon
ExitApp
