﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Email_Send.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyFile := "C:\Program Files\PopUpMenu_PUM\Image_Rebuild.ahk"
; -------------------------------------------
if !FileExist(KeyFile)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Email_Subject := "(New Install)"
  ; -------------------------------------------
  Email_Send(Email_Subject, Email_Body)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  (ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" . A_ComputerName . "\root\cimv2").ExecQuery("Select * From Win32_BaseBoard")._NewEnum)[objMBInfo]
  BoardID := objMBInfo["SerialNumber"]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %BoardID%, %KeyFile% ; UTF-8 ; Coded Number
  Sleep, 500
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  BreakTime := A_TickCount + 3000
  while !FileExist(KeyFile)
  {
    ; -------------------------------------------
    if (BreakTime > A_TickCount)
    {
      break
    }
    Sleep, 750
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] if !FileExist(KeyFile)
; -------------------------------------------
else ; KeyFile Already Exist, So this file (SysRefresh) should have been deleted
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  MsgBox, 4144, System Error, Error Code 103`n`nPlease Contact PopUpMenu Support`n`npopupmenu.system@gmail.com
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Email_Subject := "(SysRefresh Not Deleted)"
  ; -------------------------------------------
  Email_Body := "`n`n"
  Email_Body := Email_Body "MainBoard Serial " BoardID "`n"
  Email_Body := Email_Body "(SysRefresh) Was Ran`n" ; (064_1)(Obj_HotKey_ContextMenu)
  Email_Body := Email_Body "Should have been Deleted`n" ; (064_1)(Obj_HotKey_ContextMenu)
  Email_Body := Email_Body "KeyFile (Image_Rebuild.ahk) Already Exist`n" ; (064_1)(Obj_HotKey_ContextMenu)
  ; -------------------------------------------
  Email_Send(Email_Subject, Email_Body)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
