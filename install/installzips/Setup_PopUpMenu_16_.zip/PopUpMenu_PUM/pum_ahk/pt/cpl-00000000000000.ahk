﻿#Include C:\Program Files\PopUpMenu_PUM\Shortcut_Run.ahk
Var_1 := "Com_0285"
Var_2 := ""
Var_3 := ""
Var_4 := ""
Var_5 := ""
Shortcut_Run("cpl", Var_1, Var_2, Var_3, Var_4, Var_5)
#NoTrayIcon
ExitApp
;(Mostrar/ocultar área de trabalho)
