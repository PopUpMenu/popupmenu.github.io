CdOpenClose.exe cdrom close
