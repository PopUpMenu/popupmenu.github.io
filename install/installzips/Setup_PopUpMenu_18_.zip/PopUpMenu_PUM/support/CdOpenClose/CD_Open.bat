CdOpenClose.exe cdrom open
