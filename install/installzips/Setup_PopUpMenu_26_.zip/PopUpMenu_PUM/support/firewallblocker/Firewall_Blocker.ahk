﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(FilePath) ; > Array
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Menu, Tray, Icon, C:\Program Files\PopUpMenu_PUM\support\firewallblocker\ScriptImage.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
if (A_IsAdmin == 0) ; Always Run As AdMin
{
  ThisScriptFullPath := A_ScriptFullPath
  Run, *RunAs %ThisScriptFullPath%
} ; Always Run As AdMin
else
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Functions
  ; -------------------------------------------
  GetBlockList(BlockKeyWord) ; > (Array_BlockItems)
  {
  	; -------------------------------------------
  	SearchPath := "C:\Users\" A_UserName "\AppData"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	SearchPath := "C:\Users\" A_UserName "\Documents"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	SearchPath := "C:\Windows\SysWOW64\config\systemprofile\AppData"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	SearchPath := "C:\Program Files"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	SearchPath := "C:\Program Files (x86)"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	SearchPath := "C:\ProgramData"
  	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
  	; -------------------------------------------
  	;
  	; -------------------------------------------
  	MiddleScreen := A_ScreenWidth * 0.5
    MiddleScreen := MiddleScreen - 165
  	; -------------------------------------------
  	;
  	; -------------------------------------------
  	ExeCount := 0
  	FileCount := 0
  	; -------------------------------------------
  	for Index, FilePath in Array_FilePath
  	{
		  ; -------------------------------------------
		  Loop, Files, %FilePath%\*.exe, R
		  {
  			; -------------------------------------------
			  FileCount := FileCount + 1
			  ; -------------------------------------------
			  ThisFilePath := A_LoopFileFullPath			
			  ; -------------------------------------------
			  if (InStr(ThisFilePath, BlockKeyWord) > 0)
			  {
  		    ; -------------------------------------------
				  ExeCount := ExeCount + 1
		      ; -------------------------------------------
			    Array_BlockItems := Array_Add(Array_BlockItems, ThisFilePath, "End") ; > ThisArray
			    ; -------------------------------------------
		    }
			  ; -------------------------------------------
			  ;
  	    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	      Msg := Msg "===============================`n"
	      Msg := Msg "Keyword: """ BlockKeyWord """`n"
	      Msg := Msg "Searched | Block Items | Path`n"
		    Msg := Msg FileCount " | " ExeCount  " | " FilePath "`n"
		    Msg := Msg "===============================`n"
			  ; -------------------------------------------
			  CoordMode, ToolTip, Screen
			  ToolTip, %Msg%, %MiddleScreen%, 0
			  Msg := ""
			  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		  } ; Loop, Files, %FilePath%\*.exe, R
	  } ; for Index, FilePath in Array_FilePath
	  ; -------------------------------------------
	  ;
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ; <CHECK> If No Matching FullFilePath Items were fond With (BlockKeyWord)
	  ; -------------------------------------------
	  Length_Array_BlockItems := Array_BlockItems.MaxIndex() ; Highest Length
	  if (Length_Array_BlockItems == 0 or Length_Array_BlockItems == "")
	  {
    	Array_BlockItems := []
  	}
  	; -------------------------------------------
  	; <CHECK> If No Matching FullFilePath Items were fond With (BlockKeyWord)
  	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  	;
  	; -------------------------------------------
  	return Array_BlockItems
  	; -------------------------------------------
  } ; Function (GetBlockList)
  ; -------------------------------------------
  Firewall_Blocker(BlockThisKeyWord) ; > Nothing
  {
  	; -------------------------------------------
  	if (BlockThisKeyWord != "")
  	{
		  ; -------------------------------------------
		  ThisBat     := A_Temp "\Firewall_Blocker_RunBat.bat"
		  ThisBatLink := A_Temp "\Firewall_Blocker_RunBat.lnk"
		  ; -------------------------------------------
		  FileDelete, %ThisBat%
		  FileDelete, %ThisBatLink%
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  ArrayBlockTheseExes := GetBlockList(BlockThisKeyWord) ; > (ArrayBlockTheseExes)
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  Length_ArrayBlockTheseExes := ArrayBlockTheseExes.MaxIndex() ; Highest Length
		  ; -------------------------------------------
		  if (Length_ArrayBlockTheseExes > 0)
		  {
  			; -------------------------------------------
			  RuleNumber := 0
			  for Index, ItemPath in ArrayBlockTheseExes
			  {
  				; -------------------------------------------
				  RuleNumber := RuleNumber + 1
				  ; -------------------------------------------
				  RuleName := "Block " BlockThisKeyWord
				  ;~ RuleName := "Block " BlockThisKeyWord "-" RuleNumber
				  ; -------------------------------------------
				  BatEntry := "netsh advfirewall firewall add rule name=""" RuleName """ dir=out action=block program=""" ItemPath """"
				  Array_BatEntry := Array_Add(Array_BatEntry, BatEntry, "End") ; > ThisArray
			  }
			  ; -------------------------------------------
			  ;
        ; -------------------------------------------
        FileEncoding, UTF-8
        ; -------------------------------------------
        file := FileOpen(ThisBat, "w")
        ; -------------------------------------------
        for Index, ThisLine in Array_BatEntry
        {
          ; -------------------------------------------
				  ThisLine := ThisLine "`n"
          file.Write(ThisLine)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        file.Close()
        ; -------------------------------------------
        Sleep, 500
  	    ; -------------------------------------------
	      MiddleScreen := A_ScreenWidth * 0.5
        MiddleScreen := MiddleScreen - 165
			  ; -------------------------------------------
			  if FileExist(ThisBat)
			  {
  				; -------------------------------------------
				  Msg := Msg "=========================`n"
				  Msg := Msg "Blocking " Length_ArrayBlockTheseExes " Files in Firewall`n"
				  Msg := Msg "=========================`n"
				  CoordMode, ToolTip, Screen
				  ToolTip, %Msg%, %MiddleScreen%, 0
				  Msg := ""
	        FileCreateShortcut, %ThisBat%, %ThisBatLink%
	        Sleep, 100
	        ; -------------------------------------------
	        Run %ThisBatLink% , , Hide
	        Sleep, 1000
	        ; -------------------------------------------
			  } ; if FileExist(ThisBat)
			  else ; Error
			  {
  				; -------------------------------------------
				  Msg := Msg "Error`n"
				  Msg := Msg "Bat File was Not created`n"
				  Msg := Msg ThisBat "`n"
				  MsgBox, 4096, , %Msg%
				  Msg := ""
				  ; -------------------------------------------
			  } ; Error
		  } ; if (Length_ArrayBlockTheseExes > 0)
	  } ; if (ArrayKeyWord != "")
  } ; Function (Firewall_Blocker)
  ; -------------------------------------------
  ; Functions
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  ColorG := "26bd08" ; Green Color
  ColorR := "bd0808" ; Red Color
  ColorY := "edb00a" ; Yellow Color
  ColorB := "333f82" ; Blue Color
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Gui
  ; -------------------------------------------
  Gui, Font, c000000 s8 w700, arial
  Gui, Add, Text, , Enter Keyword to Block in Firewall:
  ; -------------------------------------------
  Gui, Font, c000000 s10 w700, arial
  Gui, Add, Edit, w205 vGui_Edit_KeyWord
  ; -------------------------------------------
  Gui, Font, c000000 s9 w700, arial
  Gui, Add, Text, x15 y68 vGui_Text_1, Block ALL Exe's with this Keyword
  ; -------------------------------------------
  Gui, Font, c000000 s12 w700, arial
  Gui, Add, Text, x45 y88 vGui_Text_2, CLICK OK To Start
  Gui, Add, Button, x10 y120 w80 h30 w80 vGui_Button_OK gLabel_Button_OK, OK
  Gui, Add, Button, x135 y120 w80 h30 w80 vGui_Button_Cancel gLabel_Button_Cancel, CANCEL
  ; -------------------------------------------
  GuiControl, Focus, Gui_Edit_KeyWord
  ; -------------------------------------------
  GuiControl, +c%ColorR%, Gui_Text_1
  GuiControl, +c%ColorR%, Gui_Text_2
  ; -------------------------------------------
  Gui, Show, w225 h170, Firewall Blocker
  ; -------------------------------------------
  return
  ; -------------------------------------------
  ; Gui
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Labels
  ; -------------------------------------------
  GuiClose:
  {
  	ExitApp
  }
  return
  ; -------------------------------------------
  Label_Button_OK:
  {
  	; -------------------------------------------
  	Gui, Submit ; Closes the Gui
  	; -------------------------------------------
  	GuiControlGet, KeyWord, , Gui_Edit_KeyWord
  	; -------------------------------------------
  	if (StrLen(KeyWord) > 0)
  	{
		  ; -------------------------------------------
		  Firewall_Blocker(KeyWord) ; KeyWord Item to Search for
		  ; -------------------------------------------
		  Sleep, 1000
		  ExitApp
		  ; -------------------------------------------
	  }
	  else
	  {
  		; -------------------------------------------
		  Msg := Msg "Nothing Was Entered as a Keyword`n"
		  MsgBox, 48, , %Msg%, 2
		  Msg := ""
		  ExitApp
		  ; -------------------------------------------
	  }
  }
  return
  ; -------------------------------------------
  Label_Button_CANCEL:
  {
    ExitApp
  }
  return
  ; -------------------------------------------
  ; Labels
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Hot Key
  ; -------------------------------------------
  Esc::
  {
  	ExitApp
  }
  return
  ; -------------------------------------------
  ; Hot Key
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
1. Blocking an IP Address:
Command: netsh advfirewall firewall add rule name="Block IP" dir=in action=block remoteip=<ip_to_block>/32
name="Block IP": Sets the name of the rule.
dir=in: Specifies the direction as inbound.
action=block: Specifies the action as blocking.
remoteip=<ip_to_block>/32: Specifies the IP address to block (e.g., 192.168.1.100/32). The /32 indicates a single IP address. 
*/
/*
2. Blocking a Port:
Command: netsh advfirewall firewall add rule name="Block Port" dir=in action=block protocol=TCP remoteport=<port_number>
name="Block Port": Sets the name of the rule.
dir=in: Specifies the direction as inbound.
action=block: Specifies the action as blocking.
protocol=TCP: Specifies the protocol (e.g., TCP or UDP).
remoteport=<port_number>: Specifies the port number to block (e.g., 80). 
*/
/*
3. Blocking Outbound Traffic for a Program:
Command: netsh advfirewall firewall add rule name="Block Program" dir=out action=block program="C:\path\to\program.exe"
name="Block Program": Sets the name of the rule.
dir=out: Specifies the direction as outbound.
action=block: Specifies the action as blocking.
program="C:\path\to\program.exe": Specifies the program to block (e.g., C:\Windows\System32\cmd.exe). 
*/
/*
4. Blocking Inbound Traffic for a Program:
Command: netsh advfirewall firewall add rule name="Block Program" dir=in action=block program="C:\path\to\program.exe"
name="Block Program": Sets the name of the rule.
dir=in: Specifies the direction as inbound.
action=block: Specifies the action as blocking.
program="C:\path\to\program.exe": Specifies the program to block (e.g., C:\Windows\System32\cmd.exe). 
Example: Blocking ICMP Inbound Traffic
Command: netsh advfirewall firewall add rule name="Block ICMP Inbound" protocol=icmpv4:8,any dir=in action=block
name="Block ICMP Inbound": Sets the name of the rule.
protocol=icmpv4:8,any: Specifies the ICMP protocol for IPv4 and the type (8 is echo request).
dir=in: Specifies the direction as inbound.
action=block: Specifies the action as blocking.
*/
