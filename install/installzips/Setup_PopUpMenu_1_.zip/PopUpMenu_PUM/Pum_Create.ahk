﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Convert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_PumBgPng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Create(DataArray) ; > DataArray
{
  ; -------------------------------------------
  AppProcessPathNameExt := DataArray.367.5 ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; [Application Exist]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Application Exist]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CLOSE] Gui, [CLOSE] pum
    ; -------------------------------------------
    GuiExist := WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
    ; -------------------------------------------
    if (GuiExist != "0x0")
    {
      DataArray := Pum_Close(DataArray) ; [CLOSE] Gui
    }
    ; -------------------------------------------
    DataArray := Pum_Close(DataArray) ; [CLOSE] Pum
    ; -------------------------------------------
    ; [CLOSE] Gui, [CLOSE] pum
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("Off", 0) ; (Just Before) (Run) PopUpMenu Working Gear
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
    Run, %ScriptPath%
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (367)(01)(AppProcessName [Name][LowerCase][NoSpace])
    if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Application Exist]
      ;
      ; [Internet Browser Application] [ACTIVE]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Application Exist]
        ; [Internet Browser Application] [ACTIVE]
        ;
        ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; VARS ThisPumProcessPath
        ; -------------------------------------------
        UseCommonBrowser := DataArray.290.2
        AppProcessPathNameExt := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
        ; -------------------------------------------
        ThisPumProcessExe := "pum_pumcommonbrowser.exe"
        ; -------------------------------------------
        ThisPumProcessName := "pumcommonbrowser"
        AppProcessName := "pumcommonbrowser"
        ; -------------------------------------------
        ThisPumProcessFolder         := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser"
        ThisPumProcessPath           := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
        ThisPumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\settings"
        ThisPumProcessXml            := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\settings\toolbox0.xml"
        ThisPumProcessIconCache      := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pumiconcache"
        ; -------------------------------------------
        ExeIconIco := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_ExeIconIco.ico"
        ; -------------------------------------------
        UseCommonBrowser := 1
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        FileRunPng := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        ; VARS ThisPumProcessPath
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; -------------------------------------------
      else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Application Exist]
        ; [Internet Browser Application] [ACTIVE]
        ;
        ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; VARS ThisPumProcessPath
        ; -------------------------------------------
        SplitPath, AppProcessPathNameExt, , , , AppProcessName
        StringLower, AppProcessName, AppProcessName
        AppProcessName := StrReplace(AppProcessName, A_Space, "")
        ; -------------------------------------------
        DataArray.367.1 := AppProcessName ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        ; -------------------------------------------
        ThisPumProcessExe := "pum_" AppProcessName ".exe"
        ; -------------------------------------------
        ThisPumProcessName := ThisPumProcessExe
        ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
        ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
        ; -------------------------------------------
        ThisPumProcessFolder         := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
        ThisPumProcessPath           := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\" ThisPumProcessExe
        ThisPumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings"
        ThisPumProcessXml            := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
        ThisPumProcessIconCache      := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache"
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ArrayIn    := [AppProcessPathNameExt, AppProcessName, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
        ArrayOut   := Image_PathFolderOrName(ArrayIn)
        FileRunPng := ArrayOut.1
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ; -------------------------------------------
        if !FileExist(FileRunPng)
        {
          ; -------------------------------------------
          ArrayIn := [AppProcessPathNameExt, AppProcessName, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          FileRunPng := Img_RunPng(ArrayIn)
          ; -------------------------------------------
        } ; [End] if !FileExist(FileRunPng)
        ; -------------------------------------------
        ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        ; VARS ThisPumProcessPath
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; -------------------------------------------
    } ; [Internet Browser Application] [ACTIVE]
    ; -------------------------------------------
    else ; [Any Other Application] (Non-Internet Browser) [ACTIVE]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Application Exist]
      ;
      ; [Any Other Application] (Non-Internet Browser) [ACTIVE]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; VARS ThisPumProcessPath
      ; -------------------------------------------
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
      StringLower, AppProcessName, AppProcessName
      AppProcessName := StrReplace(AppProcessName, A_Space, "")
      ; -------------------------------------------
      DataArray.367.1 := AppProcessName ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      ; -------------------------------------------
      ThisPumProcessExe := "pum_" AppProcessName ".exe"
      ; -------------------------------------------
      ThisPumProcessName := ThisPumProcessExe
      ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
      ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
      ; -------------------------------------------
      ThisPumProcessFolder         := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
      ThisPumProcessPath           := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\" ThisPumProcessExe
      ThisPumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings"
      ThisPumProcessXml            := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
      ThisPumProcessIconCache      := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ArrayIn    := [AppProcessPathNameExt, AppProcessName, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; -------------------------------------------
      if !FileExist(FileRunPng)
      {
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, AppProcessName, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        FileRunPng := Img_RunPng(ArrayIn)
        ; -------------------------------------------
      } ; [End] if !FileExist(FileRunPng)
      ; -------------------------------------------
      ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      ; VARS ThisPumProcessPath
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [Any Other Application] (Non-Internet Browser) [ACTIVE]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Check\Create [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName]
    ; -------------------------------------------
    if !FileExist(ThisPumProcessFolder)
    {
      FileCreateDir, %ThisPumProcessFolder%
      Sleep, 10
    } ; [End] if !FileExist(ThisPumProcessFolder)
    ; -------------------------------------------
    ; Check\Create [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [COPY] Pum Model Folder
    ; -------------------------------------------
    PumModelFolder := "C:\Program Files\PopUpMenu_PUM\pum_app"
    FileCopyDir, %PumModelFolder%, %ThisPumProcessFolder%, 1
    Sleep, 10
    ; -------------------------------------------
    ; [COPY] Pum Model Folder
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [COPY] Language Spicific Script (ahk) to [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName]
    ; -------------------------------------------
    UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    Pum_Ahk_Temp := "C:\Program Files\PopUpMenu_PUM\pum_ahk\" UserLang "\cpl-00000000000000.ahk"
    Pum_Ahk_Lang := ThisPumProcessFolder "\ahk\cpl-00000000000000.ahk"
    FileCopy, %Pum_Ahk_Temp%, %Pum_Ahk_Lang%, 1
    Sleep, 10
    ; -------------------------------------------
    ; [COPY] Language Spicific Script (ahk) to [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    TempFolder := A_AppData "\PopUpMenu_PUM\temp"
    ; -------------------------------------------
    if !FileExist(TempFolder)
    {
      FileCreateDir, %TempFolder%
      Sleep, 10
    } ; [End] if !FileExist(TempFolder)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\RunPngTemp.png"]
    ; -------------------------------------------
    RunPngTemp := A_AppData "\PopUpMenu_PUM\temp\RunPngTemp.png" ; w48 h48
    ; -------------------------------------------
    if FileExist(RunPngTemp)
    {
      FileDelete, %RunPngTemp%
    }
    ; -------------------------------------------
    Image_ResizePng(48, 48, FileRunPng, RunPngTemp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\RunPngTemp.png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [RESIZE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileDel254.png"]
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
    ; -------------------------------------------
    FileDel254 := "C:\Program Files\PopUpMenu_PUM\image\ico\FileDel254.png"
    Del254Temp := A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png" ; w80 h80
    ; -------------------------------------------
    if FileExist(Del254Temp)
    {
      FileDelete, %Del254Temp%
    }
    ; -------------------------------------------
    Image_ResizePng(80, 80, FileDel254, Del254Temp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    ; [RESIZE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileDel254.png"]
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"]
    ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileDel254.png"]
    ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\ExeIconTemp.png"]
    ; -------------------------------------------
    ExeIconPng := A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"
    ; -------------------------------------------
    I1 := Del254Temp ; w73 h73
    X1 := 0 ; X Position (Left)
    Y1 := 0 ; Y Postion (Down)
    ;
    I2 := RunPngTemp ; w73 h73
    X2 := 16 ; X Position (Left)
    Y2 := 26 ; Y Postion (Down)
    ; -------------------------------------------
    Image_Array := [80, 80, ExeIconPng, I1, X1, Y1, I2, X2, Y2]
    Image_Combine(Image_Array)
    ; -------------------------------------------
    ExeIconIco := A_AppData "\PopUpMenu_PUM\temp\ExeIcon.ico"
    Image_ImgToIco(ExeIconPng, ExeIconIco) ; (ImageIn, ImageOut, RunAnimate) > ImageOut
    ; -------------------------------------------
    ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"]
    ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileDel254.png"]
    ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\ExeIconTemp.png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHANGE] [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum.exe"] Icon
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"]
    ; -------------------------------------------
    Support_ResourceHacker := "C:\Program Files\PopUpMenu_PUM\support\resourcehacker\PopUpMenu_ResourceHacker.exe"
    ExeFile_In             := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum.exe"
    ThisPumProcessPath     := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
    ; -------------------------------------------
    if !FileExist(ThisPumProcessPath)
    {
      CopyFromHere := "C:\Program Files\PopUpMenu_PUM\pum_app\pum.exe"
      FileCopy, %CopyFromHere%, %ThisPumProcessPath%, 1
    }
    ; ------------------------------------------
    RunThis := Support_ResourceHacker " -open """ ExeFile_In """ -save """ ThisPumProcessPath """ -action addoverwrite -res """ ExeIconIco """ -mask ICONGROUP`, MAINICON`,"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ResourceHacker.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    ; [CHANGE] [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum.exe"] Icon
    ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [DELETE] Temp Files
    ; -------------------------------------------
    FileDelete, %ExeFile_In%  ; [A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum.exe"]
    FileDelete, %RunPngTemp% ; [A_AppData "\PopUpMenu_PUM\temp\RunPngTemp.png"]
    FileDelete, %Del254Temp% ; [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
    FileDelete, %ExeIconPng%    ; [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.png"]
    FileDelete, %ExeIconIco%    ; [A_AppData "\PopUpMenu_PUM\temp\ExeIcon.ico"]
    ; -------------------------------------------
    ; [DELETE] Temp Files
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] ThisPumProcessXml
    ; -------------------------------------------
    ; Pum Xml to Array (ThisPumProcessArray)
    ; -------------------------------------------
    ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\settings\toolbox0.xml"
    ; -------------------------------------------
    ThisPumProcessArray := Array_FromFile(ThisPumProcessXml) ; > Array
    ; -------------------------------------------
    ; [SET] ThisPumProcessXml
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [XML Line Strings] from (ThisPumProcessArray)
    ; -------------------------------------------
    XmlLine3  := ThisPumProcessArray.3
    XmlLine9  := ThisPumProcessArray.9
    ; -------------------------------------------
    ; [XML Line Strings] from (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [PumTotalRY]
    ; -------------------------------------------
    FindItem := "rows"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    PumTotalRY := ThisVar
    ; -------------------------------------------
    ; [PumTotalRY]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [PumTotalCX]
    ; -------------------------------------------
    FindItem := "columns"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    PumTotalCX := ThisVar
    ; -------------------------------------------
    ; [PumTotalCX]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [XmlIconSize]
    ; -------------------------------------------
    FindItem := "iconsize"
    XmlString := XmlLine9 ; <displaymode type="0" iconsize="48" />
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlIconSize := ThisVar
    ; -------------------------------------------
    ; [XmlIconSize]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [Center Pum on Screen]
    ; Set (PumWindowsPosX)(PumWindowsPosY)
    ; -------------------------------------------
    PumTotalW  := PumTotalCX * XmlIconSize
    PumTotalH := PumTotalRY * XmlIconSize
    ; -------------------------------------------
    PumWindowsPosX := Round((A_ScreenWidth - PumTotalW) / 2)
    PumWindowsPosY := Round((A_ScreenHeight - PumTotalH) / 2)
    ; -------------------------------------------
    ; [Center Pum on Screen]
    ; Set (PumWindowsPosX)(PumWindowsPosY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [UPDATE] (ThisPumProcessArray)
    ; -------------------------------------------
    XML_Line_3 := "<toolbox name="""" rows=""" PumTotalRY """ columns=""" PumTotalCX """ left=""" PumWindowsPosX  """ top=""" PumWindowsPosY  """ stayontop=""-1"" >"
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(3)
    ThisPumProcessArray.InsertAt(3, XML_Line_3)
    ; -------------------------------------------
    ; [UPDATE] (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    
    
    
    
    
    
    
    
    
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CREATE] pum Background Image (Applications's EXE Image and Black Background)
    ; -------------------------------------------
    ArrayIn := [AppProcessPathNameExt, AppProcessName, DataArray.290.2, DataArray.365.2, DataArray.363.12]
    bg_Selected_Bmp := Img_PumBgPng(ArrayIn)
    ; -------------------------------------------
		;
    ; -------------------------------------------
		SplitPath, bg_Selected_Bmp, SelectedImage_FileNameExt, SelectedImage_Folder, SelectedImage_Ext, SelectedImage_FileName
    ; -------------------------------------------
    bg_Selected_img := SelectedImage_Folder "\bg_Selected_img.bmp" ; BMP
    FileCopy, %bg_Selected_Bmp%, %bg_Selected_img%, 1
    ; -------------------------------------------
    bg_Selected_Fit := SelectedImage_Folder "\bg_Selected_Fit.png" ; PNG
    bg_Selected_Fit := Image_Convert(bg_Selected_Bmp, bg_Selected_Fit) ; Image_In, Image_Out > Image_Out
    ; -------------------------------------------
    bg_Selected_Gui := SelectedImage_Folder "\bg_Selected_Gui.png" ; PNG
    FileCopy, %bg_Selected_Fit%, %bg_Selected_Gui%, 1
    ; -------------------------------------------
    bg_Display_Img := SelectedImage_Folder "\bg_Display_Img.png" ; PNG
    File_PumFrame := "C:\Program Files\PopUpMenu_PUM\image\pum\PumFrame.png"
    ; -------------------------------------------
    Temp_PumFrame :=  SelectedImage_Folder "\Temp_PumFrame.png"
    Temp_Display_Img := SelectedImage_Folder "\Temp_Display_Img.png" ; PNG
    ; -------------------------------------------
    Image_ResizePng(300, 240, File_PumFrame, Temp_PumFrame) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    Image_ResizePng(300, 240, bg_Selected_Gui, Temp_Display_Img) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    Image_Array := [300, 300, bg_Display_Img, Temp_Display_Img, 0, 30, Temp_PumFrame, 0, 30]
    Image_Combine(Image_Array) ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Image_X, Image_Y,) etc]
    ; -------------------------------------------
    Source_Info_bg := "C:\Program Files\PopUpMenu_PUM\image\pum\Info_bg.txt"
    File_Info_bg := SelectedImage_Folder "\Info_bg.txt"
    FileCopy, %Source_Info_bg%, %File_Info_bg%
    ; -------------------------------------------
    FileDelete, %Temp_PumFrame%
    FileDelete, %Temp_Display_Img%
		; -------------------------------------------
    ; [CREATE] pum Background Image (Applications's EXE Image and Black Background)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [UPDATE] (ThisPumProcessArray)
    ; -------------------------------------------
    XmlBgColor   := 0
    XmlBgType    := 1
    XmlBgOpacity := 100
    ; -------------------------------------------
    XML_Line_19 := "  <background color=""" XmlBgColor """ type=""" XmlBgType """ effect=""0"" opacity=""" XmlBgOpacity """ >"
    XML_Line_20 := "    <filename>" bg_Selected_Bmp "</filename>"
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(19)
    ThisPumProcessArray.InsertAt(19, XML_Line_19)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(20)
    ThisPumProcessArray.InsertAt(20, XML_Line_20)
    ; -------------------------------------------
    ; [UPDATE] (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [DELETE] Old (toolbox)
    ; -------------------------------------------
    FileDelete, %ThisPumProcessXml%
    ; -------------------------------------------
    ; [DELETE] Old (toolbox)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [WRITE] [NEW] toolbox0
    ; -------------------------------------------
    for Index, ThisLine in ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
    {
      ; -------------------------------------------
      FileAppend, %ThisLine%`n, %ThisPumProcessXml%, CP20127 ; 20127 us-ascii US-ASCII (7-bit)
    }
    ; -------------------------------------------
    Sleep, 250
    ; -------------------------------------------
    ; [End] [WRITE] [NEW] toolbox0
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [Add Pum to Pum List]
    ; -------------------------------------------
    PumPath := A_AppData "\PopUpMenu_PUM\pums"
    PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
    if FileExist(PumList)
    {
      FileDelete, %PumList%
    }
    Loop Files, %PumPath%\pum_*.exe, R
    {
      ThisPumPath := A_LoopFileFullPath
      SplitPath, ThisPumPath, ThisPum
      FileEncoding, UTF-8
      FileAppend, %ThisPum%`n, %PumList% ; UTF-8
    }
    ; -------------------------------------------
    ; [Add Pum to Pum List]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray.301.11 := 1 ; (301_11)(Key_ShortcutInAppPum [0,1])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [COPY] Script Files
    ; -------------------------------------------
    CopyToPath := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\ahk"
    ; -------------------------------------------
    CopyFromPath := "C:\Program Files\PopUpMenu_PUM"
    CopyFiles(CopyFromPath, CopyToPath, "Shortcut_Run.ahk")
    ; -------------------------------------------
    ; [COPY] Script Files
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [RUN] ThisPumProcessPath
    ; -------------------------------------------
    Run,  %ThisPumProcessPath%,,, ThisPumProcessPriority
    ; -------------------------------------------
    ; [RUN] ThisPumProcessPath
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Current (ThisPumProcessArray)
    ; After [RUN] ThisPumProcessPath
    ; -------------------------------------------
    ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
    DataArray.361.10 := ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
    DataArray.361.9 := ThisPumProcessXml ; (361)(09)(ThisPumProcessXml [toolbox0] [Full File Path])
    ; -------------------------------------------
    ; Current (ThisPumProcessArray)
    ; After [RUN] ThisPumProcessPath
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Wait for pum to be Active
    ; -------------------------------------------
    WinWait ahk_exe %ThisPumProcessExe%
    Process, Priority, %ThisPumProcessPriority%, High
    WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
    ; -------------------------------------------
    ; Wait for pum to be Active
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if FileExist(AppProcessPathNameExt) ; [Application Exist]
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
  ScriptRunning := Script_Running(ScriptPath)
  if (ScriptRunning > 0)
  {
    Script_Close(ScriptPath)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CopyFiles(PathFrom, PathTo, FileName)
{
  ; -------------------------------------------
  if !FileExist(PathTo)
  {
    FileCreateDir, %PathTo%
  }
  ; -------------------------------------------
  CopyFrom := PathFrom "\" FileName
  CopyTo   := PathTo "\" FileName
  FileCopy, %CopyFrom%, %CopyTo%, 1
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
