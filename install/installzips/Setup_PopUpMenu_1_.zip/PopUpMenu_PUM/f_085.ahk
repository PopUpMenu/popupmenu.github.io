﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_085(DataArray) ; (085_1)(Obj_Key_Keyboard)
{
  ; -------------------------------------------
  v_085_2 := DataArray.85.2 ; (085_2)(Obj_Key_Keyboard_Sel [0,1,2,3])
  ; -------------------------------------------
  if (v_085_2 == 1) ; (085_2)(Obj_Key_Keyboard_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.366.5 := "key" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    AppName  := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
    ; -------------------------------------------
    if (AppName != "windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    {
      ; -------------------------------------------
      v_302_7 := DataArray.302.7 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
      if (v_302_7 == 1) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
      {
        DataArray := Image_GuiControl("087", 1, 1, DataArray) ; (087_1)(Obj_Mnu_Menu)
      }
      else if (v_302_7 == 0) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
      {
        DataArray := Image_GuiControl("087", 3, 1, DataArray) ; (087_1)(Obj_Mnu_Menu)
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    DataArray := Image_GuiControl("070", 1, 1, DataArray) ; (070_1)(Obj_Cpl_WinControl)
    DataArray := Image_GuiControl("085", 2, 1, DataArray) ; (085_1)(Obj_Key_Keyboard)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
    ;
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
