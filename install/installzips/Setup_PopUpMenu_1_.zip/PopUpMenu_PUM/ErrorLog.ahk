﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ErrorLog(ErrorArray)
{
  ; -------------------------------------------
  ErrorArray_Len := ErrorArray.MaxIndex()
  ; -------------------------------------------
  if (ErrorArray.MaxIndex() > 0) ; Array Length
  {
    ; -------------------------------------------
    ErrorFolder := "C:\Users\" A_UserName "\Desktop\PopUpMenu Error"
    ; -------------------------------------------
    if !FileExist(ErrorFolder)
    {
      FileCreateDir, %ErrorFolder%
      Sleep, 250
    }
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FormatTime, TimeRightNow , , yyyyMMddHHmmss
    ThisYear := SubStr(TimeRightNow, 1, 4)
    ThisMonth := SubStr(TimeRightNow, 5, 2)
    ThisDay := SubStr(TimeRightNow, 7, 2)
    ThisHour := SubStr(TimeRightNow, 9, 2)
    ThisMinute := SubStr(TimeRightNow, 11, 2)
    ThisSecond := SubStr(TimeRightNow, 13, 2)
    ; -------------------------------------------
    ErrorFile := ErrorFolder "\Error_Log_" ThisYear "_" ThisMonth "_" ThisDay "-" ThisHour "`." ThisMinute "`." ThisSecond ".txt"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ThisErrorMsg := "*** There was Error ***`n"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    for ErrorIndex, ThisErrorLine in ErrorArray
    {
      ; -------------------------------------------
      ErrorMsg := ErrorMsg ThisErrorLine "`n"
      ; -------------------------------------------
      FileAppend, %ThisErrorLine%`n, %ErrorFile%, UTF-8
      ; -------------------------------------------
    }
    ; -------------------------------------------
    MsgBox, 0, , %ThisErrorMsg%, 3
    ThisErrorMsg := ""
    ; -------------------------------------------
  } ; if (ErrorArray.MaxIndex() > 0) ; Array Length
  ; -------------------------------------------
} ; ErrorLog(ErrorArray)
