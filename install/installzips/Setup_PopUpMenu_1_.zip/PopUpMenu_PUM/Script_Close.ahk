﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Script_Close(ScriptPath)
{
  ; -------------------------------------------
  SplitPath, ScriptPath, , , , ScriptNameNoExt
  ; -------------------------------------------
  DetectHiddenWindows, On
  WinGet, List, List, ahk_class AutoHotkey
  scripts := ""
  Loop % List
  {
    ; -------------------------------------------
    WinGetTitle, ThisScriptTitle, % "ahk_id" List%A_Index%
    WinGet, ThisScriptID, ID, %ThisScriptTitle%
    ; -------------------------------------------
    if (InStr(ThisScriptTitle, ScriptNameNoExt) > 0)
    {
      WinClose, ahk_id %ThisScriptID%
    } ; Loop % List
    ; -------------------------------------------
  }
} ; [End] Script_Close(ThisScript)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
