﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Allowed Transparency
; no  > jpeg jpg iff jps mpo pcx pxr pbm sct tga 
; yes > tif tiff gif png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ImgToIco(ImageIn, ImageOut) ; (ImageIn, ImageOut) > ImageOut
{
  ; -------------------------------------------
  ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath,  ImageIn, ImageIn_NameExt, ImageIn_Folder, ImageIn_Ext, ImageIn_Name
  StringLower, ImageIn_Ext, ImageIn_Ext
  ; -------------------------------------------
  if (ImageOut == "")
  {
    ImageOut := ImageIn_Folder "\" ImageIn_Name ".ico"
  }
  ; -------------------------------------------
  if (FileExist(ImageIn))
  {
    if (ImageIn_Ext != "ico")
    {
      ; -------------------------------------------
      ImageOut_Temp := A_AppData "\PopUpMenu_PUM\temp\" ImageIn_Name ".ico"
      ; -------------------------------------------
      ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath,  ImageOut, ImageOut_NameExt, ImageOut_Folder, ImageOut_Ext, ImageOut_Name
      StringLower, ImageOut_Ext, ImageOut_Ext
      ; -------------------------------------------
      if (ImageOut_Ext != "ico") ; (Safety) make sure the OutImage is a Icon
      {
        ImageOut := StrReplace(ImageOut, ImageOut_Ext, "ico")
      }
      ; -------------------------------------------
      Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
      ; -------------------------------------------
      RunThis := """" Support_magick """ convert """ ImageIn """ -define icon:auto-resize=80 """ ImageOut_Temp """" ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
      Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
      RunWait, %RunThis%, , Hide
      ; -------------------------------------------
      
      FileMove, %ImageOut_Temp%, %ImageOut%
      ; -------------------------------------------
    } ; [End] if (ImageIn_Ext != "ico")
    else
    {
      ; -------------------------------------------
      FileCopy, %ImageIn%, %ImageOut% ; > MoveTo
      Sleep, 10
      ; -------------------------------------------
    }
    ; -------------------------------------------
    return ImageOut
    ; -------------------------------------------
  } ; [End] if FileExist(ImageIn)
} ; [End] Image_PngToIco(ImageIn, ImageOut) ; > ImageOut
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
