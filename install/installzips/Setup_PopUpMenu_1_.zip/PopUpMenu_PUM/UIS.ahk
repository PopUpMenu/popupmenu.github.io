﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
UIS(ItemValue) ; "(U_Code)XXXX(U_Code)" > ItemValue
{
  ; -------------------------------------------
  while (InStr(ItemValue, "(U_Code)") > 0)
  {
    Pos_1 := InStr(ItemValue, "(U_Code)")
    Pos_2 := InStr(ItemValue, "(U_Code)", , , 2)
    UCode := SubStr(ItemValue, Pos_1 + 8, (Pos_2 - Pos_1) - 8)
    UnicodeNumber := "`{U`+" UCode "`}"
    ThisString := UTS(UnicodeNumber) ; "{U+xxxx}" > String
    ItemValue := StrReplace(ItemValue, "(U_Code)" UCode "(U_Code)", ThisString)
  }
  ; -------------------------------------------
  return ItemValue
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
UTS(ThisCode) ; "{U+xxxx}" > String
{
  ; -------------------------------------------
  Return_String := ""
  Code_Array := ""
  ; -------------------------------------------
  Num := 1
  Pos_S := InStr(ThisCode, "`{" , , , Num)
  while (Pos_S > 0)
  {
    Pos_E := InStr(ThisCode, "`}" , , , Num)
    Pos_Len := Pos_E - Pos_S
    Pos_Len := Pos_Len + 1
    Single_Code := SubStr(ThisCode, Pos_S, Pos_Len)
    ; -------------------------------------------
    CheckThis := Code_Array[1]
    if CheckThis
    {
      Code_Array.Push(Single_Code) ; Adds (AddThis) to End
    } ; End if CheckThis
    else
    {
      Code_Array := []
      Code_Array[1] := Single_Code
    } ; End else
    ; -------------------------------------------
    Num := Num + 1
    Pos_S := InStr(ThisCode, "`{" , , , Num)
  }
  ThisArrayLen := Code_Array.MaxIndex()
  for Index, Single_Code in Code_Array
  {
    New_StrLen := StrLen(Single_Code)
    Loop, % StrLen(Single_Code) / New_StrLen
    {
    	vNum := "0x" SubStr(Single_Code, A_Index*New_StrLen-4, 4), Return_String .= Chr(vNum)
    }
  }
  ; -------------------------------------------
  return Return_String
  ; -------------------------------------------
} ; [End] UniCode_CodeToString(ThisCode) ; "{U+xxxx}" > String
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
