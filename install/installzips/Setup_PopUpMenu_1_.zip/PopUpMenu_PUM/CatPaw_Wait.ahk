﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, force
#Persistent ; Without the (#Persistent) Here Cursor will blink
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Get_CatPawTime()
{
  ; -------------------------------------------
  File_CatPawTime := A_Appdata "\PopUpMenu_PUM\system\ThisCatPawTime.txt"
  ; -------------------------------------------
  if !FileExist(File_CatPawTime) ; File NOT Exist
  {
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, 1, %File_CatPawTime% ; 20127 us-ascii US-ASCII (7-bit)
    ThisCatPawTime := 60000 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
    ; -------------------------------------------
  } ; [End] if !FileExist(File_CatPawTime) ; File NOT Exist
  else ; File Exist
  {
    ; -------------------------------------------
    FileReadLine, ThisCatPawTime, %File_CatPawTime%, 1
    ; -------------------------------------------
    if (ThisCatPawTime != 1 && ThisCatPawTime != 2 && ThisCatPawTime != 3 && ThisCatPawTime != 4 && ThisCatPawTime != 5) ; Something Wrong whit File
    {
      ; -------------------------------------------
      FileDelete, %File_CatPawTime%
      FileEncoding, UTF-8
      FileAppend, 1, %File_CatPawTime% ; 20127 us-ascii US-ASCII (7-bit)
      ThisCatPawTime := 60000 ; (169_2)(Obj_CatPawAutoStart_Sel [0,1,2,3]
      ; -------------------------------------------
    } ; [End] Something Wrong with File
    else
    {
      ThisCatPawTime := ThisCatPawTime * 60000
    }
    ; -------------------------------------------
  } ; [End] else ; File Exist
  ; -------------------------------------------
  return ThisCatPawTime
  ; -------------------------------------------
} ; [End] Get_CatPawTime()
; -------------------------------------------
CatPawTime := Get_CatPawTime()
; -------------------------------------------
SetTimer, CheckIdle_1, 50
; -------------------------------------------
CheckIdle_1:
{
  ; -------------------------------------------
  SetTimer, CheckIdle_1, 10
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
  if (Script_Running(ScriptPath) == 0) ; (NOT Running)
  {
    ExitApp
  }
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\CatPaw.ahk"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    ExitApp
  }
  ; -------------------------------------------
  if (A_TimeIdlePhysical > CatPawTime)
  {
    ; -------------------------------------------
    if !WinExist("CatPawCount" . "ahk_class AutoHotkeyGUI")
    {
      SetTimer, CheckIdle_1, Off
      RunWait, C:\Program Files\PopUpMenu_PUM\CatPaw_Count.ahk
    }
    ; -------------------------------------------
  } ; [End] if (A_TimeIdlePhysical > CatPawTime)
} ; [End] CheckIdle:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
