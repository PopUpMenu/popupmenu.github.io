﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_098(DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
{
  ; -------------------------------------------
  if (DataArray.98.2 == 1) ; (098_2)(Obj_Mnu_AppMenu11_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.302.2 := 11 ; (302_2)(Mnu_Number_x000 [#_X_X_X])
    DataArray.302.3 := 0 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
    DataArray.302.4 := 0 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
    DataArray.302.5 := 0 ; (302_5)(Mnu_Number_000x [X_X_X_#])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
