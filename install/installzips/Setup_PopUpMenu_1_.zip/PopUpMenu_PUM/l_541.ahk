﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_541: ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
{
  ; -------------------------------------------
  ; Background Image Rotate Left
  ; -------------------------------------------
  ;
  ; (_w300 x h300_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Background Image Rotate Left)
  ; global n_541 := 0 ; Start Frame Number
  ; global s_541 := 1 ; Show
  ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Background Image Rotate Left)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Background Image Rotate Left)
  ; global s_541 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Background Image Rotate Left)
  ;
  ; [ANIMATE] Start/Show in This File
  ; (182_1)(Obj_Pum_BgRotateLeft)
  ;
    ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 7
  ; -------------------------------------------
  if (s_541 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_541 > Total_Images) ; 1 Less than Number of Images
    {
      global n_541 := 1
    }
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, C:\Program Files\PopUpMenu_PUM\image\gui\(541)_%n_541%.png ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
    Gui_ObjectSize("254", DataArray) ; > Nothing
    ; -------------------------------------------
    if (ShowAnimationChange == 0)
    {
      GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
      global ShowAnimationChange := 1
    }
    ; -------------------------------------------
    global n_541 := n_541 + 1
    ; -------------------------------------------
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_541, Off ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; End (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
