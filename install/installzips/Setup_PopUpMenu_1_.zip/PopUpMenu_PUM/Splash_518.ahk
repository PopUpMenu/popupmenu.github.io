﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; PopUpMenu is Running
; Ran in (PopUpMenu.ahk)
; ("(500)_" GuiAlreadyNum ".png")
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [StartUp] Vars / PreLoad Image
; -------------------------------------------
; Max 3 Seconds to ExitApp
; -------------------------------------------
Breaktime := A_TickCount + 3000
ImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
; -------------------------------------------
GuiAlreadyNum := 0
; -------------------------------------------
GuiAlreadyNum := 0
; -------------------------------------------
; [StartUp] Vars / PreLoad Image
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui
; -------------------------------------------
Gui, PopUpMenuAlreadyLoaded:Add, Picture, x0  y0   w200 h250 vG_GuiAlready, 
; -------------------------------------------
Gui, PopUpMenuAlreadyLoaded:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
Gui, PopUpMenuAlreadyLoaded:Color, 562958 ; Good Color For Pum Guy 
WinSet, TransColor, 562958
; -------------------------------------------
Gui, PopUpMenuAlreadyLoaded:Show, ,
; -------------------------------------------
SetTimer, PopUpMenu518Already, 50
; -------------------------------------------
return
; -------------------------------------------
; Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
PopUpMenu518Already:
{
  ; -------------------------------------------
  if (A_TickCount > BreakTime)
  {
    ; -------------------------------------------
    SetTimer, PopUpMenu518Already, Off
    ExitApp
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (GuiAlreadyNum < 23)
  {
    GuiAlreadyNum := GuiAlreadyNum + 1
    ThisImage := ImagePath "\(500)_" GuiAlreadyNum ".png"
    GuiControl, PopUpMenuAlreadyLoaded:, G_GuiAlready, %ThisImage%
    if (GuiAlreadyNum > 13)
    {
      ; -------------------------------------------
      SetTimer, PopUpMenu518Already, 100
      if (GuiAlreadyNum == 23)
      {
        SetTimer, PopUpMenu518Already, 500
      }
      ; -------------------------------------------
    } ; if (GuiAlreadyNum > 13)
  } ; if (GuiAlreadyNum < 23)
  else
  {
    ; -------------------------------------------
    Sleep, 1000
    ; -------------------------------------------
    ExitApp
  }
  ; -------------------------------------------
} ; PopUpMenu518Already:
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
