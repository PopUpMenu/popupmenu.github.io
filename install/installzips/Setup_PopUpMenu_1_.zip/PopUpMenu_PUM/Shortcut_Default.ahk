﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Crop.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizeImg.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Rotate.ahk
#Include C:\Program Files\PopUpMenu_PUM\ProveRowYColX.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_FileDelete.ahk
#Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
#Include C:\Program Files\PopUpMenu_PUM\Wait_FileFolder.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\XmlWrite.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Run.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; "16777215" ; (White) (370_4)(XML_SC_L1 [TextColor])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_Default(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [CLOSE] Gui and Pum
    ; -------------------------------------------
    Gui, PopUpMenu:Destroy
    ; -------------------------------------------
    WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    if (InStr(ThisPumProcessExe, "pum_") > 0)
    {
      Process, Close, %ThisPumProcessExe%
      ; -------------------------------------------
      Pum_FileDelete(ThisPumProcessExe)
      ; -------------------------------------------
    } ; [End] if (InStr(ThisPumProcessExe, "pum_") > 0)
    ; -------------------------------------------
  } ; [End] [CLOSE] Gui and Pum
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; VARS ThisPumProcess
    ; -------------------------------------------
    ThisPumProcessName := ThisPumProcessExe
    ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
    ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
    ; -------------------------------------------
    ThisPumProcessFolder         := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
    ThisPumProcessPath           := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\" ThisPumProcessExe
    ThisPumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings"
    ThisPumProcessXml            := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
    ThisPumProcessIconCache      := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache"
    ThisPumProcessArray          := Array_FromFile(ThisPumProcessXml)
    ; -------------------------------------------
    if !FileExist(ThisPumProcessIconCache)
    {
      FileCreateDir, %ThisPumProcessIconCache%
      Sleep, 10
    }
    ; -------------------------------------------
    DataArray.361.8 := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    DataArray.361.9 := ThisPumProcessXml ; (361)(9)(ThisPumProcessXml [Full File Path])
    ; -------------------------------------------
  } ; VARS ThisPumProcess
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [STARTUP] Vars
    ; -------------------------------------------
    if (DataArray.301.5 == "") ; (301_5)(KeyMnu_Class)
    {
      DataArray.301.5 := DataArray.367.3 ; (301_5)(KeyMnu_Class)/(367_3)(AppProcessClass)
    }
    if (DataArray.301.6 == "") ; (301_6)(keyMnu_ProcessName)
    {
      DataArray.301.6 := StrReplace(DataArray.367.2, ".exe", "") ; (301_6)(keyMnu_ProcessName)/(367_2)(AppProcessExtName [Name,Ext])
    }
    ; -------------------------------------------
    ShortcutScript := 0
    ; -------------------------------------------
    UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    Obj_DisplayedIcon_Img  := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; -------------------------------------------
    Obj_EditFeild_StatusBar_Val  := DataArray.122.3 ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    Obj_DeleteShortcut_Sel := DataArray.133.2 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    ; -------------------------------------------
    ScriptType  := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    ;
    ; ------------------------------------------- XML Shortcut
    XmlShortcutLineNum            := DataArray.370.1 ; (370_1)(XmlShortcutLineNum [XML Line Number])
    XmlShortcutPosX       := DataArray.370.2 ; (370_2)(XmlShortcutPosX)
    XmlShortcutPosY          := DataArray.370.3 ; (370_3)(XmlShortcutPosY)
    XmlOldScriptPath := DataArray.370.9 ; (370_9)(XmlOldScriptPath [Full File Path])
    TbXml_ShortcutLine8_IconPath      := DataArray.370.10 ; (370_10)(TbXml_ShortcutLine8_IconPath [Full File Path])
    ; ------------------------------------------- XML Shortcut
    ;
    ; ------------------------------------------- XML Config
    XmlRowsY    := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
    XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
    XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
    XmlBgColor    := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
    XmlBgType     := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
    XmlBgOpacity  := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
    XmlBgBmp      := ThisPumProcessFolder "\image\bg_Selected_Bmp.bmp"
    ; -------------------------------------------
    ;
    if (XmlIconSize != 32 && XmlIconSize != 48 && XmlIconSize != 64)
    {
      XmlIconSize := 48
    }
    ; -------------------------------------------  XML Config
    ;
    ; ------------------------------------------- Backgroung Image
    Img_W := DataArray.362.34 ; (362_34)(Img_W)
    Img_H := DataArray.362.35 ; (362_35)(Img_H)
    ; (362_36)(Pum_W)
    ; (362_37)(Pum_H)
    bg_Image_Type := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
    Img_Gui_W := DataArray.362.39 ; (362_39)(Img_Gui_W)
    Img_Gui_H := DataArray.362.40 ; (362_40)(Img_Gui_H)
    Img_Gui_X := DataArray.362.41 ; (362_41)(Img_Gui_X)
    Img_Gui_Y := DataArray.362.42 ; (362_42)(Img_Gui_Y)
    ; (362_43)(PumBody_H)
    Pum_Gui_W := DataArray.362.44 ; (362_44)(Pum_Gui_W)
    Pum_Gui_H := DataArray.362.45 ; (362_45)(Pum_Gui_H)
    Pum_Gui_X := DataArray.362.46 ; (362_46)(Pum_Gui_X)
    Pum_Gui_Y := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
    Pum_Gui_Max_W := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
    Pum_Gui_Max_H := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
    Pum_Gui_Min_W := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
    Pum_Gui_Min_H := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
    ; ------------------------------------------- Backgroung Image
  } ; End [STARTUP] Vars  
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; Write mobiletext.txt
    ; -------------------------------------------
    Pum_MobileTextSize  := DataArray.362.23 ; (362_23)(Pum_MobileTextSize [Font Size, 10, 12, 14])
    Pum_MobileTextOnOff := DataArray.362.24 ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
    Pum_MobileTextColor := DataArray.362.25 ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    Pum_MobileBgColor   := DataArray.362.26 ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (Pum_MobileTextSize == "")
    {
      Pum_MobileTextSize := "12"
    }
    ; -------------------------------------------
    if (Pum_MobileTextOnOff == "")
    {
      Pum_MobileTextOnOff := "1"
    }
    ; -------------------------------------------
    if (Pum_MobileTextColor == "")
    {
      Pum_MobileTextColor := "0X000000"
    }
    ; -------------------------------------------
    if (Pum_MobileBgColor == "")
    {
      Pum_MobileBgColor := "0xffffff"
    }
    ; -------------------------------------------
    File_MobileText := ThisPumProcessFolder "\ahk\mobiletext.txt"
    FileDelete, %File_MobileText%
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    FileAppend, %Pum_MobileTextOnOff%`n, %File_MobileText% ; UTF-8
    FileAppend, %Pum_MobileTextColor%`n, %File_MobileText% ; UTF-8
    FileAppend, %Pum_MobileBgColor%`n, %File_MobileText% ; UTF-8
    FileAppend, %Pum_MobileTextSize%`n, %File_MobileText% ; UTF-8
    ; -------------------------------------------
    ;
    Wait_FileFolder("Exist", File_MobileText) ; (WaitType["Exist","NotExist","ID"], ThisFileFolder > Nothing
    ; -------------------------------------------
  } ; [End] Write mobiletext.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; PUM (Config) Write New ARRAY (Pum toolbox0 [Array])
    ; -------------------------------------------
    ; New DefaultPum (left="0" top="0") (pum_pumdefault.exe)
    ; -------------------------------------------
    XML_Line_1 := "<?xml version=""1.0"" encoding=""ISO-8859-1"" standalone=""yes"" `?>"
    XML_Line_3 := "<toolbox name="""" rows=""" XmlRowsY """ columns=""" XmlColumnsX """ left=""" DataArray.362.5  """ top=""" DataArray.362.6  """ stayontop=""-1"" >" ; (362_5)(XmlPosX [Pum Window Position (X) Left])/(362_6)(XmlPosY [Pum Window Position (Y) Top])
    XML_Line_5 := "  <titlebar visible=""0"" height=""16"" />"
    XML_Line_7 := "  <statusbar visible=""0"" height=""16"" hint=""0"" />"
    XML_Line_9 := "  <displaymode type=""0"" iconsize=""" XmlIconSize """ />"
    XML_Line_11 := "  <tile width=""" XmlIconSize """ height=""" XmlIconSize """ cellspacing=""0"" />"
    XML_Line_13 := "  <border spacing=""0"" type=""0"" />"
    XML_Line_15 := "  <font name=""Microsoft Sans Serif"" color=""0"" size=""8"" shadowtype=""0"" />"
    XML_Line_17 := "  <hint show=""0"" color=""0"" background=""0"" />"
    XML_Line_19 := "  <background color=""" XmlBgColor """ type=""" XmlBgType """ effect=""0"" opacity=""" XmlBgOpacity """ >"
    XML_Line_20 := "    <filename>" XmlBgBmp "</filename>"
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(1)
    ThisPumProcessArray.InsertAt(1, XML_Line_1)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(3)
    ThisPumProcessArray.InsertAt(3, XML_Line_3)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(5)
    ThisPumProcessArray.InsertAt(5, XML_Line_5)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(7)
    ThisPumProcessArray.InsertAt(7, XML_Line_7)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(9)
    ThisPumProcessArray.InsertAt(9, XML_Line_9)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(11)
    ThisPumProcessArray.InsertAt(11, XML_Line_11)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(13)
    ThisPumProcessArray.InsertAt(13, XML_Line_13)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(15)
    ThisPumProcessArray.InsertAt(15, XML_Line_15)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(17)
    ThisPumProcessArray.InsertAt(17, XML_Line_17)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(19)
    ThisPumProcessArray.InsertAt(19, XML_Line_19)
    ; -------------------------------------------
    ThisPumProcessArray.RemoveAt(20)
    ThisPumProcessArray.InsertAt(20, XML_Line_20)
    ; -------------------------------------------
  } ; [End] PUM (Config) Write New ARRAY (Pum toolbox0 [Array])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; (Script_Line_1-6)
    ; -------------------------------------------
    ShortcutScript := 1
    Obj_DeleteShortcut_Sel == 1
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
    ; Script_Line_4 := "Run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
    ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; Script_Line_6 := ""                         (Empty)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ;
    ; -------------------------------------------
    ; (305_11)(run_OutTarget [PathExtName])
    ; (305_12)(run_Arguments [Executable Arguments])
    ; (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; (305_14)(run_FileSelected [Selected File PathExtName (Select_FileFolder)])
    ; (305_15)(run_LinkIcon [Icon of Selected Link File (Select_FileFolder)])
    ; (305_16)(run_LinkName [Selected Link File Name (Select_FileFolder)])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Script_Line_2 := "Script_Line_2 := 1" ; (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
    ; -------------------------------------------
    DefaultPum := "C:\Program Files\PopUpMenu_PUM\Shortcut_RunDefault.ahk"
    Script_Line_3 := "Script_Line_3 := """ DefaultPum """" ; (305_11)(run_OutTarget [PathExtName])
    ; -------------------------------------------
    Script_Line_4 := "Script_Line_4 := """"" ; (305_12)(run_Arguments [Executable Arguments])
    Script_Line_5 := "Script_Line_5 := 0" ; (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; -------------------------------------------
    Script_Line_6 := "Script_Line_6 := """""
    ; -------------------------------------------
  } ; (Script_Line_1-6)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [Time Stamp]
    ; -------------------------------------------
    FormatTime, TimeRightNow , , yyyyMMddHHmmss
    ThisYear := SubStr(TimeRightNow, 1, 4)
    ThisMonth := SubStr(TimeRightNow, 5, 2)
    ThisDay := SubStr(TimeRightNow, 7, 2)
    ThisHour := SubStr(TimeRightNow, 9, 2)
    ThisMinute := SubStr(TimeRightNow, 11, 2)
    ThisSecond := SubStr(TimeRightNow, 13, 2)
    TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond
    ; -------------------------------------------
    SC_Script := ScriptType "-" TimeRightNow ".ahk"
    SC_Icon := TimeRightNow ".ico"
    ; -------------------------------------------
    SC_PathIcon := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache\" SC_Icon
    ; -------------------------------------------
    RunAnimate := 0
    Image_ImgToIco(Obj_DisplayedIcon_Img, SC_PathIcon) ; > ImageOut
    ; -------------------------------------------
    if (ThisMonth == "01")
    {
      ThisMonth := "Jan"
    }
    else if (ThisMonth == "02")
    {
      ThisMonth := "Feb"
    }
    else if (ThisMonth == "03")
    {
      ThisMonth := "Mar"
    }
    else if (ThisMonth == "04")
    {
      ThisMonth := "Apr"
    }
    else if (ThisMonth == "05")
    {
      ThisMonth := "May"
    }
    else if (ThisMonth == "06")
    {
      ThisMonth := "Jun"
    }
    else if (ThisMonth == "07")
    {
      ThisMonth := "Jul"
    }
    else if (ThisMonth == "08")
    {
      ThisMonth := "Aug"
    }
    else if (ThisMonth == "09")
    {
      ThisMonth := "Sep"
    }
    else if (ThisMonth == "10")
    {
      ThisMonth := "Oct"
    }
    else if (ThisMonth == "11")
    {
      ThisMonth := "Nov"
    }
    else if (ThisMonth == "12")
    {
      ThisMonth := "Dec"
    }
    ; -------------------------------------------
    if (ThisHour > 12)
    {
      AmPm := "PM"
      ThisHour := ThisHour - 12
      if (SubStr(ThisHour, 1, 1) == "0")
      {
        ThisHour := SubStr(ThisHour, 2, 1)
      }
    }
    else
    {
      AmPm := "AM"
    }
    ; -------------------------------------------
    ThisYear := SubStr(ThisYear, 3, 2)
    ThisTime := ThisDay "-" ThisMonth "-" ThisYear " " ThisHour ":" ThisMinute ":" ThisSecond " " AmPm
    ; -------------------------------------------
  } ; [Time Stamp]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [CREATE] Shortcut Script
    ; -------------------------------------------
    Xml_SC_Icon := "pumiconcache\" SC_Icon
    Xml_SC_Script := "ahk\" SC_Script
    ; -------------------------------------------
    XML_SC_Line_1 := "    <shortcut row=""" XmlShortcutPosY """ column=""" XmlShortcutPosX """ textcolor=""0"" textalign=""0"" paraalign=""2"" type=""0"" >"
    XML_SC_Line_2 := "      <filename>" Xml_SC_Script "</filename>"
    XML_SC_Line_3 := "      <openwith></openwith>"
    XML_SC_Line_4 := "      <startin></startin>"
    XML_SC_Line_5 := "      <consolebuffer hintastitle=""0"" override=""0"" rows=""0"" cols=""0"" />"
    XML_SC_Line_6 := "      <hint></hint>"
    XML_SC_Line_7 := "      <overlaytext></overlaytext>"
    XML_SC_Line_8 := "      <icon name=""" Xml_SC_Icon """ index=""0"" />"
    XML_SC_Line_9 := "      <statistics executions=""0"" since=""" ThisTime """ />"
    XML_SC_Line_10 := "    </shortcut>"
    ; -------------------------------------------
    Script_Array := []
    Script_Array.1 := "`#Include C:\Program Files\PopUpMenu_PUM\Shortcut_Run.ahk"
    Script_Array.2 := Script_Line_2
    Script_Array.3 := Script_Line_3
    Script_Array.4 := Script_Line_4
    Script_Array.5 := Script_Line_5
    Script_Array.6 := Script_Line_6
    Script_Array.7 := "Shortcut_Run(""" ScriptType """, Script_Line_2, Script_Line_3, Script_Line_4, Script_Line_5, Script_Line_6)"
    Script_Array.8 := "`#NoTrayIcon"
    Script_Array.9 := "ExitApp"
    Script_Array.10 := "`;" Obj_EditFeild_StatusBar_Val
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    XmlScriptPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\ahk\" SC_Script
    for Index, ThisLine in Script_Array
    {
      FileEncoding, UTF-8 ; UTF-8
      FileAppend, %ThisLine%`n, %XmlScriptPath% ; UTF-8
    } ; [End] for Index, ThisLine in Script_Array
  } ; [End] [CREATE] Shortcut Script
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [NEW] Shortcut
    ; -------------------------------------------
    LineNum := 25
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_1)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_2)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_3)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_4)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_5)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_6)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_7)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_8)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_9)
    ; -------------------------------------------
    LineNum := LineNum + 1
    ThisPumProcessArray.InsertAt(LineNum, XML_SC_Line_10)
    ; -------------------------------------------
    ThisPumProcessArray.InsertAt(35, "") ; (361)(10)(ThisPumProcessArray)
    ; -------------------------------------------
  } ; [NEW] Shortcut
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Prove rows="#" columns="#"
  ; <toolbox name="" rows="#" columns="#" left="38" top="36" stayontop="-1" >
  ; -------------------------------------------
  ThisPumProcessArray := ProveRowYColX(ThisPumProcessArray) ; > ThisXmlArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CHECK] for ERRORS / [WRITE] (ThisPumProcessXml)
  ; -------------------------------------------
  ;	Writes a (File_TempXml)
	; then Checks that (Temp Xml file) Againest the (Array_ThisXml)
	; if the Written (Temp Xml file) matches the Oranganal (Array_ThisXml)
	;  > Will Copy and Overwrite (File_ThisXml)
  ; -------------------------------------------
  XmlPassed := XmlWrite(ThisPumProcessArray, ThisPumProcessXml) ; Array_ThisXml, File_ThisXml > 1 = Ok , 0 Xml Has Error
  ; -------------------------------------------
  ; [CHECK] for ERRORS / [WRITE] (ThisPumProcessXml)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  if (XmlPassed == 1) ; XML is OK
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [DELETE] Old toolbox0, ThisPumProcessFolder "\settings\*.bmp"
    ; -------------------------------------------
    ;~ Bmp_Images := ThisPumProcessFolder "\settings\*.bmp"
    ;~ FileDelete, %Bmp_Images%
    ;~ ; -------------------------------------------
    ;~ Icl_Files := ThisPumProcessFolder "\*.icl"
    ;~ FileDelete, %Icl_Files%
    ;~ ; -------------------------------------------
    ;~ Dwl_Files := ThisPumProcessFolder "\*.dwl" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ;~ FileDelete, %Dwl_Files%
    ;~ ; -------------------------------------------
    ;~ Dwl_Files := ThisPumProcessFolder "\*.dwl2" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ;~ FileDelete, %Dwl_Files%
    ;~ ; -------------------------------------------
    ;~ Dwl_Files := ThisPumProcessFolder "\*.dwl3" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ;~ FileDelete, %Dwl_Files%
    ; -------------------------------------------
    ; [End] [DELETE] Old toolbox0, ThisPumProcessFolder "\settings\*.bmp"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [COPY] [NEW] Pum Background Images
    ; -------------------------------------------
    bg_Selected_Change := DataArray.362.52 ; (362_52)(bg_Selected_Change)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (bg_Selected_Change == 1 or bg_Selected_Change == 2 && ScriptType != "pum_pumSetting_pumDimension")
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [MOVE] Temp_Display_Txt_[Img,Col] to bg_Display_Txt_[Img,Col]
      ; -------------------------------------------
      Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png"
      bg_Display_Txt_Img := ThisPumProcessFolder "\image\bg_Display_Txt_Img.png"
      ;
      if FileExist(Temp_Display_Txt_Img)
      {
        FileMove, %Temp_Display_Txt_Img%, %bg_Display_Txt_Img%, 1
      } ; [End] if FileExist(Temp_Display_Txt_Img)
      else
      {
        FileDelete, %bg_Display_Txt_Img%
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png"
      bg_Display_Txt_Col := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png"
      ;
      if FileExist(Temp_Display_Txt_Col)
      {
        FileMove, %Temp_Display_Txt_Col%, %bg_Display_Txt_Col%, 1
      }
      ; -------------------------------------------
      Sleep, 100
      ; -------------------------------------------
      ; [MOVE] Temp_Display_Txt_[Img,Col] to bg_Display_Txt_[Img,Col]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if (bg_Selected_Change == 1 or bg_Selected_Change == 2)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (bg_Selected_Change == 2)
    {
      if (XmlBgType == 1) ; [BG Image 1]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        Splash_Script("Off", 0) ; (Just Before) (Run) PopUpMenu Working Gear
        ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
        Run, %ScriptPath%
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        bg_Selected_Rotate := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
        ; -------------------------------------------
        ;
        ; ------------------------------------------- [DELETE]
        File_Pum_Gui := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        FileDelete, %File_Pum_Gui%
        ; ------------------------------------------- [DELETE]
        File_TxT_Gui_C := ThisPumProcessFolder "\image\File_TxT_Gui_C.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        FileDelete, %File_TxT_Gui_C%
        ; ------------------------------------------- [DELETE]
        Delete_1 := ThisPumProcessFolder "\image\bg_Selected_img.*" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        FileDelete, %Delete_1%
        ; ------------------------------------------- [DELETE]
        ;
        ; -------------------------------------------
        Temp_Selected_Img := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
        SplitPath, Temp_Selected_Img, Temp_Selected_Img_FileNameExt, Temp_Selected_Img_Folder, Temp_Selected_Img_Ext, Temp_Selected_Img_FileName
        StringLower, Temp_Selected_Img_Ext, Temp_Selected_Img_Ext
        ; -------------------------------------------
        ;
        ; ------------------------------------------- [MOVE]
        bg_Selected_img := ThisPumProcessFolder "\image\bg_Selected_img." Temp_Selected_Img_Ext ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ;
        if FileExist(Temp_Selected_Img)
        {
          FileMove, %Temp_Selected_Img%, %bg_Selected_img%, 1
        }
        ; ------------------------------------------- [MOVE]
        Temp_Selected_Gui := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        bg_Selected_Gui := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ;
        if FileExist(Temp_Selected_Gui)
        {
          FileMove, %Temp_Selected_Gui%, %bg_Selected_Gui%, 1
        }
        ; ------------------------------------------- [MOVE]
        Temp_Selected_Fit := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        bg_Selected_Fit := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ;
        if FileExist(Temp_Selected_Fit)
        {
          FileMove, %Temp_Selected_Fit%, %bg_Selected_Fit%, 1
        }
        ; ------------------------------------------- [MOVE]
        Temp_Display_Img := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        bg_Display_Img := ThisPumProcessFolder "\image\bg_Display_Img.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ;
        if FileExist(Temp_Display_Img)
        {
          FileMove, %Temp_Display_Img%, %bg_Display_Img%, 1
        }
        ; ------------------------------------------- [MOVE]
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray) ; (362_27)(XmlBgColor [Background color])
        Pum_BgColor_GridNum := Color_Array.2
        Temp_Resize := "C:\Program Files\PopUpMenu_PUM\image\pum\Pum_" Pum_BgColor_GridNum "_100.png"
        ; -------------------------------------------
        bgColor_Temp := ThisPumProcessFolder "\image\bgColor_Temp.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        Image_ResizePng(Pum_W, Pum_H, Temp_Resize, bgColor_Temp) ; Resize_W, Resize_H, Image_In, Image_Out > 1 / 0
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (bg_Temp.png)
        ; Rotate bg.bmp
        bg_Temp := ThisPumProcessFolder "\image\bg_Temp.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ;
        if (bg_Selected_Rotate == "-90" or bg_Selected_Rotate == "90" or bg_Selected_Rotate == "180")
        {
          Image_Rotate(bg_Selected_Rotate, bg_Selected_img, bg_Temp) ; bg_Selected_Rotate, Image_In, Image_Out > 1 / 0
        } ; End (bg_Selected_Rotate == "-90" or bg_Selected_Rotate == "90" or bg_Selected_Rotate == "180")
        else
        {
          FileCopy, %bg_Selected_img%, %bg_Temp%, 1
          Sleep, 10
        }
        ; -------------------------------------------
        if (Bg_Image_Type == "C") ; [CROP] (bg_Temp.png)
        {
          ; -------------------------------------------
          Pum_Factor := Pum_W / Pum_Gui_W
          Img_W := Round(Pum_Factor * Img_Gui_W)
          Img_H := Round(Pum_Factor * Img_Gui_H)
          Image_ResizePng(Img_W, Img_H, bg_Temp, bg_Temp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
          Pum_X_Temp := Round(Pum_Factor * Pum_Gui_X)
          Pum_Y_Temp := Round(Pum_Factor * Pum_Gui_Y)
          ; -------------------------------------------
          Crop_Array := [Pum_W, Pum_H, Pum_X_Temp, Pum_Y_Temp, bg_Temp, bg_Temp]
          Image_Crop(Crop_Array) ; [ImageOut_W, ImageOut_H, Position_X, Position_Y, ImageIn, ImageOut] > 1 / 0
          ; -------------------------------------------
        } ; End (Bg_Image_Type == "C")
        else if (Bg_Image_Type == "F") ; [Fit] (bg_Temp.png)
        {
          ; -------------------------------------------
          Image_ResizeImg(Pum_W, Pum_H, bg_Temp, bg_Temp) ; Resize_W, Resize_H, Image_In, Image_Out > 1 / 0
        } ; End (Bg_Image_Type == "F")
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (bg_Selected_Bmp.bmp)
        bg_Selected_Bmp := ThisPumProcessFolder "\image\bg_Selected_Bmp.bmp" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        FileDelete, %bg_Selected_Bmp%
        Image_Array := [Pum_W, Pum_H, bg_Selected_Bmp, bgColor_Temp, 0, 0, bg_Temp, 0, 0]
        Image_Combine(Image_Array) ; > Image_Out
        ; -------------------------------------------
        FileDelete, %bg_Temp%
        FileDelete, %bgColor_Temp%
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Info_bg.txt)
        Info_bg   := ThisPumProcessFolder "\image\Info_bg.txt" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        FileDelete, %Info_bg%
        ; -------------------------------------------
        FileEncoding, UTF-8 ; UTF-8
        FileAppend, %Img_W%`n, %Info_bg% ; UTF-8         ; Line 1
        FileAppend, %Img_H%`n, %Info_bg% ; UTF-8         ; Line 2
        FileAppend, %Pum_W%`n, %Info_bg% ; UTF-8         ; Line 3
        FileAppend, %Pum_H%`n, %Info_bg% ; UTF-8         ; Line 4
        FileAppend, %bg_Image_Type%`n, %Info_bg% ; UTF-8 ; Line 5
        FileAppend, %Img_Gui_W%`n, %Info_bg% ; UTF-8     ; Line 6
        FileAppend, %Img_Gui_H%`n, %Info_bg% ; UTF-8     ; Line 7
        FileAppend, %Img_Gui_X%`n, %Info_bg% ; UTF-8     ; Line 8
        FileAppend, %Img_Gui_Y%`n, %Info_bg% ; UTF-8     ; Line 9
        FileAppend, %PumBody_H%`n, %Info_bg% ; UTF-8     ; Line 10
        FileAppend, %Pum_Gui_W%`n, %Info_bg% ; UTF-8     ; Line 11
        FileAppend, %Pum_Gui_H%`n, %Info_bg% ; UTF-8     ; Line 12
        FileAppend, %Pum_Gui_X%`n, %Info_bg% ; UTF-8     ; Line 13
        FileAppend, %Pum_Gui_Y%`n, %Info_bg% ; UTF-8     ; Line 14
        FileAppend, %Pum_Gui_Max_W%`n, %Info_bg% ; UTF-8 ; Line 15
        FileAppend, %Pum_Gui_Max_H%`n, %Info_bg% ; UTF-8 ; Line 16
        FileAppend, %Pum_Gui_Min_W%`n, %Info_bg% ; UTF-8 ; Line 17
        FileAppend, %Pum_Gui_Min_H%`n, %Info_bg% ; UTF-8 ; Line 18
        FileAppend, %bg_Selected_Rotate%`n, %Info_bg% ; UTF-8   ; Line 19
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
        ScriptRunning := Script_Running(ScriptPath)
        if (ScriptRunning > 0)
        {
          Script_Close(ScriptPath)
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; End [BG Image 1]
      ; -------------------------------------------
    } ; End (bg_Selected_Change == 2)
    ; -------------------------------------------
    ; [End] [COPY] [NEW] Pum Background Images
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (ReOpen Pum)
    ; -------------------------------------------
    DataArray := Pum_Run(DataArray) ; > DataArray
    ; -------------------------------------------
    ; (ReOpen Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Current (ThisPumProcessArray)
    ; -------------------------------------------
    ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
    DataArray.361.10 := ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
    ; -------------------------------------------
    ; Current (ThisPumProcessArray)
    ; After [RUN] ThisPumProcessPath
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Wait until pum Exist
    ; -------------------------------------------
    BreakTime := A_TickCount + 3000
    Process, Exist, %ThisPumProcessExe%
    ; -------------------------------------------
    while (ErrorLevel == 0) ; pum DOES NOT Exist
    {
      ; -------------------------------------------
      Sleep, 1
      ; -------------------------------------------
      if (A_TickCount > BreakTime)
      {
        break
      } ; [End] if (A_TickCount > BreakTime_1)
      ; -------------------------------------------
    } ; [End] while (ErrorLevel == 0) ; pum DOES NOT Exist
    ; -------------------------------------------
    ; Wait until pum Exist
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Delete Old Icon and Shortcut Script
    ; -------------------------------------------
    if (XmlShortcutLineNum > 0 or Obj_DeleteShortcut_Sel == 2)
    {
      ; ------------------------------------------- 
      FileDelete, %XmlOldScriptPath%
      ; -------------------------------------------
      if (SubStr(TbXml_ShortcutLine8_IconPath, 1, 12) == "pumiconcache")
      {
        TbXml_ShortcutLine8_IconPath := ThisPumProcessFolder "\" TbXml_ShortcutLine8_IconPath
      }
      FileDelete, %TbXml_ShortcutLine8_IconPath%
      ; -------------------------------------------
      iconcache_Path := ThisPumProcessFolder "\iconcache\*.ico"
      SplitPath, TbXml_ShortcutLine8_IconPath, , , , Old_Icon_Name
      ; -------------------------------------------
      Loop, Files, %iconcache_Path%, R
      {
        ; -------------------------------------------
        This_Icon := A_LoopFileFullPath
        ; -------------------------------------------
        SplitPath, This_Icon, , , , This_Icon_Name ; FileName ; C__ProgramData_PopUpMenu_PUM_cache_20191128111115.ico,0_(64).ico
        if (InStr(This_Icon_Name, Old_Icon_Name) > 0)
        {
          FileDelete, %This_Icon%
          break
        } ; [End] if (InStr(This_Icon_Name, Old_Icon_Name) > 0)
      } ; [End] Loop, Files, %iconcache_Path%, R
      ; -------------------------------------------
    } ; [End] if (XmlShortcutLineNum > 0 or Obj_DeleteShortcut_Sel == 2)
    ; -------------------------------------------
    ; Delete Old Icon and Shortcut Script
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; if (XmlPassed == 1) ; XML is OK
  ; -------------------------------------------
  else ; (XmlPassed != 1) ; XML is NOT ok
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (ReOpen Pum)
    ; -------------------------------------------
    DataArray := Pum_Run(DataArray) ; > DataArray
    ; -------------------------------------------
    ; (ReOpen Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
