﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Array_FromFile(FilePath) ; Array_FromFile(FilePath) ; > Array
{
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileRead, FilePathString, %FilePath%
  FilePathArray := StrSplit(FilePathString, "`n", "`n")
  ReturnArray := []
  for Index, ThisLine in FilePathArray
  {
    ThisLine := StrReplace(ThisLine, "`n", "")
    ThisLine := StrReplace(ThisLine, "`r", "")
    ReturnArray.Push(ThisLine)
  }
  ; -------------------------------------------
  return ReturnArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
