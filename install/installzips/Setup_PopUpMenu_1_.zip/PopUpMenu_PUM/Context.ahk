﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Run.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
; -------------------------------------------
if (Script_Running(ScriptPath) == 0) ; (NOT Running)
{
  ; -------------------------------------------
  RunWait, C:\Program Files\PopUpMenu_PUM\SysLoad.ahk
  Sleep, 500
  ; -------------------------------------------
  DataArray := Pum_Run(DataArray) ; > DataArray
  ; -------------------------------------------
}
else
{
  ; -------------------------------------------
  DataArray := Pum_Run(DataArray) ; > DataArray
  ; -------------------------------------------
}
; -------------------------------------------
ExitApp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
