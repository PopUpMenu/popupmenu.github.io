﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_133(DataArray) ; (133_1)(Obj_DeleteShortcut)
{
  ; -------------------------------------------
  if (DataArray.133.2 == 1) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("133", 2, 1, DataArray) ; (133_1)(Obj_DeleteShortcut)
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    Gui, PopUpMenu:Color, ba556f ; Red
    ; -------------------------------------------
  }
  else if (DataArray.133.2 == 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("133", 1, 1, DataArray) ; (133_1)(Obj_DeleteShortcut)
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    if (DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 13 or DataArray.366.6 == 18 or DataArray.366.6 == 19) ; (366_6)(ScriptError [Integer])
    {
      Gui, PopUpMenu:Color, fed8ed ; Light Read
    }
    else
    {
      Gui, PopUpMenu:Color, e7d8fe ; Purple
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (DataArray.133.2 == 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  {
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
