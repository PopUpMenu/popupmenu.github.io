﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_PumBgPng(ArrayIn) ; Img_PumBgPng(ArrayIn) ; > bg_Selected_Bmp
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
bg_Selected_Bmp := Img_PumBgPng(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
bg_Selected_Bmp := Img_PumBgPng(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
bg_Selected_Bmp := Img_PumBgPng(ArrayIn)
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return bg_Selected_Bmp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; -------------------------------------------
    SplitPath, AppProcessPathNameExt, CommonBrowser
    if (CommonBrowser == "pumcommonbrowser.txt") ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Used When (DataArray.290.2 == 1)
      ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; -------------------------------------------
      FileRunPng := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
      ; -------------------------------------------
      ; Used When (DataArray.290.2 == 1)
      ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; -------------------------------------------
      if !FileExist(FileRunPng)
      {
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
        FileRunPng := Img_RunPng(ArrayIn)
        ; -------------------------------------------
      } ; [End] if !FileExist(FileRunPng)
      ; -------------------------------------------
      ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK/CREATE] (A_AppData "\PopUpMenu_PUM\temp") Folder
    ; -------------------------------------------
    PumTempFolder := A_AppData "\PopUpMenu_PUM\temp"
    ; -------------------------------------------
    if !FileExist(PumTempFolder)
    {
      FileCreateDir, %PumTempFolder%
      Sleep, 10
    } ; [End] if !FileExist(PumTempFolder)
    ; -------------------------------------------
    ; [CHECK/CREATE] (A_AppData "\PopUpMenu_PUM\temp") Folder
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\PumBgPng.png"] [Size is 320w x 256h]
    ; [Size is 320w x 256h]
    ;
    ; [WITH]    (FileRunPng)
    ; [Size is 180w x 180h]
    ;
    ; [CREATE] (bg_Selected_Png) [A_AppData "\PopUpMenu_PUM\temp\bg_Selected_Png.png"]
    ; [Size is 320w x 256h]
    ; -------------------------------------------
    bg_Selected_Png := A_AppData "\PopUpMenu_PUM\temp\bg_Selected_Png.png" ; w320, h256
    ; -------------------------------------------
    I1 := "C:\Program Files\PopUpMenu_PUM\image\ico\PumBgPng.png" ; w320, h256
    X1 := 0 ; X Position (Left)
    Y1 := 0 ; Y Postion (Down)
    ;
    I2  := FileRunPng ; 180w, 180h
    X2 := 70 ; X Position (Left)
    Y2 := 38 ; Y Postion (Down)
    ; -------------------------------------------
    ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Image_X, Image_Y,) etc]
    Image_Array := [320, 256, bg_Selected_Png, I1, X1, Y1, I2, X2, Y2]
    Image_Combine(Image_Array)
    ; -------------------------------------------
    ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\PumBgPng.png"] [Size is 320w x 256h]
    ; [Size is 320w x 256h]
    ;
    ; [WITH]    (FileRunPng)
    ; [Size is 180w x 180h]
    ;
    ; (bg_Selected_Png)
    ; [CREATE] [A_AppData "\PopUpMenu_PUM\temp\bg_Selected_Png.png"]
    ; [Size is 320w x 256h]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK/CREATE] (A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\image")
    ; -------------------------------------------
    ThisPumProcessImageFolder := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\image"
    ; -------------------------------------------
    if !FileExist(ThisPumProcessImageFolder)
    {
      FileCreateDir, %ThisPumProcessImageFolder%
      Sleep, 10
    } ; if !FileExist(ThisPumProcessImageFolder)
    ; -------------------------------------------
    ; [CHECK/CREATE] (A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\image")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CONVERT] (bg_Selected_Png) to (bg_Selected_Bmp)
    ; -------------------------------------------
    bg_Selected_Bmp := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\image\bg_Selected_Bmp.bmp"
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
    Image_In  := bg_Selected_Png
    Image_Out := bg_Selected_Bmp
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -define png:color-type=6 """ Image_In """ """ Image_Out """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    ; [CONVERT] (bg_Selected_Png) to (bg_Selected_Bmp)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\bg_Selected_Png.png"]
    ; -------------------------------------------
    if FileExist(bg_Selected_Png)
    {
      FileDelete, %bg_Selected_Png%
    } ; [End] if FileExist(PumBgPngTemp)
    ; -------------------------------------------
    ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\bg_Selected_Png.png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return bg_Selected_Bmp
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
