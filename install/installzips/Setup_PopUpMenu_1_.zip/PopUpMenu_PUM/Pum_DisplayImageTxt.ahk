﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Crop.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\l_543.ahk ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_DisplayImageTxt(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [START UP]  Vars
    ; -------------------------------------------
    UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
    XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
    XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
    ; -------------------------------------------
    Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
    Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
    bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
    Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
    Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
    Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
    Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
    ; -------------------------------------------
    Mobile_OnOff             := DataArray.362.24 ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
    Mobile_TextColor_HexColor := DataArray.362.25 ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    Mobile_BgColor_HexColor   := DataArray.362.26 ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
    XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
    XmlBgType          := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
    BgColor_Opicity     := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
    ; -------------------------------------------
    ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
    Color_Array := Pum_ColorVarConvert("HexColor", Mobile_TextColor_HexColor, DataArray)
    Mobile_TextColor_GridNum      := Color_Array.2
    ; -------------------------------------------
    ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
    Color_Array := Pum_ColorVarConvert("HexColor", Mobile_BgColor_HexColor, DataArray)
    Mobile_BgColor_GridNum      := Color_Array.2
    ; -------------------------------------------
    ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
    Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
    Pum_BgColor_GridNum      := Color_Array.2
    ; -------------------------------------------
    bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Selected_Fit     := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
  } ; End [START UP] Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(ScriptType, "Color") == 0) ; Color panel Not Displayed
  {
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Sanding_Man
    global n_543 := 0 ; Start Frame Number
    global s_543 := 1 ; Show
    SetTimer, l_543, 100 ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Sanding_Man
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
    Pum_W := XmlColumnsX * XmlIconSize
    Pum_H := XmlRowsY * XmlIconSize
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
    ;
    ; -------------------------------------------
    if (bg_Image_Type == "")
    {
      bg_Image_Type := "C"
      DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (ImageTxt_[W,H]), (ImageTxt_Gui_[X,Y]) | [CREATE] (File_Image[.png]) (File_Image_Bg[.png])
    if (bg_Image_Type == "C")
    {
      ; ------------------------------------------- Crop
      if !FileExist(Temp_Selected_Gui)
      {
        FileCopy, %bg_Selected_Gui%, %Temp_Selected_Gui%, 1
        Sleep, 10
      }
      ; -------------------------------------------
      File_Image := ThisPumProcessFolder "\image\File_Image.png"
      FileDelete, %File_Image%
      Crop_Array := [Pum_Gui_W, Pum_Gui_H, Pum_Gui_X, Pum_Gui_Y, Temp_Selected_Gui, File_Image]
      Image_Crop(Crop_Array) ; [ImageOut_W, ImageOut_H, Position_X, Position_Y, ImageIn, ImageOut] > 1 / 0
      ; -------------------------------------------
      WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_Gui_W, Pum_Gui_H) ; OuterWin_W, OuterWin_H, InnerWin_W, InnerWin_H > [Max_W, Max_H]
      ImageTxt_W := WinInWin_Array.1
      ImageTxt_H := WinInWin_Array.2
      ; -------------------------------------------
      Image_ResizePng(ImageTxt_W, ImageTxt_H, File_Image, File_Image) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; ------------------------------------------- Crop
    }
    else if (bg_Image_Type == "F")
    {
      ; ------------------------------------------- Fit
      if !FileExist(Temp_Selected_Fit)
      {
        FileCopy, %bg_Selected_Fit%, %Temp_Selected_Fit%, 1
        Sleep, 10
      }
      ; -------------------------------------------
      File_Image := ThisPumProcessFolder "\image\File_Image.png"
      FileDelete, %File_Image%
      FileCopy, %Temp_Selected_Fit%, %File_Image%, 1
      Sleep, 10
      ; -------------------------------------------
      Gui, ImageSize:Add, Picture, hwndJustForSize, %File_Image%
      ControlGetPos, , , ImageTxt_W, ImageTxt_H, , ahk_id %JustForSize%
      ; ------------------------------------------- Fit
    }
    ; -------------------------------------------
    ImageTemp := "C:\Program Files\PopUpMenu_PUM\image\pum\Pum_" Pum_BgColor_GridNum "_100.png"
    File_Image_Bg := ThisPumProcessFolder "\image\File_Image_Bg.png"
    FileDelete, %File_Image_Bg%
    Image_ResizePng(ImageTxt_W, ImageTxt_H, ImageTemp, ImageTxt_Bg) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    if (ImageTxt_W > ImageTxt_H)
    {
      ; -------------------------------------------
      ImageTxt_Gui_X := 0
      ImageTxt_Gui_Y := (300 - ImageTxt_H) / 2
      ; -------------------------------------------
    } ; End (ImageTxt_W > ImageTxt_H)
    ; -------------------------------------------
    else if (ImageTxt_W < ImageTxt_H)
    {
      ; -------------------------------------------
      ImageTxt_Gui_X := (300 - ImageTxt_W) / 2
      ImageTxt_Gui_Y := 0
      ; -------------------------------------------
    } ; End (ImageTxt_W < ImageTxt_H)
    ; -------------------------------------------
    else if (ImageTxt_W == ImageTxt_H)
    {
      ; -------------------------------------------
      ImageTxt_Gui_X := 0
      ImageTxt_Gui_Y := 0
      ; -------------------------------------------
    } ; End (ImageTxt_W == ImageTxt_H)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (ImageTxt_[W,H]), (ImageTxt_Gui_[X,Y]) | [CREATE] (File_Image[.png]) (File_Image_Bg[.png])
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (ColorTxt_[W,H]), (ColorTxt_Gui_[X,Y]) | [CREATE] (File_Color[.png]) (File_Color_Bg[.png])
    WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_Gui_W, Pum_Gui_H) ; OuterWin_W, OuterWin_H, InnerWin_W, InnerWin_H > [Max_W, Max_H]
    ColorTxt_W := WinInWin_Array.1
    ColorTxt_H := WinInWin_Array.2
    ;
    if (BgColor_Opicity == 0)
    {
      ImageTemp := "C:\Program Files\PopUpMenu_PUM\image\pum\Pum_XX_0.png"
    }
    else
    {
      ImageTemp := "C:\Program Files\PopUpMenu_PUM\image\pum\Pum_" Pum_BgColor_GridNum "_" BgColor_Opicity ".png"
    }
    ; -------------------------------------------
    File_Color_Bg := ThisPumProcessFolder "\image\File_Color_Bg.png"
    FileDelete, %File_Color_Bg%
    Image_ResizePng(ColorTxt_W, ColorTxt_H, ImageTemp, File_Color_Bg) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    if (ColorTxt_W > ColorTxt_H)
    {
      ; -------------------------------------------
      ColorTxt_Gui_X := 0
      ColorTxt_Gui_Y := (300 - ColorTxt_H) / 2
      ; -------------------------------------------
    } ; End (ColorTxt_W > ColorTxt_H)
    ; -------------------------------------------
    else if (ColorTxt_W < ColorTxt_H)
    {
      ; -------------------------------------------
      ColorTxt_Gui_X := (300 - ColorTxt_W) / 2
      ColorTxt_Gui_Y := 0
      ; -------------------------------------------
    } ; End (ColorTxt_W < ColorTxt_H)
    ; -------------------------------------------
    else if (ColorTxt_W == ColorTxt_H)
    {
      ; -------------------------------------------
      ColorTxt_Gui_X := 0
      ColorTxt_Gui_Y := 0
      ; -------------------------------------------
    } ; End (ColorTxt_W == ColorTxt_H)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (ColorTxt_[W,H]), (ColorTxt_Gui_[X,Y]) | [CREATE] (File_Color[.png]) (File_Color_Bg[.png])
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (CenterIco_[I,X,Y]) (MobileTxt_[I,X,Y]) (MobileBak_[I,X,Y])
    CenterIco_I := "C:\Program Files\PopUpMenu_PUM\image\pum\Pum_Icon.png"
    MobileTxt_I := "C:\Program Files\PopUpMenu_PUM\image\pum\Mobile_T_" Mobile_TextColor_GridNum "_" UserLang ".png"
    MobileBak_I := "C:\Program Files\PopUpMenu_PUM\image\pum\Mobile_B_" Mobile_BgColor_GridNum "_" UserLang ".png"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] (CenterIco_[I,X,Y]) (MobileTxt_[I,X,Y]) (MobileBak_[I,X,Y])
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CREATE] (Temp_Display_Txt_Img.png) (Temp_Display_Txt_Col.png)
    FileDelete, %Temp_Display_Txt_Img%
    FileDelete, %Temp_Display_Txt_Col%
    ; -------------------------------------------
    if (Mobile_OnOff == "0") ; (1 = On, 0 = Off)
    {
      ; -------------------------------------------
      CenterIco_X := ImageTxt_Gui_X + 10
      CenterIco_Y := ImageTxt_Gui_Y + 10
      Array_Img_Mobile := [300, 300, Temp_Display_Txt_Img, File_Image_Bg, ImageTxt_Gui_X, ImageTxt_Gui_Y, File_Image, ImageTxt_Gui_X, ImageTxt_Gui_Y, CenterIco_I, CenterIco_X, CenterIco_Y]
      ; -------------------------------------------
      CenterIco_X := ColorTxt_Gui_X + 10
      CenterIco_Y := ColorTxt_Gui_Y + 10
      Array_Col_Mobile := [300, 300, Temp_Display_Txt_Col, File_Color_Bg, ColorTxt_Gui_X, ColorTxt_Gui_Y, CenterIco_I, CenterIco_X, CenterIco_Y]
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      CenterIco_X := ImageTxt_Gui_X + 10
      CenterIco_Y := ImageTxt_Gui_Y + 10
      MobileTxt_X := ImageTxt_Gui_X + 53
      MobileTxt_Y := ImageTxt_Gui_Y + 56      
      MobileBak_X := ImageTxt_Gui_X + 53
      MobileBak_Y := ImageTxt_Gui_Y + 56
      Array_Img_Mobile := [300, 300, Temp_Display_Txt_Img, File_Image_Bg, ImageTxt_Gui_X, ImageTxt_Gui_Y, File_Image, ImageTxt_Gui_X, ImageTxt_Gui_Y, CenterIco_I, CenterIco_X, CenterIco_Y, MobileBak_I, MobileBak_X, MobileBak_Y, MobileTxt_I, MobileTxt_X, MobileTxt_Y]
      ; -------------------------------------------
      CenterIco_X := ColorTxt_Gui_X + 10
      CenterIco_Y := ColorTxt_Gui_Y + 10
      MobileTxt_X := ColorTxt_Gui_X + 53
      MobileTxt_Y := ColorTxt_Gui_Y + 56      
      MobileBak_X := ColorTxt_Gui_X + 53
      MobileBak_Y := ColorTxt_Gui_Y + 56
      Array_Col_Mobile := [300, 300, Temp_Display_Txt_Col, File_Color_Bg, ColorTxt_Gui_X, ColorTxt_Gui_Y, CenterIco_I, CenterIco_X, CenterIco_Y, MobileBak_I, MobileBak_X, MobileBak_Y, MobileTxt_I, MobileTxt_X, MobileTxt_Y]
      ; -------------------------------------------
    }
    ; -------------------------------------------
    Image_Combine(Array_Img_Mobile) ; > Image_Out
    Image_Combine(Array_Col_Mobile) ; > Image_Out
    ; -------------------------------------------
    FileDelete, %File_Image_Bg%
    FileDelete, %File_Color_Bg%
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CREATE] (Temp_Display_Txt_Img.png) (Temp_Display_Txt_Col.png)
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Sanding_Man
    global s_543 := 0 ; Hide
    SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
    global ShowAnimationChange := 0
    Sleep, 110
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Sanding_Man
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DISPLAY] (Message Image 8)
    if (XmlBgType == 1) ; [BG with Image 1 / BG with Color 2]
    {
      GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Img% ; (254_1)(Obj_MsgImg300x300)
      DataArray.254.3 := Temp_Display_Txt_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
    }
    else if (XmlBgType == 2) ; [BG with Image 1 / BG with Color 2]
    {
      GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Col% ; (254_1)(Obj_MsgImg300x300)
      DataArray.254.3 := Temp_Display_Txt_Col ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DISPLAY] (Message Image 8)
  } ; End if (InStr(ScriptType, "Color") == 0) ; Color panel Not Displayed
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum_DisplayImageTxt(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
