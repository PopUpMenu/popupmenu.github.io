﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ResizeImg(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
{
  ; -------------------------------------------
  if FileExist(ImageIn)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Image Size
    ; -------------------------------------------
    Gui, ImageSize:Add, Picture, hwndJustForSize, %ImageIn% ; (368_5)(Selected Pum Background [Full Path])
    ControlGetPos, , , This_W, This_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (This_W != Resize_W or This_H != Resize_H)
    {
      ; -------------------------------------------
      Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
      ; -------------------------------------------
      RunThis := """" Support_magick """ convert """ ImageIn """ -resize " Resize_W "x" Resize_H "! """ ImageOut """"
      Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
      RunWait, %RunThis%, , Hide
      ; -------------------------------------------
		} ; if (This_W != Resize_W or This_H != Resize_H)
		else ; No Change
		{
			ImageOut := ImageIn
		}
  }
  ; -------------------------------------------
  return ImageOut
  ; -------------------------------------------
} ; End Image_ResizeImg(Resize_W, Resize_H, Image_In) ; > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
