#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\XmlWrite.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FixXmlArray(FixThisArray, FixThisXml) ; > FixThisArray
{
  ; -------------------------------------------
  CK_Line_20 := FixThisArray.20
  ; -------------------------------------------
  if (StrLen(CK_Line_20) == 15) ; Error
	{
		; -------------------------------------------
    CK_Line_39 := FixThisArray.39
	  CK_Line_39 := StrReplace(CK_Line_39, A_Space, "")
		; -------------------------------------------
		New_Line_20 := CK_Line_20 CK_Line_39
		; -------------------------------------------
    FixThisArray.RemoveAt(20) ; (361)(10)(FixThisArray)
    FixThisArray.InsertAt(20, New_Line_20) ; (361)(10)(FixThisArray)
		; -------------------------------------------
		CK_Line_21 := FixThisArray.21
		while (CK_Line_21 != "  </background>")
		{
			FixThisArray.RemoveAt(21) ; (361)(10)(FixThisArray)
			CK_Line_21 := FixThisArray.21
		}
	  ; -------------------------------------------
		XmlWrite(FixThisArray, FixThisXml) ; Array_PumXml, ThisPumXml > [0,1] 1 = Ok , 0 Xml Error
		; -------------------------------------------
	}
	; -------------------------------------------
	return FixThisArray
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
