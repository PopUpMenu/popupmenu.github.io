﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
; -------------------------------------------
ClipBoardType = 0
"empty"
; -------------------------------------------
ClipBoardType = 2
"object"
; -------------------------------------------
ClipBoardType = 1
"integer"
"float"
"number"
"space"
"tab"
"time"
"string"
"folder"
"image"
"document"
"webpage"
"file"
; -------------------------------------------
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
VarIsType(ThisVar) ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
{
  ; -------------------------------------------
  ; https://www.autohotkey.com/docs/commands/IfIs.htm
  ; -------------------------------------------
  ReturnArray := ["UNKNOWN"]
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; (Pulgin_powerpoint_clipboard.ahk)
  ; Must Be Running
  File_ClipBoardType := A_AppData "\PopUpMenu_PUM\system\ClipBoardType.txt"
  if FileExist(File_ClipBoardType)
  {
    FileReadLine, ClipBoardType, %File_ClipBoardType%, 1
  }
  ; -------------------------------------------
  if (ClipBoardType == 0)
  {
    ReturnArray := ["empty"]
  }
  else if (ClipBoardType == 2)
  {
    ReturnArray := ["object"]
  }
  else
  {
    ; -------------------------------------------
    if ThisVar is integer
    {
      ; -------------------------------------------
      ReturnArray := ["integer", ThisVar]
      ; -------------------------------------------
    }
    else if ThisVar is float
    {
      ; -------------------------------------------
      ReturnArray := ["float", ThisVar]
      ; -------------------------------------------
    }
    else if ThisVar is number
    {
      ; -------------------------------------------
      ReturnArray := ["number", ThisVar]
      ; -------------------------------------------
    }
    else if ThisVar is space
    {
      if (ThisVar == A_Space)
      {
        ; -------------------------------------------
        ReturnArray := ["space"]
        ; -------------------------------------------
      }
      else if (ThisVar == A_Tab)
      {
        ; -------------------------------------------
        ReturnArray := ["tab"]
        ; -------------------------------------------
      }
    }
    else if ThisVar is time
    {
      ; -------------------------------------------
      ReturnArray := ["time", ThisVar]
      ; -------------------------------------------
    }
    else if FileExist(ThisVar)
    {
      ; -------------------------------------------
      SplitPath, ThisVar, ThisFileExtName, ThisFolder, ThisExt, ThisFileName, ThisDrive
      StringLower, ThisExt, ThisExt
      ; -------------------------------------------
      if (ThisExt == "")
      {
        ReturnArray := ["folder", ThisFolder]
      }
      else if (ThisExt == "apng" or ThisExt == "avif" or ThisExt == "bmp" or ThisExt == "gif" or ThisExt == "ico" or ThisExt == "jfif" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "svg" or ThisExt == "tif" or ThisExt == "tiff" or ThisExt == "webp")
      {
        ReturnArray := ["image", ThisExt]
      }
      else if (ThisExt == "doc" or ThisExt == "docx" or ThisExt == "odt" or ThisExt == "pdf" or ThisExt == "xls" or ThisExt == "xlsx" or ThisExt == "ods" or ThisExt == "ppt" or ThisExt == "pptx" or ThisExt == "txt" or ThisExt == "xml")
      {
        ReturnArray := ["document", ThisExt]
      }
      else if (ThisExt == "HTML" or ThisExt == "HTM")
      {
        ReturnArray := ["webpage", ThisExt]
      }
      else
      {
        ReturnArray := ["file", ThisExt]
      }
    }
    else if (StrLen(ThisVar) > 0)
    {
      ; -------------------------------------------
      IsString := 0
      ; -------------------------------------------
      KeyListArray := ["~", "``", "!", "@", "#", "£", "€", "$", "¢", "¥", "§", "%", "°", "^", "&", "*", "(", ")", "-", "_", "+", "=", "{", "}", "[", "]", "|", "\", "/", ":", ";", """", "'", "<", ">", ",", ".", "?", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "Q", "q", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "W", "w", "X", "x", "Y", "y", "Z", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      ; -------------------------------------------
      Array_Len := KeyListArray.MaxIndex() ; Highest Length
      for Index, ThisKey in KeyListArray
      {
        if (InStr(ThisVar, ThisKey) > 0)
        {
          ReturnArray := ["string", ThisVar]
        }
      }
    }
  }
  ; -------------------------------------------
  return ReturnArray
  ; -------------------------------------------
} ; [End] VarIsType(ThisVar) ; > the Type of ThisVar
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
