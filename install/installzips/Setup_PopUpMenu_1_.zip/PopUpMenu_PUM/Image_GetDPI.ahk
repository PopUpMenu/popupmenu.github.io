﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_DPI_Functions.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FGP_Init()
{
  static PropTable
  if (!PropTable)
	{
    PropTable := {Name: {}, Num: {}}, Gap := 0
    oShell := ComObjCreate("Shell.Application")
    oFolder := oShell.NameSpace(0)
    while (Gap < 11)
    if (PropName := oFolder.GetDetailsOf(0, A_Index - 1))
		{
      PropTable.Name[PropName] := A_Index - 1
      PropTable.Num[A_Index - 1] := PropName
      Gap := 0
    }
    else
		{
      Gap++
    }
  }
  return PropTable
}
; -------------------------------------------
FGP_Value(FilePath, Property)
{
  static PropTable := FGP_Init()
  if ((PropNum := PropTable.Name[Property] != "" ? PropTable.Name[Property] : PropTable.Num[Property] ? Property : "") != "")
	{
    SplitPath, FilePath, FileName, DirPath
    oShell := ComObjCreate("Shell.Application")
    oFolder := oShell.NameSpace(DirPath)
    oFolderItem := oFolder.ParseName(FileName)
    if (PropVal := oFolder.GetDetailsOf(oFolderItem, PropNum))
		{
      return PropVal
		}
		else
		{
      return 0
    }
  }
  return -1
}
; -------------------------------------------
Image_GetDPI(FilePath) ; FilePath > DPI
{
	; -------------------------------------------
  pToken := Gdip_Startup()
  pBitmap := Gdip_CreateBitmapFromFile(FilePath)
  pGraphics := Gdip_GraphicsFromImage(pBitmap)
  DPI := Gdip_GetDpiX(pGraphics)
  Gdip_DeleteGraphics(pGraphics)
  Gdip_DisposeImage(pBitmap)
  Gdip_Shutdown(pToken)
	; -------------------------------------------
	return DPI
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
