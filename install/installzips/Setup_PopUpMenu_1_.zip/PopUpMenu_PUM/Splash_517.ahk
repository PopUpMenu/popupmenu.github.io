﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (517)(01)(Splash Anamated: Installing Continues Folder Icons)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Breaktime := A_TickCount + 120000 ; 2 Minutes > ExitApp
; -------------------------------------------
; This Splash Animation Ran In
; Image_PathFolderOrName.ahk
; PopUpMenu_Start
; -------------------------------------------
ColorTrans := "000000" ; Black
; -------------------------------------------
; Anamation
; -------------------------------------------
ImageName := 517
ImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
ProcessImagePath := "C:\Program Files\PopUpMenu_PUM\image\ico"
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; User Language [GET] (UserLang)
; -------------------------------------------
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
; -------------------------------------------
if FileExist(File_UserLang)
{
  FileReadLINE, UserLang, %File_UserLang%, 1
}
if (UserLang == "")
{
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileDelete, %File_UserLang%
    Sleep, 100
  } ; [End] if FileExist(File_UserLang)
  ; -------------------------------------------
  if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
  {
    ; -------------------------------------------
    UserLang := "de"
    ; -------------------------------------------
  } ; [End] German (de)
  ; -------------------------------------------
  else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] English (en)
  ; -------------------------------------------
  else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
  {
    ; -------------------------------------------
    UserLang := "es"
    ; -------------------------------------------
  } ; [End] Spanish (es)
  ; -------------------------------------------
  else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
  {
    ; -------------------------------------------
    UserLang := "fr"
    ; -------------------------------------------
  } ; [End] French (fr)
  ; -------------------------------------------
  else if (A_Language == "0410" or A_Language == "0810")
  {
    ; -------------------------------------------
    UserLang := "it"
    ; -------------------------------------------
  } ; [End] Italian (it)
  ; -------------------------------------------
  else if (A_Language == "0415")
  {
    ; -------------------------------------------
    UserLang := "pl"
    ; -------------------------------------------
  } ; [End] Polish (pl)
  ; -------------------------------------------
  else if (A_Language == "0416" or A_Language == "0816")
  {
    ; -------------------------------------------
    UserLang := "pt"
    ; -------------------------------------------
  } ; [End] Portuguese (pt)
  ; -------------------------------------------
  else if (A_Language == "0419")
  {
    ; -------------------------------------------
    UserLang := "ru"
    ; -------------------------------------------
  } ; [End] Russian (ru)
  ; -------------------------------------------
  else if (A_Language == "041d" or A_Language == "081d")
  {
    ; -------------------------------------------
    UserLang := "sv"
    ; -------------------------------------------
  } ; [End] Swedish (sv)
  ; -------------------------------------------
  else if (A_Language == "041f")
  {
    ; -------------------------------------------
    UserLang := "tr"
    ; -------------------------------------------
  } ; [End] Turkish (tr)
  ; -------------------------------------------
  else ; English (en)
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] else ; English (en)
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
} ; [End] if (UserLang == "")
; -------------------------------------------
; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
Gui, Margin , 0, 0
Gui, Add, Picture, x0 y0 w230 h180 vImgBg, %ImagePath%\(%ImageName%)_%UserLang%.png
Gui, Add, Picture, x64 y114 w142 h14 vSplash_Animate, %ProcessImagePath%\ProcessBar_1.png
Gui, Color, %ColorTrans%
Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, %ColorTrans%,
Gui, Show
SetTimer, Splash_Animate, 200
Return
; -------------------------------------------
Splash_Animate:
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; If These Script are Running ExitApp
  ; -------------------------------------------
  ScriptPath_1 := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
  ScriptPath_2 := "C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk"
  ; -------------------------------------------
  ScriptRunning_1 := Script_Running(ScriptPath_1)
  ScriptRunning_2 := Script_Running(ScriptPath_2)
  ; -------------------------------------------
  if (ScriptRunning_1 > 0 or ScriptRunning_2 > 0)
  {
    ; -------------------------------------------
    SetTimer, Splash_Animate, Off
    ExitApp
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; If These Script are Running ExitApp
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  if (A_TickCount > Breaktime)
  {
    SetTimer, Splash_Animate, Off
    ExitApp
  }
  ; -------------------------------------------
  if (Image_Num == "")
  {
    Image_Num := 2
  }
  if (Image_Num > 9)
  {
    Image_Num := 1
  }
  else
  {
    Image_Num := Image_Num + 1
  }
  ThisImage := ProcessImagePath "\ProcessBar_" Image_Num ".png"
  GuiControl, , Splash_Animate, %ThisImage%
  GuiControl, Show, Splash_Animate
  ; -------------------------------------------
} ; [End] Splash_Animate:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
