﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;HQEsXMryLJZfe8msZ8HAnRgxXMDA3aU7EsGu97DaPmT7
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_GridCheck.ahk
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
#Include C:\Program Files\PopUpMenu_PUM\XmlValidate.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Run(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ToolTip
  ; -------------------------------------------
  ; ToolBox v2.85
  ; ahk_class #32770
  ; ahk_exe pum_photoshop.exe
  ; -------------------------------------------
  SetTitleMatchMode, 1 ; must start with
  ;~ SetTitleMatchMode, 2 ; anywhere inside
  ;~ SetTitleMatchMode, 3 ; exactly match
  if WinExist("ToolBox v2.85" . "ahk_class #32770")
  {
    WinClose
  }
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  DataArray.367.1  := "" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  DataArray.367.2  := "" ; (367_2)(AppProcessExtName [Name,Ext])
  DataArray.367.3  := "" ; (367_3)(AppProcessClass)
  DataArray.367.4  := "" ; (367_4)(AppProcessTitle)
  DataArray.367.5  := "" ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
  DataArray.367.6  := "" ; (367_6)(AppProcesssVersion)
  DataArray.367.7  := "" ; (367_7)(AppProcesssPID)
  ; -------------------------------------------
  DataArray.307.2  := "" ; (307_2)(Url_Address)
  DataArray.307.4 := "" ; (307_4)(Url_Title [Web Page Title])
  ; -------------------------------------------
  AppProcessName := ""
  AppProcessExtName := ""
  AppProcessClass := ""
  AppProcessTitle := ""
  AppProcessPathNameExt := ""
  AppProcesssVersion := ""
  AppProcesssPID := ""
  Url_Address := ""
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Get Current Process Information
  ; -------------------------------------------
  WinGetTitle,    AppProcessTitle, A
  WinGetClass,    AppProcessClass, A
  WinGet,         AppProcessExtName,     ProcessName, A
  SplitPath,      AppProcessExtName,   , , , AppProcessName
  WinGet,         AppProcessPathNameExt, ProcessPath , A
  FileGetVersion, AppProcesssVersion,    %AppProcessPathNameExt%
  WinGet, AppProcesssPID, PID , A
  ; -------------------------------------------
  StringLower, AppProcessName, AppProcessName
  AppProcessName := StrReplace(AppProcessName, A_Space, "")
  ; -------------------------------------------
  SplitPath, AppProcessPathNameExt, AppProcessNameExt
  ; -------------------------------------------
  StringLower, Lower_AppProcessNameExt, AppProcessNameExt
  ; -------------------------------------------
  StringLower, Lower_AppProcessClass, AppProcessClass
  ; -------------------------------------------
  StringLower, Lower_AppProcessTitle, AppProcessTitle
  ; -------------------------------------------
  ; Get Current Process Information
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if in Windows Desktop
  ; -------------------------------------------
  if (InStr(AppProcessName, "sidebar") > 0)
  {
    ; -------------------------------------------
    AppProcessName        := "windows"
    AppProcessExtName     := "windows"
    AppProcessClass       := "windows"
    AppProcessTitle       := "windows"
    AppProcessPathNameExt := "windows"
    AppProcesssVersion    := "windows"
    AppProcesssPID        := "windows"
    ; -------------------------------------------
  } ; [End] else if (InStr(AppProcessName, "sidebar") > 0)
  else if (InStr(Lower_AppProcessClass, "workerw") > 0)
  {
    ; -------------------------------------------
    AppProcessName        := "windows"
    AppProcessExtName     := "windows"
    AppProcessClass       := "windows"
    AppProcessTitle       := "windows"
    AppProcessPathNameExt := "windows"
    AppProcesssVersion    := "windows"
    AppProcesssPID        := "windows"
    ; -------------------------------------------
  } ; [End] else if (InStr(Lower_AppProcessClass, "workerw") > 0)
  else if (InStr(Lower_AppProcessClass, "progman") > 0)
  {
    ; -------------------------------------------
    AppProcessName        := "windows"
    AppProcessExtName     := "windows"
    AppProcessClass       := "windows"
    AppProcessTitle       := "windows"
    AppProcessPathNameExt := "windows"
    AppProcesssVersion    := "windows"
    AppProcesssPID        := "windows"
    ; -------------------------------------------
  }  ; [End] else if (InStr(Lower_AppProcessClass, "progman") > 0)
  else if (InStr(Lower_AppProcessClass, "shell_traywnd") > 0)
  {
    ; -------------------------------------------
    AppProcessName        := "windows"
    AppProcessExtName     := "windows"
    AppProcessClass       := "windows"
    AppProcessTitle       := "windows"
    AppProcessPathNameExt := "windows"
    AppProcesssVersion    := "windows"
    AppProcesssPID        := "windows"
    ; -------------------------------------------
  } ; [End] else if (InStr(Lower_AppProcessClass, "shell_traywnd") > 0)
  else if (InStr(Lower_AppProcessTitle, "tor browser") > 0)
  {
    ; -------------------------------------------
    AppProcessName := "torbrowser"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; Check if in Windows Desktop
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [SET] Path_PumExe
  ; -------------------------------------------
  File_PumExe  := "pum_" AppProcessName ".exe"
  Name_PumProcess := File_PumExe
  Name_PumProcess := StrReplace(Name_PumProcess, "pum_", "")
  Name_PumProcess := StrReplace(Name_PumProcess, ".exe", "")
  ; -------------------------------------------
  ;
  Path_PumExe := ""
  ;
  ; -------------------------------------------
  if (IsInternetBrowser(AppProcessName, AppProcessClass, AppProcessTitle) == 1)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Internet Browser Application Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [GET] Value (290)(04)(Obj_BrowserPum_UseCommonBrowser [0,1,2])
    ; -------------------------------------------
    File_InternetBrowserPum := A_Appdata "\PopUpMenu_PUM\system\InternetBrowserPum.txt"
    ; -------------------------------------------
    FileReadLine, UseCommonBrowser, %File_InternetBrowserPum%, 1
    ; -------------------------------------------
    if (UseCommonBrowser == "")
    {
      ; -------------------------------------------
      UseCommonBrowser := 1
      DataArray.290.2  := 1
      ; -------------------------------------------
      FileDelete, %File_InternetBrowserPum%
      Sleep, 250
      FileEncoding, UTF-8
      FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
      Sleep, 250
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (UseCommonBrowser != 1 && UseCommonBrowser != 2)
    {
      ; -------------------------------------------
      UseCommonBrowser := 1
      DataArray.290.2  := 1
      ; -------------------------------------------
      FileDelete, %File_InternetBrowserPum%
      Sleep, 250
      FileEncoding, UTF-8
      FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
      Sleep, 250
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      DataArray.290.2 := UseCommonBrowser
      ; -------------------------------------------
    }
    ; [GET] Value (290)(04)(Obj_BrowserPum_UseCommonBrowser [0,1,2])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Internet Browser Application Active]
      ;
      ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      Folder_PumSettings := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\settings"
      Path_PumExe           := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
      ; -------------------------------------------
    } ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
  } ; [Internet Browser Application Active]
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (Path_PumExe == "") ; [Any Other Application Active] -OR- [UseCommonBrowser = 2][Each Browser Different pum]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Any Other Application (Non-Internet Browser) Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    Folder_PumSettings := A_AppData "\PopUpMenu_PUM\pums\" Name_PumProcess "\settings"
    Path_PumExe        := A_AppData "\PopUpMenu_PUM\pums\" Name_PumProcess "\" File_PumExe
    ; -------------------------------------------
  } ; [Any Other Application (Non-Internet Browser) Active]
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if !FileExist(Path_PumExe) ; pum NOT Exist [RUN] Default pum
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; pum NOT Exist [RUN] Default pum
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    Folder_PumSettings := A_AppData "\PopUpMenu_PUM\pums\pumdefault\settings"
    Path_PumExe := A_AppData "\PopUpMenu_PUM\pums\pumdefault\pum_pumdefault.exe"
    File_PumExe        := "pum_pumdefault.exe"
    Name_PumProcess    := "pumdefault"
    ; -------------------------------------------
  } ; pum NOT Exist [RUN] Default pum
  ; -------------------------------------------
  File_PumXml       := Folder_PumSettings "\toolbox0.xml"
  ; -------------------------------------------
  ; [SET] Path_PumExe
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [RUN] Path_PumExe
  Process, Exist, %File_PumExe%
  if (ErrorLevel == 0) ; pum DOES NOT Exist
  {
    ; -------------------------------------------
    Run, %Path_PumExe%,,, Priority_PumExe
    Process, Priority, %Priority_PumExe%, High
    WinSet, AlwaysOnTop, On, ahk_exe %File_PumExe%
    ; -------------------------------------------
  } ; [End] if (ErrorLevel == 0) ; pum DOES NOT Exist
  ; [RUN] Path_PumExe
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Pum_GridCheck
  Pum_GridCheck(Name_PumProcess, 0) ; AppName [Lowercase], MakeIt [0/1]
  ; -------------------------------------------
  ; Pum_GridCheck
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Delete Extra XML files
  ; -------------------------------------------
  Loop Files, %Folder_PumSettings%\*.xml
  {
    ; -------------------------------------------
    ThisFilePath := A_LoopFileFullPath
    SplitPath, ThisFilePath, , , , OutNameNoExt
    ; -------------------------------------------
    if (OutNameNoExt != "toolbox0")
    {
      FileDelete, %ThisFilePath%
      Sleep, 10
    }
  } ; [End] Loop Files, %Folder_PumSettings%\*.xml
  ; -------------------------------------------
  ; Delete Extra XML files
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Xml Structure (if) InCorrect Copy From Backup
  ; -------------------------------------------
  Ok_XmlValidate := XmlValidate(File_PumXml) ; > [1, 0]
  ; -------------------------------------------
  if (Ok_XmlValidate == 0) ; Pum is Not Valid, Copy From Backup
  {
    ; -------------------------------------------
    SplitPath, File_PumXml, , Folder_PumXml
    ; -------------------------------------------
    File_Backup_PumXml := StrReplace(File_PumXml, "\pums", "\pums_backup")
    ; -------------------------------------------
    FileCopy, %File_Backup_PumXml%, %File_PumXml%, 1
    Sleep, 100
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; Xml Structure (if) InCorrect Copy From Backup
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Array_FromFile(File_PumXml), Set Vars (DataArray.361.10) (DataArray.361.9)
  ; -------------------------------------------
  ThisPumProcessArray := Array_FromFile(File_PumXml)
  DataArray.361.10 := ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
  DataArray.361.9 := File_PumXml ; (361)(09)(File_PumXml [toolbox0] [Full File Path])
  ; -------------------------------------------
  ; Array_FromFile(File_PumXml), Set Vars (DataArray.361.10) (DataArray.361.9)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Wait until pum Exist
  ; -------------------------------------------
  BreakTime := A_TickCount + 3000
  Process, Exist, %File_PumExe%
  ; -------------------------------------------
  while (ErrorLevel == 0) ; pum DOES NOT Exist
  {
    ; -------------------------------------------
    Sleep, 1
    ; -------------------------------------------
    if (A_TickCount > BreakTime)
    {
      break
    } ; [End] if (A_TickCount > BreakTime_1)
    ; -------------------------------------------
    Process, Exist, %File_PumExe%
    if (ErrorLevel == 0) ; pum (Exist)
    {
      break
    }
    ; -------------------------------------------
  } ; [End] while (ErrorLevel == 0) ; pum DOES NOT Exist
  ; -------------------------------------------
  ; Wait until pum Exist
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [SET] DataArray Process information
  ; -------------------------------------------
  DataArray.367.1  := AppProcessName ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  DataArray.367.2  := AppProcessExtName ; (367_2)(AppProcessExtName [Name,Ext])
  DataArray.367.3  := AppProcessClass ; (367_3)(AppProcessClass)
  DataArray.367.4  := AppProcessTitle ; (367_4)(AppProcessTitle)
  DataArray.367.5  := AppProcessPathNameExt ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
  DataArray.367.6  := AppProcesssVersion ; (367_6)(AppProcesssVersion)
  DataArray.367.7  := AppProcesssPID ; (367_7)(AppProcesssPID)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Name_PumProcess   := File_PumExe
  Name_PumProcess   := StrReplace(Name_PumProcess, "pum_", "")
  Name_PumProcess   := StrReplace(Name_PumProcess, ".exe", "")
  Folder_PumProcess := A_AppData "\PopUpMenu_PUM\pums\" Name_PumProcess
  File_PumXml    := A_AppData "\PopUpMenu_PUM\pums\" Name_PumProcess "\settings\toolbox0.xml"
  ; -------------------------------------------
  FileDelete, %Folder_PumProcess%\*.ini
  ; -------------------------------------------
  if (File_PumExe == "pum_pumdefault.exe")
  {
    DataArray.301.11  := 0 ; (301_11)(Key_ShortcutInAppPum [0,1])
  }
  else
  {
    DataArray.301.11  := 1 ; (301_11)(Key_ShortcutInAppPum [0,1])
    DataArray.367.10  := AppProcessPathNameExt ; (367_10)(Empty)
  }
  ; -------------------------------------------
  DataArray.361.7  := File_PumExe ; (361)(7)(File_PumExe [Pum Name and Extension])
  DataArray.361.9  := File_PumXml ; (361)(9)(File_PumXml [Full File Path])
  DataArray.361.15 := Name_PumProcess ; (361)(15)(Name_PumProcess [NO pum_,Path,Ext])
  DataArray.361.8  := Folder_PumProcess ; (361)(8)(Folder_PumProcess [Pum Folder Path])
  ; -------------------------------------------
  ; [SET] DataArray Process information
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [WRITE] A_AppData "\PopUpMenu_PUM\system\File_ActiveApp.txt"
  ; This is Needed for Shortcut_Run.ahk
  ; -------------------------------------------
  File_ActiveApp := A_AppData "\PopUpMenu_PUM\system\File_ActiveApp.txt"
  FileDelete, %File_ActiveApp%
  ; -------------------------------------------
  Line_1 := AppProcessName "`r`n"
  Line_2 := Lower_AppProcessNameExt "`r`n"
  Line_3 := AppProcessClass "`r`n"
  Line_4 := AppProcessTitle "`r`n"
  Line_5 := AppProcessPathNameExt "`r`n"
  Line_6 := AppProcesssVersion "`r`n"
  Line_7 := AppProcesssPID "`r`n"
  Line_8 := Url_Address "`r`n"
  Line_9 := 0 "`r`n" ; ContextClicked
  ; -------------------------------------------
  This_File := FileOpen(File_ActiveApp, "rw")
  This_File.Write(Line_1)
  This_File.Write(Line_2)
  This_File.Write(Line_3)
  This_File.Write(Line_4)
  This_File.Write(Line_5)
  This_File.Write(Line_6)
  This_File.Write(Line_7)
  This_File.Write(Line_8)
  This_File.Write(Line_9)
  This_File.Close()
  ; -------------------------------------------
  ; [WRITE] A_AppData "\PopUpMenu_PUM\system\File_ActiveApp.txt"
  ; This is Needed for Shortcut_Run.ahk
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum_Run
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
