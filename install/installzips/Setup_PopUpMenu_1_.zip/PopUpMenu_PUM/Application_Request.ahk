﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
#Include C:\Program Files\PopUpMenu_PUM\Email_Send.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
#Include C:\Program Files\PopUpMenu_PUM\f_004.ahk ; (004_1)(Obj_ok)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Application_Request(DataArray) ; > DataArray
{
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ;
  ; -------------------------------------------
  AppName     := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  ; -------------------------------------------
  AppProcessClass    := DataArray.367.3 ; (367_3)(AppProcessClass)
  AppProcessPathNameExt := DataArray.367.5 ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcesssVersion  := DataArray.367.6 ; (367_6)(AppProcesssVersion)
  ; -------------------------------------------
  if (AppName != "windows")
  {
    ; -------------------------------------------
    HasConnection := InternetConnectCheck()
    ; -------------------------------------------
    if (HasConnection == 1)  ; Has Internet Connection
    {
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Writing Request
      global n_524 := 1 ; Start Frame Number
      global s_524 := 1 ; Show
      SetTimer, l_524, 100 ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Writing Request
      ;
      End_Time := A_TickCount + 4000
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      Email_Subject := "(App Request)(" AppName ")(" UserLang ")"
      ; -------------------------------------------
      Email_Body := "`n`n"
      Email_Body := Email_Body "User Lang: " UserLang "`n"
      Email_Body := Email_Body "Process Name: " AppName "`n"
      Email_Body := Email_Body "Version: " AppProcesssVersion "`n"
      Email_Body := Email_Body "Class: " AppProcessClass "`n"
      Email_Body := Email_Body "File Name : " AppProcessPathNameExt "`n"
      ; -------------------------------------------
      Email_Send(Email_Subject, Email_Body)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      ; (380_2)(Application Request [System Text File Path])
      AppRequest := AppName "_" UserLang
      File_AppRequest := A_AppData "\PopUpMenu_PUM\system\File_AppRequest.txt"
      ; -------------------------------------------
      FileEncoding, UTF-8
      FileAppend, %AppRequest%`n, %File_AppRequest% ; 20127 us-ascii US-ASCII (7-bit)
      ; -------------------------------------------
      ;
      while (A_TickCount < End_Time)
      {
      }
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Writing Request
      global s_524 := 0 ; Hide
      SetTimer, l_524, Off ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Writing Request
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("137", "SE12", 1, DataArray) ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
      ;
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
