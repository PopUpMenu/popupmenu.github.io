﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_FileDelete.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_LButton(DataArray) ; > DataArray
{
  ; -------------------------------------------
  XmlShortcutLineNum := 0
  ; -------------------------------------------
  WinGet, ThisPumProcessExe, ProcessName , ahk_class TfrmToolbox
  ; -------------------------------------------
  ;
  if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; User LButton Clicked OutSide of Pum
    ; -------------------------------------------
    Var_Acitve := WinActive("ahk_class TfrmToolbox")
    ; -------------------------------------------
    if (Var_Acitve == "0x0") ; Application Does (Exist), Application NOT (Active)
    {
      ; -------------------------------------------
      Process, Close, %ThisPumProcessExe%
      ; -------------------------------------------
      Pum_FileDelete(ThisPumProcessExe)
      ; -------------------------------------------
      return
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; User LButton Clicked OutSide of Pum
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Current Mouse Position
    ; -------------------------------------------
    CoordMode, Mouse, Window
    ; -------------------------------------------
    MouseGetPos , Pum_MousePosX, Pum_MousePosY, , , 1
    ; -------------------------------------------
    ; Get Current Mouse Position
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Close ThisPumProcessExe
    ; -------------------------------------------
    Process, Close, %ThisPumProcessExe%
    ; -------------------------------------------
    Pum_FileDelete(ThisPumProcessExe)
    ; -------------------------------------------
    ; Close ThisPumProcessExe
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; -------------------------------------------
    SplitPath, ThisPumProcessExe, , , , ThisPumProcessName
    ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
    ThisPumProcessFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
    ; -------------------------------------------
    ThisPumProcessArray := DataArray.361.10
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Check_Len := ThisPumProcessArray.MaxIndex() ; Highest Length
    if (Check_Len < 38 or Check_Len == "")
    {
      ; -------------------------------------------
      ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
      ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
      DataArray.361.10 := ThisPumProcessArray
      ; -------------------------------------------
    } ; if (Check_Len < 38 or Check_Len == "")
    ; -------------------------------------------
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; XML Line Strings from (ThisPumProcessArray)
    ; -------------------------------------------
    XmlLine3  := ThisPumProcessArray.3
    XmlLine9  := ThisPumProcessArray.9
    XmlLine19 := ThisPumProcessArray.19
    XmlLine20 := ThisPumProcessArray.20
    ; -------------------------------------------
    ; XML Line Strings from (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlRowsY)
    ; -------------------------------------------
    FindItem := "rows"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlRowsY := ThisVar
    ; -------------------------------------------
    ; (XmlRowsY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlColumnsX)
    ; -------------------------------------------
    FindItem := "columns"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlColumnsX := ThisVar
    ; -------------------------------------------
    ; (XmlColumnsX)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlIconSize)
    ; -------------------------------------------
    FindItem := "iconsize"
    XmlString := XmlLine9 ; <displaymode type="0" iconsize="48" />
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlIconSize := ThisVar
    ; -------------------------------------------
    ; (XmlIconSize)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; -------------------------------------------
    XmlShortcutPosX := Pum_MousePosX / XmlIconSize
    XmlShortcutPosY := Pum_MousePosY / XmlIconSize
    ; -------------------------------------------
    XmlShortcutPosX := XmlShortcutPosX + 1
    XmlShortcutPosY := XmlShortcutPosY + 1
    ; -------------------------------------------
    XmlShortcutPosX := Floor(XmlShortcutPosX)
    XmlShortcutPosY := Floor(XmlShortcutPosY)
    ; -------------------------------------------
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (XmlShortcutPosX > XmlColumnsX) ; Mouse is Outside Pum (Right)
    {
      XmlShortcutPosX := 0
    }
    else if (XmlShortcutPosX < 0) ; Mouse is Outside Pum (Left)
    {
      XmlShortcutPosX := 0
    }
    ; -------------------------------------------
    if (XmlShortcutPosY > XmlRowsY) ; Mouse is Outside Pum (Bottom)
    {
      XmlShortcutPosY := 0
    }
    else if (XmlShortcutPosY < 0) ; Mouse is Outside Pum (Top)
    {
      XmlShortcutPosY := 0
    }
    ; -------------------------------------------
    if (XmlShortcutPosX == 0 or XmlShortcutPosY == 0)
    {
      XmlShortcutLineNum := 0
    }
    else ; Check for Empty Grid [SET] (370_1)(XML_SC Line Number [-1 = Not in Pum] [0 = Empty Grid] [# = XML Line Number])
    {
      ; -------------------------------------------
      CheckFor := "<shortcut row=""" XmlShortcutPosY """ column=""" XmlShortcutPosX """"
      XmlShortcutLineNum := 0
      ; -------------------------------------------
      for Index, ThisLine in ThisPumProcessArray
      {
        if (InStr(ThisLine, CheckFor) > 0)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Set (XmlShortcutLineNum)
          ; Run Script
          ; -------------------------------------------
          XmlShortcutLineNum := Index
          ; -------------------------------------------
          ScriptNameExt := ThisPumProcessArray[Index + 1]
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>ahk\","")
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>","")
          ScriptNameExt := StrReplace(ScriptNameExt, "</filename>","")
          ScriptNameExt := StrReplace(ScriptNameExt, A_Space ,"")
          XmlScriptPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\ahk\" ScriptNameExt
          ; -------------------------------------------
          Run, %XmlScriptPath%
          ; -------------------------------------------
          ; Set (XmlShortcutLineNum)
          ; Run Script
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          break
          ; -------------------------------------------
        } ; End if (InStr(ThisLine, CheckFor) > 0)
      } ; [End] for Index, ThisLine in ThisPumProcessArray
    } ; [End] Check for Empty Grid [SET] (370_1)(XML_SC Line Number [-1 = Not in Pum] [0 = Empty Grid] [# = XML Line Number])
  } ; [End] if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  ; -------------------------------------------
  DataArray.370.1 := XmlShortcutLineNum ; (370)(01)(XmlShortcutLineNum [XML Line Number])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; [End] Shortcut_LButton() ; > XmlShortcutLineNum
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
