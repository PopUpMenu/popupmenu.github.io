﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; apng bmp gif ico jpg jpeg png svg tif tiff webp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Convert(Image_In, Image_Out) ; Image_In, Image_Out > Image_Out
{
  ; -------------------------------------------
  Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
  ; -------------------------------------------
  ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
  SplitPath, Image_In, , , Image_In_Ext
  StringLower, Image_In_Ext, Image_In_Ext
  ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
  SplitPath, Image_Out, FileNameExt, Image_Out_Folder, Image_Out_Ext, Image_Out_FileName
  StringLower, Image_Out_Ext, Image_Out_Ext
  ; -------------------------------------------
  ; (apng) bmp (gif) (ico) jpg jpeg png svg tif tiff webp
  if (Image_In_Ext == "apng" or Image_In_Ext == "gif" or Image_In_Ext == "ico")
  {
    ; -------------------------------------------
    Image_Out := Image_Out_Folder "\" Image_Out_FileName ".png"
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -define png:color-type=6 """ Image_In """ """ Image_Out """" ; OK
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    Image_Out_0 := Image_Out_Folder "\" Image_Out_FileName "-0.png"
    ; -------------------------------------------
    if (Image_In_Ext == "ico")
    {
      if FileExist(Image_Out_0)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Get Largest "png" Image
        ; -------------------------------------------
        Num := 0
        ThisImage := Image_Out_Folder "\" Image_Out_FileName "-" Num ".png"
        LargestWidth := 0
        ; -------------------------------------------
        while FileExist(ThisImage)
        {
          ; -------------------------------------------
          Gui, ImageSize:Add, Picture, hwndJustForSize, %ThisImage%
          ControlGetPos, , , Img_W, Img_H, , ahk_id %JustForSize%
          ; -------------------------------------------
          if (Img_W > LargestWidth)
          {
            ; -------------------------------------------
            LargestImage := ThisImage
            LargestWidth := Img_W
            ; -------------------------------------------
          }
          ; -------------------------------------------
          Num := Num + 1
          ThisImage := Image_Out_Folder "\" Image_Out_FileName "-" Num ".png"
          ; -------------------------------------------
        } ; [End] while FileExist(ThisImage)
        ; -------------------------------------------
        Num := 0
        ThisImage := Image_Out_Folder "\" Image_Out_FileName "-" Num ".png"
        ; -------------------------------------------
        while FileExist(ThisImage)
        {
          ; -------------------------------------------
          if (ThisImage == LargestImage)
          {
            ; -------------------------------------------
            FileMove, %LargestImage%, %Image_Out%, 1
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            FileDelete, %ThisImage%
            ; -------------------------------------------
          }
          ; -------------------------------------------
          Num := Num + 1
          ThisImage := Image_Out_Folder "\" Image_Out_FileName "-" Num ".png"
          ; -------------------------------------------
        } ; [End] while FileExist(ThisImage)
        ; -------------------------------------------
      } ; [End] if (Image_In_Ext == "ico")
    } ; [End] if FileExist(Image_Out_0)
    else if (Image_In_Ext != "ico")
    {
      Image_Out_0 := Image_Out_Folder "\" Image_Out_FileName "-0.png"
      FileMove, %Image_Out_0%, %Image_Out%, 1
      Image_Out_N := Image_Out_Folder "\" Image_Out_FileName "-*.png"
      FileDelete, %Image_Out_N%
    } ; [End] else if (Image_In_Ext != "ico")
  } ; [End] if (Image_In_Ext == "apng" or Image_In_Ext == "gif" or Image_In_Ext == "ico")
  ; -------------------------------------------
  ; (apng) bmp (gif) (ico) jpg jpeg png (svg) tif tiff (webp)
  else if (Image_In_Ext == "svg")
  {
    Image_Out := Image_Out_Folder "\" Image_Out_FileName ".png"
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -background none -define png:color-type=6 """ Image_In """ """ Image_Out """"  ; OK
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (Image_In_Ext == "webp")
  {
    Image_Out := Image_Out_Folder "\" Image_Out_FileName ".png"
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -define png:color-type=6 """ Image_In """ """ Image_Out """"  ; OK
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    ; Sometimes a webp file is like a gif with mulitible images in the file
    if !FileExist(Image_Out)
    {
      Image_Out_0 := Image_Out_Folder "\" Image_Out_FileName "-0.png"
      FileMove, %Image_Out_0%, %Image_Out%, 1
      Image_Out_N := Image_Out_Folder "\" Image_Out_FileName "-*.png"
      FileDelete, %Image_Out_N%
    }
  }
  ; -------------------------------------------
  ; (apng) (bmp) (gif) (ico) jpg jpeg png (svg) tif tiff (webp)
  else if (Image_In_Ext == "bmp")
  {
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -type TrueColor """ Image_In """ """ Image_Out """" ; OK
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; (apng) (bmp) (gif) (ico) (jpg) (jpeg) png (svg) (tif) (tiff) (webp)
  else if (Image_In_Ext == "jpg" or Image_In_Ext == "jpeg" or Image_In_Ext == "tif" or Image_In_Ext == "tiff")
  {
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -colorspace sRGB -type truecolor """ Image_In """ """ Image_Out """" ; OK
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; (apng) (bmp) (gif) (ico) (jpg) (jpeg) (png) (svg) (tif) (tiff) (webp)
  else if (Image_In_Ext == "png")
  {
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert -define png:color-type=6 """ Image_In """ """ Image_Out """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else
  {
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert """ Image_In """ """ Image_Out """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return Image_Out
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
