﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Select_FileFolder.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_068(DataArray) ; (068_1)(Obj_RwhUrl_OpenWith)
{
  ; -------------------------------------------
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  ; -------------------------------------------
  if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
    Selected_Array := Select_FileFolder(DataArray.365.2, "Application", "", ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Selected_File := Selected_Array.1
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if FileExist(Selected_File)
  {
    ; -------------------------------------------
    ; [Value] [Modify]
    ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
    SplitPath, Selected_File, , , FileExt ; (305_5)(Selected Opening Application [Full File Path])
    StringLower, FileExt, FileExt
    ; -------------------------------------------
    if (FileExt == "exe")
    {
      if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray.305.5 := Selected_File ; (305_5)(Rwh_OpeningApp [Full File Path])
        ; -------------------------------------------
        if (DataArray.305.5 == DataArray.305.6) ; (305_5)(Rwh_OpeningApp [Full File Path])/(305_6)(Rwh_DefaultApp [Full File Path])
        {
          ; 1 = Is Use Default
          DataArray.305.8 := 1 ; (305_8)(Rwh_UseAppDefault [0/1])
        }
        else
        {
          ; 0 = DO NOT Use Default
          DataArray.305.8 := 0 ; (305_8)(Rwh_UseAppDefault [0/1])
        }
        ; -------------------------------------------
        DataArray := _S1_C(DataArray)
        DataArray := _S2_H(DataArray)
        DataArray := _S3_S(DataArray)
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
    } ; [End] if (FileExt == "exe")
    ; -------------------------------------------
  } ; [End] if FileExist(Selected_File)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
