﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Kill()
{
  ; -------------------------------------------
  ; Close All Running Pums
  DetectHiddenWindows, On
  WinGet, List, List, ahk_class TfrmToolbox
  scripts := ""
  Loop % List
  {
    ; -------------------------------------------
    WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    if (InStr(ThisPumProcessExe, "pum_") > 0) ; (This Process is a pum)
    {
      Process, Close, %ThisPumProcessExe%
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

