﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_099() ; (099_1)(Obj_PopUpMenuWebLink)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if There ia a Internet Connection
  ; -------------------------------------------
  HasConnection := InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
  ; -------------------------------------------
  ; Check if There ia a Internet Connection
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (HasConnection == 1) ; Internet Connection OK
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Current PopUpMenu Web Site
    ; -------------------------------------------
    PopupmenuSiteDomain := "https://popupmenu.github.io"
    ; -------------------------------------------
    ; Get Current PopUpMenu Web Site
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Open Current PopUpMenu Web Site
      ; -------------------------------------------
      File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
      FileReadLine, UserLang, %File_UserLang%, 1
      if (UserLang != "de" && UserLang != "en" && UserLang != "es" && UserLang != "fr" && UserLang != "it" && UserLang != "pl" && UserLang != "pt" && UserLang != "ru" && UserLang != "sv" && UserLang != "tr")
      {
        UserLang := "en"
      }
      PopUpMenuWebSite := PopupmenuSiteDomain "/" UserLang ".html"
      Run, %PopUpMenuWebSite%,,, Priority_PopUpMenuWebSite
      Process, Priority, %Priority_PopUpMenuWebSite%, High
      ; -------------------------------------------
      ; Open Current PopUpMenu Web Site
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Close GUI
      ; -------------------------------------------
      if (WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") or WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI"))
      {
        Pum_Close(DataArray) ; > Nothing
      }
      ; -------------------------------------------
      ; Close GUI
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Close pum Process
      ; -------------------------------------------
      WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
      if (InStr(ThisPumProcessExe, "pum_") != 0) ; pum Exist
      {
        ; -------------------------------------------
        Process, Close, %ThisPumProcessExe%
        ; -------------------------------------------
        Pum_FileDelete(ThisPumProcessExe)
        ; -------------------------------------------
        DataArray.367.1 := "" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        DataArray.367.2 := "" ; (367_2)(AppProcessExtName [Name,Ext])
        DataArray.367.3 := "" ; (367_3)(AppProcessClass)
        DataArray.367.4 := "" ; (367_4)(AppProcessTitle)
        DataArray.367.5 := "" ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
        DataArray.367.6 := "" ; (367_6)(AppProcesssVersion)
        DataArray.367.7 := "" ; (367_7)(AppProcesssPID)
        ; -------------------------------------------
      } ; [End] if (InStr(ThisPumProcessExe, "pum_") != 0) ; pum Exist
      ; -------------------------------------------
      ; Close pum Process
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
    ; -------------------------------------------
  } ; [End] if (HasConnection == 1) ; Internet Connection OK
  ; -------------------------------------------
} ; [End] (099_1)(Obj_PopUpMenuWebLink)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
