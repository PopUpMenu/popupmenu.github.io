﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Gui_TextWidth(String, GuiFont, FontSize)
{
  While !TW
  {
    Gui StringWidth:Font, s%FontSize%, %GuiFont%
    Gui StringWidth:Add, Text, R1, %String%
    GuiControlGet, T, StringWidth:Pos, Static1
    Gui StringWidth:Destroy
  } ; End While !TW
  return TW
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
