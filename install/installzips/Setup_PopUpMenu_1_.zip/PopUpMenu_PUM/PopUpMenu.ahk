﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;~ #Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; this the Main Program Starter
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; PopUpMenu_1_DayStamp.zip
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
CheckHasAdminRights()
{
  ; -------------------------------------------
  TOKEN_QUERY := 0x0008
  TokenElevationTypeDefault := 1
  TokenElevationTypeFull := 2
  TokenElevationTypeLimited := 3
  TokenType := 8
  TokenElevationType := 18
  ; -------------------------------------------
  TokenInformationClass := TokenElevationType
  DllCall("SetLastError", "UInt", 0)
  ret := DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
  ; -------------------------------------------
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "Int", 0, "Int", 0, "UIntP", ReturnLength)
  ; -------------------------------------------
  sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "UIntP", elevationType, "Int", sizeof_elevationType, "UIntP", ReturnLength)
  ; -------------------------------------------
  if (elevationType=TokenElevationTypeDefault)
  {
    ThisUserHasAdminRights := 0
  }
  else if (elevationType=TokenElevationTypeFull)
  {
    ThisUserHasAdminRights := 1
  }
  else if (elevationType=TokenElevationTypeLimited)
  {
    ThisUserHasAdminRights := 1
  }
  else
  {
    ThisUserHasAdminRights := 0
  }
  if (hToken)
  {
    DllCall("CloseHandle", "UInt", hToken)
  }
  ; -------------------------------------------
  return ThisUserHasAdminRights
  ; -------------------------------------------
} ; [End] CheckHasAdminRights()
; -------------------------------------------
Splash_Script(Img_Num, Sleep_Time) ; Img_Num ("Off"/Number), Sleep_Time > Nothing
{
  ; -------------------------------------------
  if (Sleep_Time == "")
  {
    Sleep_Time := 0
  }
  ; -------------------------------------------
  if (Img_Num == "Off")
  {
    ; -------------------------------------------
    ; Closes Any Splash Image
    ; Does Not Need DataArray
    ; -------------------------------------------
    if (Sleep_Time > 0)
    {
      Sleep, %Sleep_Time%
    }
    ; -------------------------------------------
    SplashImage, Off
    ; -------------------------------------------
    Splash_Script_Path := "C:\Program Files\PopUpMenu_PUM\Splash_5*.ahk"
    Loop, Files, %Splash_Script_Path%, R  ; Recurse into subfolders.
    {
      Splash_Script := A_LoopFileFullPath
      Script_Close(Splash_Script)
    } ; End Loop, Files, %iconcache_Path%, R
    ; -------------------------------------------
  } ; End (Img_Num == "Off")
  else ; run Splash
  {
    ; -------------------------------------------
    if (SubStr(Img_Num, 1, 1) == "4") ; Error Splash
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; User Language [GET] (UserLang)
      ; -------------------------------------------
      File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileReadLINE, UserLang, %File_UserLang%, 1
      }
      if (UserLang == "")
      {
        ; -------------------------------------------
        if FileExist(File_UserLang)
        {
          FileDelete, %File_UserLang%
          Sleep, 100
        } ; [End] if FileExist(File_UserLang)
        ; -------------------------------------------
        if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
        {
          ; -------------------------------------------
          UserLang := "de"
          ; -------------------------------------------
        } ; [End] German (de)
        ; -------------------------------------------
        else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] English (en)
        ; -------------------------------------------
        else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
        {
          ; -------------------------------------------
          UserLang := "es"
          ; -------------------------------------------
        } ; [End] Spanish (es)
        ; -------------------------------------------
        else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
        {
          ; -------------------------------------------
          UserLang := "fr"
          ; -------------------------------------------
        } ; [End] French (fr)
        ; -------------------------------------------
        else if (A_Language == "0410" or A_Language == "0810")
        {
          ; -------------------------------------------
          UserLang := "it"
          ; -------------------------------------------
        } ; [End] Italian (it)
        ; -------------------------------------------
        else if (A_Language == "0415")
        {
          ; -------------------------------------------
          UserLang := "pl"
          ; -------------------------------------------
        } ; [End] Polish (pl)
        ; -------------------------------------------
        else if (A_Language == "0416" or A_Language == "0816")
        {
          ; -------------------------------------------
          UserLang := "pt"
          ; -------------------------------------------
        } ; [End] Portuguese (pt)
        ; -------------------------------------------
        else if (A_Language == "0419")
        {
          ; -------------------------------------------
          UserLang := "ru"
          ; -------------------------------------------
        } ; [End] Russian (ru)
        ; -------------------------------------------
        else if (A_Language == "041d" or A_Language == "081d")
        {
          ; -------------------------------------------
          UserLang := "sv"
          ; -------------------------------------------
        } ; [End] Swedish (sv)
        ; -------------------------------------------
        else if (A_Language == "041f")
        {
          ; -------------------------------------------
          UserLang := "tr"
          ; -------------------------------------------
        } ; [End] Turkish (tr)
        ; -------------------------------------------
        else ; English (en)
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] else ; English (en)
        ; -------------------------------------------
        FileEncoding, UTF-8 ; UTF-8
        FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
        ; -------------------------------------------
      } ; [End] if (UserLang == "")
      ; -------------------------------------------
      ; User Language [GET] (UserLang)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      File_SplashActive := A_AppData "\PopUpMenu_PUM\system\File_SplashActive.txt"
      FileAppend, 1, %File_SplashActive%, UTF-8
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      SetTitleMatchMode, 1
      WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
      WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      Splash_Image := "C:\Program Files\PopUpMenu_PUM\image\gui\(" Img_Num ")_" UserLang ".png" ; (365_2)(Current User language)
      SplashImage, %Splash_Image%, b
      Sleep, %Sleep_Time%
      SplashImage, Off
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileDelete, %File_SplashActive%
      ; -------------------------------------------
    } ; End (SubStr(Img_Num, 1, 1) == "4") ; Error Splash
    else ; Informational Message
    {
      ; -------------------------------------------
      Splash_Script := "C:\Program Files\PopUpMenu_PUM\Splash_" Img_Num ".ahk"
      ; -------------------------------------------
      Run, %Splash_Script%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (Sleep_Time > 0)
      {
        ; -------------------------------------------
        Sleep, %Sleep_Time%
        ; -------------------------------------------
        Script_Close(Splash_Script)
        ; -------------------------------------------
        Splash_Script_Path := "C:\Program Files\PopUpMenu_PUM\Splash_5*.ahk"
        Loop, Files, %Splash_Script_Path%, R  ; Recurse into subfolders.
        {
          Splash_Script := A_LoopFileFullPath
          Script_Close(Splash_Script)
        } ; End Loop, Files, %iconcache_Path%, R
        ; -------------------------------------------
      } ; End (Sleep_Time > 0)
    } ; End Informational Message
  } ; End run Splash
} ; End Splash_Script(Img_Num, Sleep_Time)
; -------------------------------------------
Script_Close(ScriptPath)
{
  ; -------------------------------------------
  SplitPath, ScriptPath, , , , ScriptNameNoExt
  ; -------------------------------------------
  DetectHiddenWindows, On
  WinGet, List, List, ahk_class AutoHotkey
  scripts := ""
  Loop % List
  {
    ; -------------------------------------------
    WinGetTitle, ThisScriptTitle, % "ahk_id" List%A_Index%
    WinGet, ThisScriptID, ID, %ThisScriptTitle%
    ; -------------------------------------------
    if (InStr(ThisScriptTitle, ScriptNameNoExt) > 0)
    {
      WinClose, ahk_id %ThisScriptID%
    } ; Loop % List
    ; -------------------------------------------
  }
} ; [End] Script_Close(ThisScript)
; -------------------------------------------
Script_Running(ScriptPath) ; Script_Running(ScriptPath) ; > [0,Number]
{
  ; -------------------------------------------
  ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
  SplitPath, ScriptPath, , ,  , ThisScript
  ; -------------------------------------------
  ScriptRunning := 0
  DetectHiddenWindows, On
  WinGet, ahk_list, List, ahk_class AutoHotkey
  ; -------------------------------------------
  Loop % ahk_list
  {
    ; -------------------------------------------
    WinGetTitle, ahk_win, % "ahk_id" ahk_list%A_Index%
    RegExMatch(ahk_win,"^.*?\.ahk",m)
    ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
    SplitPath, m, AhkName
    StringLower, AhkName, AhkName
    ; -------------------------------------------
    Check_AhkName := AhkName
    Check_AhkName := StrReplace(Check_AhkName, ".ahk", "")
    StringLower, ThisScript, ThisScript
    StringLower, Check_AhkName, Check_AhkName
    if (Check_AhkName == ThisScript)
    {
      ScriptRunning := ScriptRunning + 1
      break
    } ; End (AhkName == ThisScript)
    ; -------------------------------------------
  } ; End Loop % ahk_list
  ; -------------------------------------------
  return ScriptRunning
}
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Script_SysLoad   := "C:\Program Files\PopUpMenu_PUM\SysLoad.ahk"   ; Load 1
Script_SysConfig := "C:\Program Files\PopUpMenu_PUM\SysConfig.ahk" ; Load 2
Script_SysTray   := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"   ; Load 3
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
File_InternetConnectCheck := A_Temp "\internetconnectcheck.txt"
if FileExist(File_InternetConnectCheck)
{
  FileDelete, %File_InternetConnectCheck%
}
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if (Script_Running(Script_SysConfig) == 0 && Script_Running(Script_SysLoad) == 0) ; PopUpMenu is NOT Loading
{
  ; -------------------------------------------
  if (Script_Running(Script_SysTray) > 0) ; PopUpMenu is Running
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("518", 0)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    return
    ; -------------------------------------------
  }
  else ; PopUpMenu is NOT Running
  {
    ; -------------------------------------------
    HasAdminRights := CheckHasAdminRights()
    ; -------------------------------------------
    if (HasAdminRights == 1) ; User is Admin
    {
      ; -------------------------------------------
      Run, *RunAs C:\Program Files\PopUpMenu_PUM\SysLoad.ahk,,, Priority_PopUpMenuStart
      ; -------------------------------------------
      Process, Priority, %Priority_PopUpMenuStart%, High
      ; -------------------------------------------
      return
      ; -------------------------------------------
    } ; [End] if (HasAdminRights == 1) ; User is Admin
    else ; User is NOT Admin
    {
      ; -------------------------------------------
      Run, C:\Program Files\PopUpMenu_PUM\SysLoad.ahk,,, Priority_PopUpMenuStart
      ; -------------------------------------------
      Process, Priority, %Priority_PopUpMenuStart%, High
      ; -------------------------------------------
      return
      ; -------------------------------------------
    } ; [End] else ; User is NOT Admin
  } ; [End] else ; PopUpMenu is NOT Running
} ; [End] ; PopUpMenu is NOT Loading
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
