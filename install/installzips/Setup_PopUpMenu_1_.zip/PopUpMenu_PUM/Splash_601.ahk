﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
;~ #NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>z>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
; -------------------------------------------
if FileExist(File_UserLang)
{
  FileReadLINE, UserLang, %File_UserLang%, 1
}
; -------------------------------------------
if (UserLang == "")
{
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileDelete, %File_UserLang%
    Sleep, 100
  } ; [End] if FileExist(File_UserLang)
  ; -------------------------------------------
  if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
  {
    ; -------------------------------------------
    UserLang := "de"
    ; -------------------------------------------
  } ; [End] German (de)
  ; -------------------------------------------
  else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] English (en)
  ; -------------------------------------------
  else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
  {
    ; -------------------------------------------
    UserLang := "es"
    ; -------------------------------------------
  } ; [End] Spanish (es)
  ; -------------------------------------------
  else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
  {
    ; -------------------------------------------
    UserLang := "fr"
    ; -------------------------------------------
  } ; [End] French (fr)
  ; -------------------------------------------
  else if (A_Language == "0410" or A_Language == "0810")
  {
    ; -------------------------------------------
    UserLang := "it"
    ; -------------------------------------------
  } ; [End] Italian (it)
  ; -------------------------------------------
  else if (A_Language == "0415")
  {
    ; -------------------------------------------
    UserLang := "pl"
    ; -------------------------------------------
  } ; [End] Polish (pl)
  ; -------------------------------------------
  else if (A_Language == "0416" or A_Language == "0816")
  {
    ; -------------------------------------------
    UserLang := "pt"
    ; -------------------------------------------
  } ; [End] Portuguese (pt)
  ; -------------------------------------------
  else if (A_Language == "0419")
  {
    ; -------------------------------------------
    UserLang := "ru"
    ; -------------------------------------------
  } ; [End] Russian (ru)
  ; -------------------------------------------
  else if (A_Language == "041d" or A_Language == "081d")
  {
    ; -------------------------------------------
    UserLang := "sv"
    ; -------------------------------------------
  } ; [End] Swedish (sv)
  ; -------------------------------------------
  else if (A_Language == "041f")
  {
    ; -------------------------------------------
    UserLang := "tr"
    ; -------------------------------------------
  } ; [End] Turkish (tr)
  ; -------------------------------------------
  else ; English (en)
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] else ; English (en)
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
} ; [End] if (UserLang == "")
; -------------------------------------------
; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Vars
; -------------------------------------------
UninstallImage := A_Temp "\PopUpMenuTempFolder\UninstallPopUpMenu.png"
; -------------------------------------------
; Vars
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
Gui, Margin , 0, 0
; -------------------------------------------
Gui, Add, Picture, x0   y0   w250 h250 vImgBg, %UninstallImage%
; -------------------------------------------
Gui, Color, 000000
Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 000000,
Gui, Show
; -------------------------------------------
MsgBox, 4096, , %Msg%
Msg := ""
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Close scripts
; -------------------------------------------
ThisScript := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
DetectHiddenWindows, On
PostMessage, 0x111, 65305,,, %ThisScript% ahk_class AutoHotkey  ; Suspend
PostMessage, 0x111, 65306,,, %ThisScript% ahk_class AutoHotkey  ; Pause
WinClose, %ThisScript% ahk_class AutoHotkey
; -------------------------------------------
; Close scripts
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Remove All User Folders (pum) (Pictures) (Startmenu)
; Uninstall PopUpMenu
; -------------------------------------------
FilePath := A_AppData
SplitPath, FilePath, , , , , OutDrive
; -------------------------------------------
FilePath := OutDrive "\Users\*.*"
Array_PumFolder := ""
; -------------------------------------------
Loop Files, %FilePath%, D ; (Array_PumFolder) All User Pum Folder Array
{
  ; -------------------------------------------
  ThisFolderPath := A_LoopFileFullPath
  SplitPath, ThisFolderPath, , , , UserName
  ; -------------------------------------------
  ThisFile := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM"
  if FileExist(ThisFile)
  {
    FileRemoveDir, %ThisFile%, 1
    BreakTime := A_TickCount + 2000
    while FileExist(ThisFile)
    {
      Sleep, 100
      if (A_TickCount > BreakTime)
      {
        break
      }
    }
  }
  ; -------------------------------------------
  ThisFile := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)"
  if FileExist(ThisFile)
  {
    FileRemoveDir, %ThisFile%, 1
    BreakTime := A_TickCount + 2000
    while FileExist(ThisFile)
    {
      Sleep, 100
      if (A_TickCount > BreakTime)
      {
        break
      }
    }
  }
  ; -------------------------------------------
  ThisFile := OutDrive "\Users\" UserName "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\PopUpMenu"
  if FileExist(ThisFile)
  {
    FileRemoveDir, %ThisFile%, 1
    BreakTime := A_TickCount + 2000
    while FileExist(ThisFile)
    {
      Sleep, 100
      if (A_TickCount > BreakTime)
      {
        break
      }
    }
  }
  ; -------------------------------------------
  ThisFile := OutDrive "\Users\CaveMan\Desktop\PopUpMenu.lnk"
  if FileExist(ThisFile)
  {
    Filedelete, %ThisFile%
    BreakTime := A_TickCount + 2000
    while FileExist(ThisFile)
    {
      Sleep, 100
      if (A_TickCount > BreakTime)
      {
        break
      }
    }
  }
  ; -------------------------------------------
}
; -------------------------------------------
; Remove All User Folders (pum) (Pictures) (Startmenu)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Remove All Common Folders and Links
; -------------------------------------------
FileRemoveDir, %A_StartMenuCommon%\Programs\PopUpMenu
FileRemoveDir, %A_StartMenu%\Programs\PopUpMenu
; -------------------------------------------
;
; -------------------------------------------
FileDelete, %A_DesktopCommon%\PopUpMenu.lnk
FileDelete, %A_Desktop%\PopUpMenu.lnk
; -------------------------------------------
;
; -------------------------------------------
FileDelete, %A_DesktopCommon%\SetupPlugin_*.ahk
FileDelete, %A_Desktop%\SetupPlugin_*.ahk
; -------------------------------------------
;
; -------------------------------------------
FileRemoveDir, %A_DesktopCommon%\SetupFolder_PopUpMenu, 1
FileRemoveDir, %A_Desktop%\SetupFolder_PopUpMenu, 1
; -------------------------------------------
;
FileDelete, %A_DesktopCommon%\Setup_PopUpMenu_123.zip
FileDelete, %A_Desktop%\Setup_PopUpMenu_123.zip
; -------------------------------------------
;
; -------------------------------------------
FileRemoveDir, %A_Temp%\PopUpMenuTempFolder, 1
; -------------------------------------------
;
; -------------------------------------------
FileRemoveDir, C:\Program Files\PopUpMenu_PUM, 1
; -------------------------------------------
FileRemoveDir, %ThisFile%, 1
; -------------------------------------------
BreakTime := A_TickCount + 5000
while FileExist("C:\Program Files\PopUpMenu_PUM")
{
  Sleep, 100
  if (A_TickCount > BreakTime)
  {
    break
  }
}
; -------------------------------------------
ExitApp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
