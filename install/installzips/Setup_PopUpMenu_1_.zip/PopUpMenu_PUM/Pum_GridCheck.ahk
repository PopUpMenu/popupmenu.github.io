﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_GridCheck(AppName, MakeIt) ; AppName [Lowercase], MakeIt [0/1/2]
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; This Takes No time 0.0015 of 1 Second
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; MakeIt = 1 Delete Old (GridCheck.txt) (if Exist) Creat New (GridCheck.txt)
  ; MakeIt = 0 Check Grid
  ; Will Create a new "..\settings\GridCheck\GridCheck.txt"
  ; from "..\settings\toolbox0"
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\" AppName "\settings\toolbox0.xml"
  File_CurTxt := A_AppData "\PopUpMenu_PUM\pums\" AppName "\settings\GridCheck\GridCheck.txt"
  ; -------------------------------------------
  CheckFolder := A_AppData "\PopUpMenu_PUM\pums\" AppName "\settings\GridCheck"
  if !FileExist(CheckFolder)
  {
    FileCreateDir, %CheckFolder%
    Sleep,100
  }
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(ThisPumProcessXml)
  {
    ; -------------------------------------------
    if (MakeIt == 1)
    {
      ; -------------------------------------------
      if FileExist(File_CurTxt)
      {
        FileDelete, %File_CurTxt%
      }
      ; -------------------------------------------
      Array_CurXml := Array_FromFile(ThisPumProcessXml) ; > Array
      ; -------------------------------------------
      for Index, ThisLine in Array_CurXml
      {
        ; -------------------------------------------
        if (InStr(ThisLine, "<shortcut row=") > 0)
        {
          ; -------------------------------------------
          Pos_1 := InStr(ThisLine, """",,, 1)
          Pos_2 := InStr(ThisLine, """",,, 2)
          Len_Y := Pos_2 - Pos_1
          Len_Y := Len_Y - 1
          Pos_1 := Pos_1 + 1
          Grid_Y := SubStr(ThisLine, Pos_1, Len_Y)
          ; -------------------------------------------
          Pos_3 := InStr(ThisLine, """",,, 3)
          Pos_4 := InStr(ThisLine, """",,, 4)
          Len_X := Pos_4 - Pos_3
          Len_X := Len_X - 1
          Pos_3 := Pos_3 + 1
          Grid_X := SubStr(ThisLine, Pos_3, Len_X)
          ; -------------------------------------------
          ThisLine := Grid_X "|" Grid_Y
          FileEncoding, UTF-8
          FileAppend, %ThisLine%`n, %File_CurTxt% ; 20127 us-ascii US-ASCII (7-bit)
          ; -------------------------------------------
        } ; [End] if (InStr(ThisLine, "<shortcut row=") > 0)
        ; -------------------------------------------
      } ; [End] for Index, ThisLine in Array_CurXml
      ; -------------------------------------------            
    } ; [End] if (MakeIt == 1)
    else ; (MakeIt != 1)
    {
      ; -------------------------------------------
      if !FileExist(File_CurTxt)
      {
        ; -------------------------------------------
        if !FileExist(File_CurTxt)
        {
          ; -------------------------------------------
          Array_CurXml := Array_FromFile(ThisPumProcessXml) ; > Array
          ; -------------------------------------------
          for Index, ThisLine in Array_CurXml
          {
            ; -------------------------------------------
            if (InStr(ThisLine, "<shortcut row=") > 0)
            {
              ; -------------------------------------------
              Pos_1 := InStr(ThisLine, """",,, 1)
              Pos_2 := InStr(ThisLine, """",,, 2)
              Len_Y := Pos_2 - Pos_1
              Len_Y := Len_Y - 1
              Pos_1 := Pos_1 + 1
              Grid_Y := SubStr(ThisLine, Pos_1, Len_Y)
              ; -------------------------------------------
              Pos_3 := InStr(ThisLine, """",,, 3)
              Pos_4 := InStr(ThisLine, """",,, 4)
              Len_X := Pos_4 - Pos_3
              Len_X := Len_X - 1
              Pos_3 := Pos_3 + 1
              Grid_X := SubStr(ThisLine, Pos_3, Len_X)
              ; -------------------------------------------
              ThisLine := Grid_X "|" Grid_Y
              FileAppend, %ThisLine%`n, %File_CurTxt%, UTF-8
              ; -------------------------------------------
            } ; [End] if (InStr(ThisLine, "<shortcut row=") > 0)
            ; -------------------------------------------
          } ; [End] for Index, ThisLine in Array_CurXml
          ; -------------------------------------------
        } ; [End] if !FileExist(File_CurTxt)
        ; -------------------------------------------
      } ; [End] if !FileExist(File_CurTxt)
      else ; File_CurTxt (EXIST)
      {
        ; -------------------------------------------
        Array_CurTxt := Array_FromFile(File_CurTxt) ; > Array
        ; -------------------------------------------
        Array_ChkTxt := ""
        ; -------------------------------------------
        Array_CurXml := Array_FromFile(ThisPumProcessXml) ; > Array
        ; -------------------------------------------
        for Index, ThisLine in Array_CurXml ; [CREATE] Array_ChkTxt
        {
          ; -------------------------------------------
          if (InStr(ThisLine, "<shortcut row=") > 0)
          {
            ; -------------------------------------------
            Pos_1 := InStr(ThisLine, """",,, 1)
            Pos_2 := InStr(ThisLine, """",,, 2)
            Len_Y := Pos_2 - Pos_1
            Len_Y := Len_Y - 1
            Pos_1 := Pos_1 + 1
            Grid_Y := SubStr(ThisLine, Pos_1, Len_Y)
            ; -------------------------------------------
            Pos_3 := InStr(ThisLine, """",,, 3)
            Pos_4 := InStr(ThisLine, """",,, 4)
            Len_X := Pos_4 - Pos_3
            Len_X := Len_X - 1
            Pos_3 := Pos_3 + 1
            Grid_X := SubStr(ThisLine, Pos_3, Len_X)
            ; -------------------------------------------
            ThisGrid := Grid_X "|" Grid_Y
            Array_ChkTxt := Array_Add(Array_ChkTxt, ThisGrid, "End") ; ThisArray, AddThis, ThisPos > ThisArray
            ; -------------------------------------------
          } ; [End] if (InStr(ThisLine, "<shortcut row=") > 0)
          ; -------------------------------------------
        } ; [End] for Index, ThisLine in Array_CurXml
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        ArrayLen_CurTxt := Array_CurTxt.MaxIndex() ; Highest Length
        ArrayLen_CurTxt := ArrayLen_CurTxt - 1 ; Thie Last Line is Empty (Just a Return)
        GridPass := 0
        ; ------------------------------------------
        for Index_1, ThisGrid_1 in Array_ChkTxt
        {
          for Index_2, ThisGrid_2 in Array_CurTxt
          {
            ; -------------------------------------------
            if (ThisGrid_1 = ThisGrid_2)
            {
              GridPass := GridPass + 1
            } ; [End] if (ThisGrid_1 = ThisGrid_2)
            ; -------------------------------------------
          } ; [End] for Index_2, ThisGrid_2 in Array_CurTxt
        } ; [End] for Index_1, ThisGrid_1 in Array_ChkTxt
        ; -------------------------------------------
      } ; [End] else ; File_CurTxt (EXIST)
      ; -------------------------------------------
    } ; [End] else ; (MakeIt != 1)
    ; -------------------------------------------
  } ; [End] if FileExist(ThisPumProcessXml)
  ; -------------------------------------------
} ; [End] Pum_GridCheck(AppName)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
