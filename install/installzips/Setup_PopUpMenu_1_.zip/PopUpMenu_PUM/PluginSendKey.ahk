﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\VarIsType.ahk ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
=======================================
KeyArray = ["", "", etc]
=======================================
=======================================
SendCtrl(KeyArray)
---------------------------------------
FirstValue  "Clip"          > Clipboard is NOT empty
FirstValue  "ClipText"      > Clipboard Contains Text
FirstValue  "ClipObject"    > Clipboard Contains Object
---------------------------------------
FirstValue  "Select"        > Something is Selected
FirstValue  "SelectText"    > Text is Highlighted
FirstValue  "SelectObject"  > Objected is Selected
---------------------------------------
AnyPosition  "Shift"        > Send, Down at Array End Up
AnyPosition  "Alt"          > Send, Down at Array End Up
AnyPosition  "F1"           > Send Once
=======================================
=======================================
SendAlt(KeyArray)
---------------------------------------
FirstValue  "Clip"          > Clipboard is NOT empty
FirstValue  "ClipText"      > Clipboard Contains Text
FirstValue  "ClipObject"    > Clipboard Contains Object
---------------------------------------
FirstValue  "Select"        > Something is Selected
FirstValue  "SelectText"    > Text is Highlighted
FirstValue  "SelectObject"  > Objected is Selected
---------------------------------------
AnyPosition  "Sleep###"     > Sleep ### = Sleep Time
AnyPosition  "@_T"          > Click Center of Titlebar
AnyPosition  "Alt"          > Send Once
AnyPosition  "Enter"        > Send Once
AnyPosition  "Up"           > Send Once
AnyPosition  "Down"         > Send Once
AnyPosition  "Left"         > Send Once
AnyPosition  "Right"        > Send Once
AnyPosition  "Home"         > Send Once
AnyPosition  "End"          > Send Once
=======================================
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SendCtrl(KeyArray)
{
  ; -------------------------------------------
  BlockInput, On
  ; -------------------------------------------
  ThisPassed := 1
  ShiftDown := 0
  AltDown := 0
  ; -------------------------------------------
  FirstVar := KeyArray.1
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (InStr(FirstVar, "Clip") > 0)
  {
    ; -------------------------------------------
    KeyArray.RemoveAt(1)
    ; -------------------------------------------
    CheckClipArray := VarIsType(Clipboard) ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
    CheckClip := CheckClipArray.1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (CheckClip == "empty")
    {
      ThisPassed := 0
    } ; [End] if (CheckClip == "empty")
    ; -------------------------------------------
    else if (FirstVar == "ClipText")
    {
      if (CheckClip != "integer" && CheckClip != "float" && CheckClip != "number" && CheckClip != "space" && CheckClip != "tab" && CheckClip != "time" && CheckClip != "string")
      {
        ThisPassed := 0
      }
    } ; [End] if (FirstVar == "ClipText")
    else if (FirstVar == "ClipObject")
    {
      if (CheckClip != "object")
      {
        ThisPassed := 0
      } ; [End] if (CheckClip != "object")
    } ; [End] else if (FirstVar == "ClipObject")
  } ; [End] if (InStr(FirstVar, "Clip") > 0)
  ; -------------------------------------------
  else if (InStr(FirstVar, "Select") > 0)
  {
    ; -------------------------------------------
    KeyArray.RemoveAt(1)
    ; -------------------------------------------
    OldClip := Clipboard
    Clipboard :=
    Sleep, 100
    Send, {Ctrl Down}c{Ctrl Up}
    Sleep, 100
    ; -------------------------------------------
    CheckClipArray := VarIsType(Clipboard) ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
    CheckClip := CheckClipArray.1
    ; -------------------------------------------
    Sleep, 100
    Clipboard := OldClip
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (CheckClip == "empty")
    {
      ThisPassed := 0
    } ; [End] if (CheckClip == "empty")
    ; -------------------------------------------
    else if (FirstVar == "SelectText")
    {
      if (CheckClip != "integer" && CheckClip != "float" && CheckClip != "number" && CheckClip != "space" && CheckClip != "tab" && CheckClip != "time" && CheckClip != "string")
      {
        ThisPassed := 0
      }
    } ; [End] if (FirstVar == "SelectText")
    ; -------------------------------------------
    else if (FirstVar == "SelectObject")
    {
      if (CheckClip != "object")
      {
        ThisPassed := 0
      } ; [End] if (CheckClip != "object")
    } ; [End] else if (FirstVar == "SelectObject")
    ; -------------------------------------------
  } ; [End] else if (InStr(FirstVar, "Select") > 0)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (ThisPassed == 1)
  {
    ; -------------------------------------------
    Send, {Ctrl Down}
    ; -------------------------------------------
    for index, ThisKey in KeyArray
    {
      if (ThisKey == "Sleep")
      {
        SleepTime := StrReplace(ThisKey, "Sleep", "")
        Sleep, %SleepTime%
      }
      else if (ThisKey == "Shift")
      {
        ShiftDown := 1
        Send, {Shift Down}
      } ; [End] if (ThisKey == "Shift")
      else if (ThisKey == "Alt")
      {
        AltDown := 1
        Send, {Alt Down}
      } ; [End] if (ThisKey == "Alt")
      else if (ThisKey == "F1")
      {
        Send, {F1}
      } ; [End] if (ThisKey == "F1")
      else
      {
        Send, %ThisKey%
      } ; [End] else
    } ; [End] for index, ThisKey in KeyArray
    ; -------------------------------------------
    if (ShiftDown == 1)
    {
      Send, {Shift Up}
    } ; [End] if (ShiftDown == 1)
    ; -------------------------------------------
    if (AltDown == 1)
    {
      Send, {Alt Up}
    } ; [End] if (AltDown == 1)
    ; -------------------------------------------
    Send, {Ctrl Up}
    ; -------------------------------------------
  } ; [End] if (ThisPassed == 1)
  ; -------------------------------------------
  BlockInput, Off
  ; -------------------------------------------
} ; [End] SendCtrl(KeyArray)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SendAlt(KeyArray)
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  BlockInput, On
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  ThisPassed := 1
  KeyNum := 0
  ; -------------------------------------------
  FirstVar := KeyArray.1
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (InStr(FirstVar, "Clip") > 0)
  {
    ; -------------------------------------------
    KeyArray.RemoveAt(1)
    ; -------------------------------------------
    CheckClipArray := VarIsType(Clipboard) ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
    CheckClip := CheckClipArray.1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (CheckClip == "empty")
    {
      ThisPassed := 0
    } ; [End] if (CheckClip == "empty")
    ; -------------------------------------------
    else if (FirstVar == "ClipText")
    {
      if (CheckClip != "integer" && CheckClip != "float" && CheckClip != "number" && CheckClip != "space" && CheckClip != "tab" && CheckClip != "time" && CheckClip != "string")
      {
        ThisPassed := 0
      }
    } ; [End] if (FirstVar == "ClipText")
    else if (FirstVar == "ClipObject")
    {
      if (CheckClip != "object")
      {
        ThisPassed := 0
      } ; [End] if (CheckClip != "object")
    } ; [End] else if (FirstVar == "ClipObject")
  } ; [End] if (InStr(FirstVar, "Clip") > 0)
  ; -------------------------------------------
  else if (InStr(FirstVar, "Select") > 0)
  {
    ; -------------------------------------------
    KeyArray.RemoveAt(1)
    ; -------------------------------------------
    OldClip := Clipboard
    Clipboard :=
    Sleep, 100
    Send, {Ctrl Down}c{Ctrl Up}
    Sleep, 100
    ; -------------------------------------------
    CheckClipArray := VarIsType(Clipboard) ; VarIsType(ThisVar) ; > the [Type of ThisVar, Value of ThisVar]
    CheckClip := CheckClipArray.1
    ; -------------------------------------------
    Sleep, 100
    Clipboard := OldClip
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (CheckClip == "UNKNOWN")
    {
      ThisPassed := 0
    } ; [End] if (CheckClip == "empty")
    ; -------------------------------------------
    else if (FirstVar == "SelectText")
    {
      if (CheckClip != "integer" && CheckClip != "float" && CheckClip != "number" && CheckClip != "space" && CheckClip != "tab" && CheckClip != "time" && CheckClip != "string")
      {
        ThisPassed := 0
      }
    } ; [End] if (FirstVar == "SelectText")
    ; -------------------------------------------
    else if (FirstVar == "SelectObject")
    {
      if (CheckClip != "object")
      {
        ThisPassed := 0
      } ; [End] if (CheckClip != "object")
    } ; [End] else if (FirstVar == "SelectObject")
    ; -------------------------------------------
  } ; [End] else if (InStr(FirstVar, "Select") > 0)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (ThisPassed == 1)
  {
    ; -------------------------------------------
    for index, ThisKey in KeyArray
    {
      ; -------------------------------------------
      if (ThisKey == "Sleep")
      {
        SleepTime := StrReplace(ThisKey, "Sleep", "")
        Sleep, %SleepTime%
      }
      else if (SubStr(ThisKey, 1, 6) == "Window")
      {
        ; -------------------------------------------
        TitleClass := SubStr(ThisKey, 8)
        AtPos := InStr(TitleClass, "@")
        TitleClass_Len := StrLen(TitleClass)
        Title_Len := AtPos - 1
        ThisTitle := SubStr(TitleClass, 1, Title_Len)
        ThisClass := SubStr(TitleClass, AtPos + 1)
        ; -------------------------------------------
        BreakTime := A_TickCount + 2000
        SetTitleMatchMode, 2
        while !WinExist(ThisTitle . ThisClass)
        {
          if (BreakTime > A_TickCount)
          {
            break
          }
        }
        Sleep, 500
      }
      else if (SubStr(ThisKey, 1, 5) == "Sleep")
      {
        ThisSleep := SubStr(ThisKey, 6)
        Sleep, %ThisSleep%
      }
      else if (ThisKey == "@_T")
      {
        ClickAtPoint("@_T") ; (ClickHere) Center of Titlebar
      } ; [End] else if (ThisKey == "@_T")
      else if (ThisKey == "Home")
      {
        Sleep, 100
        Send, {Home}
      } ; [End] else if (ThisKey == "Home")
      else if (SubStr(ThisKey, 1, 3) == "Tab")
      {
        LoopNum := SubStr(ThisKey, 4)
        Loop %LoopNum%
        {
          Send, {Tab}
          Sleep, 100
        }
      } ; [End] else if (ThisKey == "Tab")
      else if (ThisKey == "Alt")
      {
        Send, {Alt}
      } ; [End] else if (ThisKey == "Alt")
      else if (ThisKey == "Alt_Down")
      {
        Send, {Alt Down}
      } ; [End] else if (ThisKey == "Alt_Down")
      else if (ThisKey == "Alt_Up")
      {
        Send, {Alt Up}
      } ; [End] else if (ThisKey == "Alt_Up")
      else if (ThisKey == "Enter")
      {
        Send, {Enter}
      } ; [End] else if (ThisKey == "Enter")
      else if (SubStr(ThisKey, 1, 2) == "Up")
      {
        LoopNum := SubStr(ThisKey, 3)
        Loop %LoopNum%
        {
          Send, {Up}
          Sleep, 1
        }
      } ; [End] else if (SubStr(ThisKey, 1, 4) == "Up")
      else if (SubStr(ThisKey, 1, 4) == "Down")
      {
        LoopNum := SubStr(ThisKey, 5)
        Loop %LoopNum%
        {
          Send, {Down}
          Sleep, 1
        }
      } ; [End] else if (SubStr(ThisKey, 1, 4) == "Down")
      else if (SubStr(ThisKey, 1, 4) == "Left")
      {
        LoopNum := SubStr(ThisKey, 5)
        Loop %LoopNum%
        {
          Send, {Left}
          Sleep, 1
        }
      } ; [End] else if (SubStr(ThisKey, 1, 4) == "Left")
      else if (SubStr(ThisKey, 1, 5) == "Right")
      {
        LoopNum := SubStr(ThisKey, 6)
        Loop %LoopNum%
        {
          Send, {Right}
          Sleep, 1
        }
      } ; [End] else if (SubStr(ThisKey, 1, 4) == "Right")
      else if (ThisKey == "Home")
      {
        Send, {Home}
      } ; [End] else if (ThisKey == "Home")
      else if (ThisKey == "End")
      {
        Send, {End}
      } ; [End] else if (ThisKey == "End")
      else
      {
        KeyNum := KeyNum + 1
        Send, %ThisKey%
      } ; [End] else
      ; -------------------------------------------
      if (ThisKey != "Up" && ThisKey != "Down" && ThisKey != "Right" && ThisKey != "Left")
      {
        ; -------------------------------------------
        NextIndex := index + 1
        CkNext := KeyArray[NextIndex]
        ; -------------------------------------------
        if (CkNext != "")
        {
          ; -------------------------------------------
          Sleep, 250
        } ; [End] if (CkNext != "")
      } ; [End] if (ThisKey != "Up" && ThisKey != "Down" && ThisKey != "Right" && ThisKey != "Left")
    } ; [End] for index, ThisKey in KeyArray
  } ; [End] if (ThisPassed == 1)
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  BlockInput, Off
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
} ; [End] PluginSendAlt(KeyArray, SendArrow)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ClickAtPoint(ClickHere) ; (ClickHere) @PP_C=PowerPointCenterDocument,"@_T"=TitleBar
{
  if (ClickHere == "@PP_C") ; (Click) @ PowerPoint Center Document
  {
    ; -------------------------------------------
    ; This Function used before Send Keystroke
    ; Click the Left Mouse Button
    ; in the Center Top of the PowerPoint Presentation
    ; -------------------------------------------
    SysGet, TitleBarHeight, 31
    CoordMode, Mouse, Screen
    MouseGetPos, Old_X, Old_Y ; Current Mouse Postion
    ; -------------------------------------------
    WinGetActiveTitle, OutputVar
    WinGetPos , Win_X, Win_Y, Win_W, Win_H, %OutputVar%
    ; -------------------------------------------
    New_X := (Win_W / 2) + (Win_X + 100)
    New_Y := (Win_H / 2) + (Win_Y - 90)
    MouseMove, New_X, New_Y, 0
    Send, {LButton}
    CoordMode, Mouse, Screen
    MouseMove, Old_X, Old_Y, 0
    ; -------------------------------------------
  }
  else if (ClickHere == "@_T") ; (Click) @ TitleBar
  {
    ; -------------------------------------------
    ; Click the Left Mouse Button
    ; in the Center of the Active Window Title Bar
    ; -------------------------------------------
    SysGet, TitleBarHeight, 31
    CoordMode, Mouse, Screen
    MouseGetPos, Old_X, Old_Y ; Current Mouse Postion
    ; -------------------------------------------
    WinGetActiveTitle, OutputVar
    WinGetPos , Win_X, Win_Y, Win_W, Win_H, %OutputVar%
    ; -------------------------------------------
    New_X := (Win_W / 2) + Win_X
    New_Y := Win_Y + (TitleBarHeight / 2)
    MouseMove, New_X, New_Y, 0
    Send, {LButton}
    CoordMode, Mouse, Screen
    MouseMove, Old_X, Old_Y, 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
} ; [End] ClickAtPoint(ClickHere) ; (ClickHere) "PowerPointCenterDocument", "TitleBar"
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
