﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_Description(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; ExistingShortcut = 0 (Not Over Shortcut)
  ; ExistingShortcut = 1 (Over Shortcut)
  ; ExistingShortcut = 2 (Not in Pum)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  WinGet, ThisPumProcessExe, ProcessName , ahk_class TfrmToolbox
  ; -------------------------------------------
  if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Current Mouse Position
    ; -------------------------------------------
    CoordMode, Mouse, Window
    ; -------------------------------------------
    MouseGetPos , Pum_MousePosX, Pum_MousePosY, , , 1
    ; -------------------------------------------
    ; Get Current Mouse Position
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; -------------------------------------------
    SplitPath, ThisPumProcessExe, , , , ThisPumProcessName
    ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
    ThisPumProcessFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
    ; -------------------------------------------
    ThisPumProcessArray := DataArray.361.10
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Check_Len := ThisPumProcessArray.MaxIndex() ; Highest Length
    ; -------------------------------------------
    if (Check_Len < 38 or Check_Len == "")
    {
      ; -------------------------------------------
      ThisPumProcessXml := ThisPumProcessFolder "\settings\toolbox0.xml"
      ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
      DataArray.361.10 := ThisPumProcessArray
      ; -------------------------------------------
    } ; if (Check_Len < 38 or Check_Len == "")
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; XML Line Strings from (ThisPumProcessArray)
    ; -------------------------------------------
    XmlLine3  := ThisPumProcessArray.3
    XmlLine9  := ThisPumProcessArray.9
    ; -------------------------------------------
    ; XML Line Strings from (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlRowsY)
    ; -------------------------------------------
    FindItem := "rows"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlRowsY := ThisVar
    ; -------------------------------------------
    ; (XmlRowsY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlColumnsX)
    ; -------------------------------------------
    FindItem := "columns"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlColumnsX := ThisVar
    ; -------------------------------------------
    ; (XmlColumnsX)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlIconSize)
    ; -------------------------------------------
    FindItem := "iconsize"
    XmlString := XmlLine9 ; <displaymode type="0" iconsize="48" />
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlIconSize := ThisVar
    ; -------------------------------------------
    ; (XmlIconSize)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; -------------------------------------------
    XmlShortcutPosX := Pum_MousePosX / XmlIconSize
    XmlShortcutPosY := Pum_MousePosY / XmlIconSize
    ; -------------------------------------------
    XmlShortcutPosX := XmlShortcutPosX + 1
    XmlShortcutPosY := XmlShortcutPosY + 1
    ; -------------------------------------------
    XmlShortcutPosX := Floor(XmlShortcutPosX)
    XmlShortcutPosY := Floor(XmlShortcutPosY)
    ; -------------------------------------------
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (XmlShortcutPosX > XmlColumnsX)
    {
      XmlShortcutPosX := 0
    }
    else if (XmlShortcutPosX < 0)
    {
      XmlShortcutPosX := 0
    }
    ; -------------------------------------------
    if (XmlShortcutPosY  > XmlRowsY)
    {
      XmlShortcutPosY  := 0 
    }
    else if (XmlShortcutPosY  < 0) 
    {
      XmlShortcutPosY  := 0 
    }
    ; -------------------------------------------
    if (XmlShortcutPosX == 0 or XmlShortcutPosY  == 0)
    {
      ExistingShortcut := 2 ; 0 = Not Over Shortcut, 1 = Over Shortcut, 2 = Not in Pum
    }
    else ; Check for Existing Short
    {
      ; -------------------------------------------
      CheckFor := "<shortcut row=""" XmlShortcutPosY  """ column=""" XmlShortcutPosX """"
      ; -------------------------------------------
      ExistingShortcut   := 0 ; 0 = Not Over Shortcut, 1 = Over Shortcut, 2 = Not in Pum
      XmlShortcutLineNum := 0
      XmlScriptPath     := ""
      ; -------------------------------------------
      for Index, ThisLine in ThisPumProcessArray
      {
        if (InStr(ThisLine, CheckFor) > 0)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Set (XmlShortcutLineNum)
          ; Set (ExistingShortcut)
          ; -------------------------------------------
          XmlShortcutLineNum := Index
          ; -------------------------------------------
          ScriptNameExt := ThisPumProcessArray[XmlShortcutLineNum + 1]
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>ahk\", "")
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>","")
          ScriptNameExt := StrReplace(ScriptNameExt, "</filename>", "")
          ScriptNameExt := StrReplace(ScriptNameExt, A_Space ,"")
          XmlScriptPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\ahk\" ScriptNameExt
          ; -------------------------------------------
          ExistingShortcut := 1 ; 0 = Not Over Shortcut, 1 = Over Shortcut, 2 = Not in Pum
          ; -------------------------------------------
          ; Set (XmlShortcutLineNum)
          ; Set (ExistingShortcut)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          break
          ; -------------------------------------------
        } ; End if (InStr(ThisLine, CheckFor) > 0)
      } ; End for Index, ThisLine in ThisPumProcessArray
      ; -------------------------------------------
    } ; End Check for Existing Short
    ; -------------------------------------------
    if (ExistingShortcut == 1)
    {
      ; -------------------------------------------
      FileReadLine, ShortcutDescription, %XmlScriptPath%, 10
      ShortcutDescription := SubStr(ShortcutDescription, 2)
      ; -------------------------------------------
    } ; [End] if (ExistingShortcut == 1)
    ; -------------------------------------------
  } ; [End] if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  ; -------------------------------------------
  DataArray.153.1 := ExistingShortcut ; (153)(01)(Shortcut_Description_ExistingShortcut)
  DataArray.153.2 := ShortcutDescription ; (153)(02)(ShortcutDescription)
  DataArray.153.3 := XmlShortcutPosX ; (153)(03)(XmlShortcutPosX)
  DataArray.153.4 := XmlShortcutPosY ; (153)(04)(XmlShortcutPosY)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
