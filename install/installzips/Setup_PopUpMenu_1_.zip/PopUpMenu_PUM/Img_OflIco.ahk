﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_OflIco(ArrayIn) ; > FileOflIco
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileOflIco := Img_OflIco(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileOflIco := Img_OflIco(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileOflIco := Img_OflIco(ArrayIn)
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileOflIco
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Application Path Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn      := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileOflIco", UserLang, UserPictureFolder]
    ArrayOut     := Image_PathFolderOrName(ArrayIn)
    FileOflIco := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)\" AppProcessName "_(" AppProcessFolder ").ico"]
    ; -------------------------------------------
    if !FileExist(FileOflIco)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png]
      ; -------------------------------------------
      OflIcoTemp1 := A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png" ; w41 h41
      ; -------------------------------------------
      if FileExist(OflIcoTemp1)
      {
        FileDelete, %OflIcoTemp1%
      } ; [End] if FileExist(OflIcoTemp1)
      ; -------------------------------------------
      Image_ResizePng(41, 41, FileRunPng, OflIcoTemp1) ; [RESIZE]_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\ofl.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png"]
      ; -------------------------------------------
      I1 := "C:\Program Files\PopUpMenu_PUM\image\ico\ofl.png" ; w80 h80
      X1 := 0
      Y1 := 0
      ;
      I2 := OflIcoTemp1
      X2 := 20 ; X Position
      Y2 := 25 ; Y Postion
      ; -------------------------------------------
      OflIcoTemp2 := A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png" ; w80 h80
      ; -------------------------------------------
      if FileExist(OflIcoTemp2)
      {
        FileDelete, %OflIcoTemp1%
      } ; [End] if FileExist(OflIcoTemp1)
      ; -------------------------------------------
      Image_Array := [80, 80, OflIcoTemp2, I1, X1, Y1, I2, X2, Y2]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\ofl.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CONVERT] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; -------------------------------------------
      Image_ImgToIco(OflIcoTemp2, FileOflIco) ; > ImageOut
      ; -------------------------------------------
      ; [CONVERT] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png"]
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; -------------------------------------------
      if FileExist(OflIcoTemp1)
      {
        FileDelete, %OflIcoTemp1%
      } ; [End] if FileExist(OflIcoTemp1)
      ; -------------------------------------------
      if FileExist(OflIcoTemp2)
      {
        FileDelete, %OflIcoTemp2%
      } ; [End] if FileExist(OflIcoTemp2)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp1.png"]
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\OflIcoTemp2.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileOflIco)
    ; -------------------------------------------
    return FileOflIco
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ;  Application Path Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
