﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Combine(Image_Array) ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Pos_X, Pos_Y,) etc] > Image_Out
{
  ; -------------------------------------------
  if IsObject(Image_Array)
  {
    ; -------------------------------------------
    SymPlus := "{+}"
    ; -------------------------------------------
    Out_W     := Image_Array.1  ; Out_W   = Image_Out Width
    Out_H     := Image_Array.2  ; Out_H   = Image_Out Height
    Image_Out := Image_Array.3 ; Return Image_Out
    ;
    Image_0 := Image_Array.4
    Pos_X := Image_Array.5
    Pos_Y := Image_Array.6
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    RunThis := """" Support_magick """ convert -page " Out_W "x" Out_H "+"
    ImgString := Pos_X "+" Pos_Y " """ Image_0 """"
    ;
    NumCnt := 7
    ; -------------------------------------------
    for NumImg, This_Var in Image_Array
    {
      ; -------------------------------------------
      if (NumImg == NumCnt)
      {
        ; -------------------------------------------
        Img_0  := Image_Array[NumCnt] ; (0  _1)(Empty)
        NumCnt := NumCnt + 1
        PosImg_X  := Round(Image_Array[NumCnt])
        NumCnt := NumCnt + 1
        PosImg_Y  := Round(Image_Array[NumCnt])
        NumCnt := NumCnt + 1
        ; -------------------------------------------
        ImgString := ImgString " -page +" PosImg_X "+" PosImg_Y " """ Img_0 """"
        ; -------------------------------------------
      } ; End (NumImg == NumCnt)
      ; -------------------------------------------
    } ; End for NumImg, This_Var in Image_Array
    ; -------------------------------------------
    ImgString := ImgString ""
    ; -------------------------------------------
    RunThis := RunThis ImgString " -background none -layers flatten """ Image_Out """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    return Image_Out
    ; -------------------------------------------
  } ; End if IsObject(Image_Array)
  ; -------------------------------------------
} ; End Image_page_2(Image_Array)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
