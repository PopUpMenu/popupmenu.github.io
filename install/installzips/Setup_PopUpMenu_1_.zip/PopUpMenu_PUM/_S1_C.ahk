﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Validate.ahk
#Include C:\Program Files\PopUpMenu_PUM\Default_Application.ahk
#Include C:\Program Files\PopUpMenu_PUM\Default_Browser.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
; [ScriptError = 2] (rwh)(No Application to Open File)
; [ScriptError = 3] (key)(Invalid KeyStroke)
; [ScriptError = 4] (xxx)(Enpty Icon Grid Selected)
; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
; [ScriptError = 6] (ofl)(Folder Not Found)
; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
; [ScriptError = 15] (url)(No Selected URL)
; [ScriptError = 16] 
; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
; [ScriptError = 18] (url)(Source Not Found)
; [ScriptError = 19] (url)(No Internet Connection)
; [ScriptError = 20] (AppProcessName = "windows")
; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
; [ScriptError = 22] (pumtom)(No Error)
; -------------------------------------------
/*
  ; -------------------------------------------
  FontColor := "199524"
  FontColor := "a30404"
  FontColor := "000000"
  FontColor := "921297"
  FontColor := "040e47"
  ; -------------------------------------------
*/
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
_S1_C(DataArray)
{
  ; -------------------------------------------
  DataArray.366.6 := 0 ; (366_6)(ScriptError [Integer])
  ; -------------------------------------------
  HasConnection := InternetConnectCheck()
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    ; [ScriptError = 4] (xxx)(Enpty Icon Grid Selected)
    DataArray.366.6 := 4 ; (366_6)(ScriptError [Integer])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
  } ; [End] (xxx)
  ; -------------------------------------------
  else if (DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    ; [ScriptError = 8] (No Error)(run_rwh_url_ofl)(Country Image)
    DataArray.366.6 := 8 ; (366_6)(ScriptError [Integer])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
  } ; [End] (run_rwh_url_ofl)
  ; -------------------------------------------
  else if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; Set to 0 for check
    DataArray.302.7 := 0 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.365.2 == "de" && DataArray.321.3 == 1) ; (365_2)(UserLang [Current User language])/(321_3)([mnu] (mnu_MenuInstalled_de) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "en" && DataArray.322.3 == 1) ; (365_2)(UserLang [Current User language])/(322_3)([mnu] (mnu_MenuInstalled_en) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "es" && DataArray.323.3 == 1) ; (365_2)(UserLang [Current User language])/(323_3)([mnu] (mnu_MenuInstalled_es) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "fr" && DataArray.324.3 == 1) ; (365_2)(UserLang [Current User language])/(324_3)([mnu] (mnu_MenuInstalled_fr) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "it" && DataArray.325.3 == 1) ; (365_2)(UserLang [Current User language])/(325_3)([mnu] (mnu_MenuInstalled_it) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "pl" && DataArray.326.3 == 1) ; (365_2)(UserLang [Current User language])/(326_3)([mnu] (mnu_MenuInstalled_pl) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "pt" && DataArray.327.3 == 1) ; (365_2)(UserLang [Current User language])/(327_3)([mnu] (mnu_MenuInstalled_pt) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "ru" && DataArray.328.3 == 1) ; (365_2)(UserLang [Current User language])/(328_3)([mnu] (mnu_MenuInstalled_ru) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "sv" && DataArray.329.3 == 1) ; (365_2)(UserLang [Current User language])/(329_3)([mnu] (mnu_MenuInstalled_sv) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "tr" && DataArray.330.3 == 1) ; (365_2)(UserLang [Current User language])/(330_3)([mnu] (mnu_MenuInstalled_tr) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (DataArray.302.7 == 0) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    {
      ; -------------------------------------------
      if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        ; [ScriptError = 20] (AppProcessName = "windows")
        DataArray.366.6 := 20 ; (366_6)(ScriptError [Integer])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      }
      else ; Not in Desktop
      {
        ; -------------------------------------------
        File_CurrentAddons := "C:\Program Files\PopUpMenu_PUM\update\currentaddons.txt"
        ; -------------------------------------------
        if FileExist(File_CurrentAddons)
        {
          ; -------------------------------------------
          Current_menu_Array := Array_FromFile(File_CurrentAddons)
          Check_App_Addon := DataArray.367.1 "_" DataArray.365.2 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])/(365_2)(UserLang [Current User language])
          StringLower, Check_App_Addon, Check_App_Addon
          ; -------------------------------------------
          for Index, This_Addon in Current_menu_Array
          {
            ; -------------------------------------------
            StringLower, This_Addon, This_Addon
            ; -------------------------------------------
            if (This_Addon == Check_App_Addon)
            {
              ; -------------------------------------------
              if (HasConnection == 1) ; Internet Connection Ok
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
                ; [ScriptError = 5] (Addon Not Installed)(Addon is Available)
                DataArray.366.6 := 5 ; (366_6)(ScriptError [Integer])
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              } ; [End] if (HasConnection == 1) ; Internet Connection Ok
              else ; No Internet Connection
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
                ; [ScriptError = 7] (No Error)(mnu_cpl_key)(Country Image)
                DataArray.366.6 := 7 ; (366_6)(ScriptError [Integer])
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              }
              ; -------------------------------------------
              break
              ; -------------------------------------------
            } ; [End] (This_Addon == Check_App_Addon)
          } ; [End] for Index, This_Addon in Current_menu_Array
        } ; [End] FileExist(File_CurrentAddons)
        ; -------------------------------------------
        if (DataArray.366.6 != 5) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          File_AppRequest := A_AppData "\PopUpMenu_PUM\system\File_AppRequest.txt"
          ; -------------------------------------------
          StringLower, Check_App_Addon, Check_App_Addon
          ; -------------------------------------------
          HasRequested := 0
          ; -------------------------------------------
          if FileExist(File_AppRequest)
          {
            ; -------------------------------------------
            AppArray := Array_FromFile(File_AppRequest)
            for Index, CheckApp in AppArray
            {
              ; -------------------------------------------
              StringLower, CheckApp, CheckApp
              ; -------------------------------------------
              if (CheckApp == Check_App_Addon)
              {
                HasRequested := 1
                break
              } ; [End] (CheckApp == AppRequest)
            } ; [End] for Index, CheckApp in AppArray
            ; -------------------------------------------
          } ; [End] FileExist(File_AppRequest)
          ; -------------------------------------------
          if (HasConnection == 1) ; Internet Connection Ok
          {
            ; -------------------------------------------
            if (HasRequested == 0)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              ; [ScriptError = 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
              DataArray.366.6 := 17 ; (366_6)(ScriptError [Integer])
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            } ; [End] (HasRequested == 0)
            else if (HasRequested == 1)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              ; [ScriptError = 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
              DataArray.366.6 := 12 ; (366_6)(ScriptError [Integer])
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            } ; [End] (HasRequested == 1)
          } ; [End] if (HasConnection == 1) ; Internet Connection Ok
          else ; No Internet Connection
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            ; [ScriptError = 7] (No Error)(mnu_cpl_key)(Country Image)
            DataArray.366.6 := 7 ; (366_6)(ScriptError [Integer])
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
          } ; [End] else ; No Internet Connection
        } ; [End] (ScriptError != 5)
      } ; [End] Not in Desktop
      ; -------------------------------------------
    } ; [End] (mnu_ActiveAddonInstalled == 0)
    ; -------------------------------------------
    else if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 7] (No Error)(mnu_cpl_key)(Country Image)
      DataArray.366.6 := 7 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    } ; (366_6)(ScriptError [Integer])
  } ; [End] (mnu_cpl_key)
  ; -------------------------------------------
  else if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ; Script_Line_2 := "Com_####"                 (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ; Script_Line_3 := ""                         *** EMPTY ***
    ; Script_Line_4 := ""                         *** EMPTY ***
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ;
    ; -------------------------------------------
    ; Set to 0 for check
    DataArray.302.7 := 0 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.365.2 == "de" && DataArray.321.3 == 1) ; (365_2)(UserLang [Current User language])/(321_3)([mnu] (mnu_MenuInstalled_de) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "en" && DataArray.322.3 == 1) ; (365_2)(UserLang [Current User language])/(322_3)([mnu] (mnu_MenuInstalled_en) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "es" && DataArray.323.3 == 1) ; (365_2)(UserLang [Current User language])/(323_3)([mnu] (mnu_MenuInstalled_es) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "fr" && DataArray.324.3 == 1) ; (365_2)(UserLang [Current User language])/(324_3)([mnu] (mnu_MenuInstalled_fr) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "it" && DataArray.325.3 == 1) ; (365_2)(UserLang [Current User language])/(325_3)([mnu] (mnu_MenuInstalled_it) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "pl" && DataArray.326.3 == 1) ; (365_2)(UserLang [Current User language])/(326_3)([mnu] (mnu_MenuInstalled_pl) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "pt" && DataArray.327.3 == 1) ; (365_2)(UserLang [Current User language])/(327_3)([mnu] (mnu_MenuInstalled_pt) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "ru" && DataArray.328.3 == 1) ; (365_2)(UserLang [Current User language])/(328_3)([mnu] (mnu_MenuInstalled_ru) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "sv" && DataArray.329.3 == 1) ; (365_2)(UserLang [Current User language])/(329_3)([mnu] (mnu_MenuInstalled_sv) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; -------------------------------------------
    else if (DataArray.365.2 == "tr" && DataArray.330.3 == 1) ; (365_2)(UserLang [Current User language])/(330_3)([mnu] (mnu_MenuInstalled_tr) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (DataArray.300.2 == 0) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      DataArray.366.6 := 14 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
    ; -------------------------------------------
    else if (DataArray.300.4 == 0) ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      DataArray.366.6 := 11 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
  } ; [End] (cpl)
  ; -------------------------------------------
  else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; Script_Line_2 := 1/2                        (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
    ; Script_Line_3 := ["[Key]", "~X~"]           (301_8)(Key_KeyArrayShortcut [Array])
    ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
    ; Script_Line_5 := "App ProcessPathNameExt"   (301_10)(KeyMnu_ProcessPathExtName)
    ; Script_Line_6 := 0/1                        (301_11)(Key_ShortcutInAppPum [0,1])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
    DataArray := KeyArray_Validate(DataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
    ;
    ; -------------------------------------------
    if (DataArray.301.3 == 3) ; (301_3)(Key_ArrayValid [1,3])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      DataArray.366.6 := 3 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
    ; -------------------------------------------
    else if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
    {
      ; -------------------------------------------
      if (DataArray.301.10 != "") ; (301_10)(KeyMnu_ProcessPathExtName)
      {
        if (DataArray.301.11  == 0) ; (301_11)(Key_ShortcutInAppPum [0,1])
        {
          if (DataArray.72.2 == 2) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            if (DataArray.301.10 != DataArray.367.5) ; (301_10)(KeyMnu_ProcessPathExtName)/(367_5)(AppProcessPathNameExt [Path,Name,Ext])
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
              DataArray.366.6 := 13 ; (366_6)(ScriptError [Integer])
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            }
          }
        }
      }
    } ; (366_6)(ScriptError [Integer])
  } ; [End] (key)
  ; -------------------------------------------  
  else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
    ; Script_Line_3 := "Com_####" or "Mkb_####"   (302_8)(Mnu_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
    ; Script_Line_5 := "App ProcessName"          (301_6)(KeyMnu_ProcessName)
    ; Script_Line_6 := "Lang"                     (365_2)(UserLang [Current User language])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ;
    ; -------------------------------------------
    DataArray.302.7 := 0 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    ; -------------------------------------------
    if ((DataArray.365.2 == "de" && DataArray.321.3 == 1) or (DataArray.365.2 == "en" && DataArray.322.3 == 1) or (DataArray.365.2 == "es" && DataArray.323.3 == 1) or (DataArray.365.2 == "fr" && DataArray.324.3 == 1) or (DataArray.365.2 == "it" && DataArray.325.3 == 1) or (DataArray.365.2 == "pl" && DataArray.326.3 == 1) or (DataArray.365.2 == "pt" && DataArray.327.3 == 1) or (DataArray.365.2 == "ru" && DataArray.328.3 == 1) or (DataArray.365.2 == "sv" && DataArray.329.3 == 1) or (DataArray.365.2 == "tr" && DataArray.330.3 == 1)) ; (321_3)([mnu] (mnu_MenuInstalled_de) [1/0])/(322_3)([mnu] (mnu_MenuInstalled_en) [1/0])/(323_3)([mnu] (mnu_MenuInstalled_es) [1/0])/(324_3)([mnu] (mnu_MenuInstalled_fr) [1/0])/(325_3)([mnu] (mnu_MenuInstalled_it) [1/0])/(326_3)([mnu] (mnu_MenuInstalled_pl) [1/0])/(327_3)([mnu] (mnu_MenuInstalled_pt) [1/0])/(328_3)([mnu] (mnu_MenuInstalled_ru) [1/0])/(329_3)([mnu] (mnu_MenuInstalled_sv) [1/0])/(365_2)(UserLang [Current User language])/(330_3)([mnu] (mnu_MenuInstalled_tr) [1/0])
    {
      DataArray.302.7 := 1 ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    } ; Any Addon Installed for Active Process
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.302.7 == 0) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    {
      ; -------------------------------------------
      File_CurrentAddons := "C:\Program Files\PopUpMenu_PUM\update\currentaddons.txt"
      ; -------------------------------------------
      if FileExist(File_CurrentAddons)
      {
        ; -------------------------------------------
        Current_menu_Array := Array_FromFile(File_CurrentAddons)
        Check_App_Addon := DataArray.367.1 "_" DataArray.365.2 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])/(365_2)(UserLang [Current User language])
        StringLower, Check_App_Addon, Check_App_Addon
        ; -------------------------------------------
        for Index, This_Addon in Current_menu_Array
        {
          ; -------------------------------------------
          StringLower, This_Addon, This_Addon
          ; -------------------------------------------
          if (This_Addon == Check_App_Addon)
          {
            ; -------------------------------------------
            if (HasConnection == 1) ; Internet Connection Ok
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              ; [ScriptError = 5] (Addon Not Installed)(Addon is Available)
              DataArray.366.6 := 5 ; (366_6)(ScriptError [Integer])
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            } ; [End] if (HasConnection == 1) ; Internet Connection Ok
            else ; No Internet Connection
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
              ; [ScriptError = 7] (No Error)(mnu_cpl_key)(Country Image)
              DataArray.366.6 := 7 ; (366_6)(ScriptError [Integer])
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
            }
            ; -------------------------------------------
            break
            ; -------------------------------------------
          } ; [End] (This_Addon == Check_App_Addon)
        } ; [End] for Index, This_Addon in Current_menu_Array
      } ; [End] FileExist(File_CurrentAddons)
      ; -------------------------------------------
      if (DataArray.366.6 != 5) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        StringLower, Check_App_Addon, Check_App_Addon
        ; -------------------------------------------
        HasRequested := 0
        ; -------------------------------------------
        File_AppRequest := A_AppData "\PopUpMenu_PUM\system\File_AppRequest.txt"
        ; -------------------------------------------
        if FileExist(File_AppRequest)
        {
          ; -------------------------------------------
          AppArray := Array_FromFile(File_AppRequest)
          ; -------------------------------------------
          for Index, CheckApp in AppArray
          {
            ; -------------------------------------------
            StringLower, CheckApp, CheckApp
            ; -------------------------------------------
            if (CheckApp == Check_App_Addon)
            {
              HasRequested := 1
              break
            } ; [End] (CheckApp == Check_App_Addon)
          } ; [End] for Index, CheckApp in AppArray
          ; -------------------------------------------
        } ; [End]  FileExist(File_AppRequest)
        ; -------------------------------------------
        if (HasRequested == 0)
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
          ; [ScriptError = 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
          DataArray.366.6 := 17 ; (366_6)(ScriptError [Integer])
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        } ; [End] (HasRequested == 0)
        else if (HasRequested == 1)
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
          ; [ScriptError = 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
          DataArray.366.6 := 12 ; (366_6)(ScriptError [Integer])
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        } ; [End] (HasRequested == 1)
      } ; [End] (ScriptError != 5)
    } ; [End] (mnu_ActiveAddonInstalled == 0)
    ; -------------------------------------------
    else if (DataArray.302.7 == 1) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
    {
      if (DataArray.302.2 == 0) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        ; [ScriptError = 9] (No Error)(mnu)(Menu Bar Item Not Selected)
        DataArray.366.6 := 9 ; (366_6)(ScriptError [Integer])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      }
      else if (DataArray.302.2 != 0) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
      {
        ; -------------------------------------------
        if (DataArray.302.5 == 0) ; (302_5)(Mnu_Number_000x [X_X_X_#])
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
          ; [ScriptError = 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
          DataArray.366.6 := 10 ; (366_6)(ScriptError [Integer])
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        }
      }
    } ; [End] (mnu_ActiveAddonInstalled == 1)
  } ; [End] (mnu)
  ; -------------------------------------------
  else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; Script_Line_2 := ""                         *** EMPTY ***
    ; Script_Line_3 := "x:\Folder"                (303_2)(ofl_FolderPathName [Folder Name With Path])
    ; Script_Line_4 := ""                         *** EMPTY ***
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ;
    ; -------------------------------------------
    if !FileExist(DataArray.303.2) ; (303_2)(ofl_FolderPathName [Folder Name With Path])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 6] (Folder Not Found)
      DataArray.366.6 := 6 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
    ; -------------------------------------------
  } ; [End] (ofl)
  ; -------------------------------------------
  else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
    ; Script_Line_4 := "Run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
    ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; Script_Line_6 := ""                         (Empty)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ;
    ; -------------------------------------------
    if !FileExist(DataArray.305.11) ; (305_11)(Run_OutTarget [PathExtName])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 1] (Target File Not Found)
      DataArray.366.6 := 1 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    } ; [End] !FileExist(run_OutTarget)
    ; -------------------------------------------
    if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
    {
      DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
      DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
    }
    ; -------------------------------------------
  } ; [End] (run)
  ; -------------------------------------------
  else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\File.ext"              (305_4)(run_FilePathNameExt [Selected File] [Path,Name,Ext])
    ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ;
    ; -------------------------------------------
    Run_FilePathNameExt := DataArray.305.4 ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
    SplitPath, Run_FilePathNameExt , OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
    DataArray.305.6 := Default_Application(OutExtension) ; (305_6)(Rwh_DefaultApp [Full File Path])
    ; -------------------------------------------
    if !FileExist(DataArray.305.4) ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 1] (Target File Not Found)
      DataArray.366.6 := 1 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
    else if !FileExist(DataArray.305.5) ; (305_5)(Rwh_OpeningApp [Full File Path])
    {
      if !FileExist(DataArray.305.6) ; (305_6)(Rwh_DefaultApp [Full File Path])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
        ; [ScriptError = 2] (No Application to Open File)
        DataArray.366.6 := 2 ; (366_6)(ScriptError [Integer])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      }
      else
      {
        DataArray.305.8 := 1 ; (305_8)(Rwh_UseAppDefault [0/1])
        DataArray.305.5 := DataArray.305.6 ; (305_5)(Rwh_OpeningApp [Full File Path])/(305_6)(Rwh_DefaultApp [Full File Path])
      }
      ; -------------------------------------------
    }
    else ; [Exist] (305_5)(Rwh_OpeningApp [Full File Path])
    {
      ; -------------------------------------------
      if (DataArray.305.5 == DataArray.305.6) ; (305_5)(Rwh_OpeningApp [Full File Path])/(305_6)(Rwh_DefaultApp [Full File Path])
      {
        DataArray.305.8 := 1 ; (305_8)(Rwh_UseAppDefault [0/1])
      }
      ; -------------------------------------------
    } ; [End] [Exist] (305_5)(Rwh_OpeningApp [Full File Path])
  } ; [End] (rwh)
  ; -------------------------------------------
  else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; Script_Line_2 := "Browser Name from Title"  (307_11)(Url_BrowserTitle [Browser Name from Window Title])
    ; Script_Line_3 := "https://Site.com/"        (307_2)(Url_Address)
    ; Script_Line_4 := *** EMPTY ***
    ; Script_Line_5 := 0/1                        (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HasConnection == 0) ; No Internet Connection
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 19] (url)(No Internet Connection)
      DataArray.366.6 := 19 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    } ; [ScriptError = 16] (url)(No Active Browser)
    ; -------------------------------------------
    ; NO Borwser is Active
    else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      DataArray.366.6 := 21 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    }
    ; -------------------------------------------
  } ; [End] (url)
  ; -------------------------------------------
  else if (DataArray.366.5 == "pumtom") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    ; [ScriptError = 22] (No Error)(pumtom)
    DataArray.366.6 := 22 ; (366_6)(ScriptError [Integer])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
  }
  ; -------------------------------------------
  ;
  if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  {
    if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
      DataArray.4.2 := 1 ; (004_2)(Obj_ok_Sel [0,1,3])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
      ;
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
    ; [ScriptError = 2] (rwh)(No Application to Open File)
    ; [ScriptError = 3] (key)(Invalid KeyStroke)
    ; [ScriptError = 6] (ofl)(Folder Not Found)
    ; [ScriptError = 15] (url)(No Selected URL)
    ; [ScriptError = 19] (url)(No Internet Connection)
    ; -------------------------------------------
    if (DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or or DataArray.366.6 == 15 or DataArray.366.6 == 19) ; (366_6)(ScriptError [Integer])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
      DataArray.4.2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
      ;
      ; -------------------------------------------
      Gui, PopUpMenu:Color, fed8ed ; Light Read
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
    ; -------------------------------------------
    else if (DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
    {
      ; -------------------------------------------
      Gui, PopUpMenu:Color, fed8ed ; Light Read
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      Gui, PopUpMenu:Color, e7d8fe ; Purple
      ; -------------------------------------------
    }
  }
  else
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
    DataArray.4.2 := 1 ; (004_2)(Obj_ok_Sel [0,1,3])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
