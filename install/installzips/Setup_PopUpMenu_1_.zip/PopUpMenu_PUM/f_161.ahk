﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_Del135.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_DisplayPumApp.ahk
#Include C:\Program Files\PopUpMenu_PUM\l_521.ahk ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_161(DataArray) ; (161_1)(Obj_Pum_Del)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ThisPumProcessXml := DataArray.361.9
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(ThisPumProcessXml, "\pumdefault\") > 0) ; (Default Pum Active is Active) NEW Application Pum
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ; [Default pum Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ; [Default pum Active]
      ;
      ; [Internet Browser Application Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ;
      ; -------------------------------------------
      if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ; [Default pum Active]
        ; [Internet Browser Application Active]
        ;
        ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ;
        ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
        ; -------------------------------------------
        if FileExist(ThisPum) ; [pum Exist] [Delete Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ;
          ; [Common Browser pum Exist]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ;
          ; -------------------------------------------
          if (DataArray.161.2 == "" or DataArray.161.2 == 1) ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; [Common Browser pum Exist]
            ;
            ; Pum_DisplayPumApp("Del", DataArray)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
            ;
            ; -------------------------------------------
            if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
            {
              DataArray.161.2 := 1 ; Set Here, is the case value was blank
            }
            ; -------------------------------------------
            DataArray.366.5 := "pumDelete" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Sys_EnableDisable("Disable") ; "Enable" or "Disable"
            ; -------------------------------------------
            Gui, PopUpMenu:Color, ba556f ; Red
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            if (InternetConnectCheck() != 0)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
            }
            ; -------------------------------------------
            f_161_HideObjects(DataArray) ; > DataArray
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
            DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 2, 1, DataArray) ; (161_1)(Obj_Pum_Del)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Pum_DisplayPumApp("Del", DataArray) ; > DataArray
            ; -------------------------------------------
          } ; Pum_DisplayPumApp("Del", DataArray)
          ; -------------------------------------------
          else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; [Common Browser pum Exist]
            ;
            ; [UnSelect] Delete Pum
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Sys_EnableDisable("Enable") ; "Enable" or "Disable"
            ; -------------------------------------------
            Gui, PopUpMenu:Color, e7d8fe ; Purple
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            if (InternetConnectCheck() == 1)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
            }
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
            DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
            ; -------------------------------------------
            ;
            Sleep, 500
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
            if (n_521 == 170)
            {
              ; -------------------------------------------
              DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              global s_521 := 0 ; Hide
              SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              global ShowAnimationChange := 0
              ; -------------------------------------------
            }
            else
            {
              global s_521 := 1 ; Show
              SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            }
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
          } ; [UnSelect] Delete Pum
          ; -------------------------------------------
        } ; [Common Browser pum Exist]
        ; -------------------------------------------
      } ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; -------------------------------------------
      else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ; [Default pum Active]
        ; [Internet Browser Application Active]
        ;
        ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ;
        ; -------------------------------------------
        AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
        ; -------------------------------------------
        if FileExist(ThisPum) ; [pum Exist] [Delete Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ;
          ; [Any Other Internet Browser Application pum Exist]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ;
          if (DataArray.161.2 == "" or DataArray.161.2 == 1) ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; [Any Other Internet Browser Application pum Exist]
            ;
            ; Pum_DisplayPumApp("Del", DataArray)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
            ; -------------------------------------------
            if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
            {
              DataArray.161.2 := 1 ; Set Here, is the case value was blank
            }
            ; -------------------------------------------
            DataArray.366.5 := "pumDelete" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Sys_EnableDisable("Disable") ; "Enable" or "Disable"
            ; -------------------------------------------
            Gui, PopUpMenu:Color, ba556f ; Red
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; -------------------------------------------
            if (InternetConnectCheck() != 0)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
            }
            ; -------------------------------------------
            f_161_HideObjects(DataArray) ; > DataArray
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
            DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 2, 1, DataArray) ; (161_1)(Obj_Pum_Del)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Pum_DisplayPumApp("Del", DataArray) ; > DataArray
            ; -------------------------------------------
          } ; Pum_DisplayPumApp("Del", DataArray)
          ; -------------------------------------------
          else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; [Any Other Internet Browser Application pum Exist]
            ;
            ; [UnSelect] Delete Pum
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Sys_EnableDisable("Enable") ; "Enable" or "Disable"
            ; -------------------------------------------
            Gui, PopUpMenu:Color, e7d8fe ; Purple
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            if (InternetConnectCheck() == 1)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
            }
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
            DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
            ; -------------------------------------------
            ;
            Sleep, 500
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
            if (n_521 == 170)
            {
              ; -------------------------------------------
              DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              global s_521 := 0 ; Hide
              SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              global ShowAnimationChange := 0
              ; -------------------------------------------
            }
            else
            {
              global s_521 := 1 ; Show
              SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            }
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
          } ; [UnSelect] Delete Pum
          ; -------------------------------------------
        } ; [Any Other Internet Browser Application pum Exist]
        ; -------------------------------------------
      } ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; -------------------------------------------
    } ; [Internet Browser Application Active]
    ; -------------------------------------------
  } ; [Default pum Active]
  ; -------------------------------------------
  else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ; [Internet Browser Application Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ;
    ; -------------------------------------------
    if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ; [Internet Browser Application Active]
      ;
      ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ;
      ; -------------------------------------------
      ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
      ; -------------------------------------------
      if FileExist(ThisPum) ; [pum Exist] [Delete Pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ; [Internet Browser Application Active]
        ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ;
        ; [Common Browser pum Exist]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ;
        ; -------------------------------------------
        if (DataArray.161.2 == "" or DataArray.161.2 == 1) ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; [Common Browser pum Exist]
          ;
          ; Pum_DisplayPumApp("Del", DataArray)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ;
          ; -------------------------------------------
          if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
          {
            DataArray.161.2 := 1 ; Set Here, is the case value was blank
          }
          ; -------------------------------------------
          DataArray.366.5 := "pumDelete" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
          DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          Sys_EnableDisable("Disable") ; "Enable" or "Disable"
          ; -------------------------------------------
          Gui, PopUpMenu:Color, ba556f ; Red
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          if (InternetConnectCheck() != 0)
          {
            DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
          }
          ; -------------------------------------------
          f_161_HideObjects(DataArray) ; > DataArray
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
          ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          Img135 := Img_Del135(ArrayIn)
          DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
          ; -------------------------------------------
          DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
          DataArray := Image_GuiControl("161", 2, 1, DataArray) ; (161_1)(Obj_Pum_Del)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Pum_DisplayPumApp("Del", DataArray) ; > DataArray
          ; -------------------------------------------
        } ; Pum_DisplayPumApp("Del", DataArray)
        ; -------------------------------------------
        else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; [Common Browser pum Exist]
          ;
          ; [UnSelect] Delete Pum
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          Sys_EnableDisable("Enable") ; "Enable" or "Disable"
          ; -------------------------------------------
          Gui, PopUpMenu:Color, e7d8fe ; Purple
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          if (InternetConnectCheck() == 1)
          {
            DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
          ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          Img135 := Img_Del135(ArrayIn)
          DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
          ; -------------------------------------------
          DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
          DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
          ; -------------------------------------------
          ;
          Sleep, 500
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
          if (n_521 == 170)
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global s_521 := 0 ; Hide
            SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global ShowAnimationChange := 0
            ; -------------------------------------------
          }
          else
          {
            global s_521 := 1 ; Show
            SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
          }
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
        } ; [UnSelect] Delete Pum
        ; -------------------------------------------
      } ; [Common Browser pum Exist]
      ; -------------------------------------------
    } ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ; [Internet Browser Application Active]
      ;
      ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ;
      ; -------------------------------------------
      AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
      ; -------------------------------------------
      if FileExist(ThisPum) ; [pum Exist] [Delete Pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ; [Internet Browser Application Active]
        ; [UseCommonBrowser = 2][Each Browser Different pum]
        ;
        ; [Internet Browser Application pum Exist]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ;
        ; -------------------------------------------
        if (DataArray.161.2 == "" or DataArray.161.2 == 1) ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; [Internet Browser Application pum Exist]
          ;
          ; Pum_DisplayPumApp("Del", DataArray)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
          ;
          ; -------------------------------------------
          if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
          {
            DataArray.161.2 := 1 ; Set Here, is the case value was blank
          }
          ; -------------------------------------------
          DataArray.366.5 := "pumDelete" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
          DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          Sys_EnableDisable("Disable") ; "Enable" or "Disable"
          ; -------------------------------------------
          Gui, PopUpMenu:Color, ba556f ; Red
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          if (InternetConnectCheck() != 0)
          {
            DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
          }
          ; -------------------------------------------
          f_161_HideObjects(DataArray) ; > DataArray
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ThisAppPath := DataArray.367.5
          ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          Img135 := Img_Del135(ArrayIn)
          DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
          ; -------------------------------------------
          DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
          DataArray := Image_GuiControl("161", 2, 1, DataArray) ; (161_1)(Obj_Pum_Del)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Pum_DisplayPumApp("Del", DataArray) ; > DataArray
          ; -------------------------------------------
        } ; Pum_DisplayPumApp("Del", DataArray)
        ; -------------------------------------------
        else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; [Internet Browser Application pum Exist]
          ;
          ; [UnSelect] Delete Pum
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          Sys_EnableDisable("Enable") ; "Enable" or "Disable"
          ; -------------------------------------------
          Gui, PopUpMenu:Color, e7d8fe ; Purple
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          if (InternetConnectCheck() == 1)
          {
            DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          ThisAppPath := DataArray.367.5
          ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          Img135 := Img_Del135(ArrayIn)
          DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
          ; -------------------------------------------
          DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
          DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
          ; -------------------------------------------
          ;
          Sleep, 500
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
          if (n_521 == 170)
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global s_521 := 0 ; Hide
            SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global ShowAnimationChange := 0
            ; -------------------------------------------
          }
          else
          {
            global s_521 := 1 ; Show
            SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
          }
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
        } ; [UnSelect] Delete Pum
        ; -------------------------------------------            
      } ; [Internet Browser Application pum Exist]
      ; -------------------------------------------
    } ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
  } ; [Internet Browser Application pum Active]
  ; -------------------------------------------
  else ; [Any Other Application (Non Internet Browser) Active]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ; [Any Other Application (Non Internet Browser) Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
    ;
    ; -------------------------------------------
    AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
    ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
    ; -------------------------------------------
    if FileExist(ThisPum) ; [pum Exist] [Delete Pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ; [Any Other Application (Non Internet Browser) Active]
      ;
      ; [Application pum Exist]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
      ;
      ; -------------------------------------------
      if (DataArray.161.2 == "" or DataArray.161.2 == 1) ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ; [Any Other Application (Non Internet Browser) Active]
        ; [Application pum Exist]
        ;
        ; Pum_DisplayPumApp("Del", DataArray)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
        ;
        ; -------------------------------------------
        if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
        {
          DataArray.161.2 := 1 ; Set Here, is the case value was blank
        }
        ; -------------------------------------------
        DataArray.366.5 := "pumDelete" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
        DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
        ; -------------------------------------------
        DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        Sys_EnableDisable("Disable") ; "Enable" or "Disable"
        ; -------------------------------------------
        Gui, PopUpMenu:Color, ba556f ; Red
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        if (InternetConnectCheck() != 0)
        {
          DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
        }
        ; -------------------------------------------
        f_161_HideObjects(DataArray) ; > DataArray
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        ThisAppPath := DataArray.367.5
        ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        Img135 := Img_Del135(ArrayIn)
        DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
        DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
        ; -------------------------------------------
        DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
        DataArray := Image_GuiControl("161", 2, 1, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        DataArray := Pum_DisplayPumApp("Del", DataArray) ; > DataArray
        ; -------------------------------------------
      } ; Pum_DisplayPumApp("Del", DataArray)
      ; -------------------------------------------
      else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Any Other Application (Non Internet Browser) Active]
        ; [Application pum Exist]
        ;
        ; [UnSelect] Delete Pum
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        Sys_EnableDisable("Enable") ; "Enable" or "Disable"
        ; -------------------------------------------
        Gui, PopUpMenu:Color, e7d8fe ; Purple
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (InternetConnectCheck() == 1)
        {
          DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        ThisAppPath := DataArray.367.5
        ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        Img135 := Img_Del135(ArrayIn)
        DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
        DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
        ; -------------------------------------------
        DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
        DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
        ; -------------------------------------------
        ;
        Sleep, 500
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
        if (n_521 == 170)
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
          global s_521 := 0 ; Hide
          SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
          global ShowAnimationChange := 0
          ; -------------------------------------------
        }
        else
        {
          global s_521 := 1 ; Show
          SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
        }
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
      } ; [UnSelect] Delete Pum
      ; -------------------------------------------      
    } ; [Application pum Exist]
    ; -------------------------------------------
  } ; [Any Other Application (Non Internet Browser) Active]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
  DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
  GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
  GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
  ; -------------------------------------------
  return DataArray
  ; -----------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_161_HideObjects(DataArray) ; > DataArray
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
  ; Hide Objects
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum]
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum] [ANIMATE] Stop/Hide (Pum_Building_Construct)
  global s_521 := 0 ; Hide
  SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
  global ShowAnimationChange := 0
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Delete Pum] [ANIMATE] Stop/Hide (Pum_Building_Construct)
  ;
  ; -------------------------------------------
  DataArray := Image_GuiControl("154", 0, 0, DataArray) ; (154_1)(Obj_Pum_BgImage)
  DataArray := Image_GuiControl("155", 0, 0, DataArray) ; (155_1)(Obj_Pum_BgText)
  DataArray := Image_GuiControl("156", 0, 0, DataArray) ; (156_1)(Obj_Pum_BgDim)
  ; -------------------------------------------
  ; [pum] > [pumSetting] > [pumBgImage]
  DataArray := Image_GuiControl("165", 0, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
  DataArray := Image_GuiControl("167", 0, 0, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
  DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
  DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
  DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
  DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
  DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
  DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
  DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
  DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
  DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
  ; -------------------------------------------
  ; [pum] > [pumSetting] > [pumBgText]
  GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
  DataArray := Image_GuiControl("166", 0, 0, DataArray) ; (166_1)(Obj_Pum_BgColor)
  DataArray := Image_GuiControl("172", 0, 0, DataArray) ; (172_1)(Obj_Pum_MobileText)
  DataArray := Image_GuiControl("173", 0, 0, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
  DataArray := Image_GuiControl("174", 0, 0, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
  DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
  DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
  DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
  DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
  DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
  ; -------------------------------------------
  ; [pum] > [pumSetting] > [pumDimension]
  DataArray := Image_GuiControl("260", 0, 0, DataArray) ; (260_1)(Obj_Pum_IconSize)
  DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
  DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
  DataArray := Image_GuiControl("263", 0, 0, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
  DataArray := Image_GuiControl("266", 0, 0, DataArray) ; (266_1)(Obj_Pum_PumRow)
  DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
  DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
  DataArray := Image_GuiControl("269", 0, 0, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
  DataArray := Image_GuiControl("272", 0, 0, DataArray) ; (272_1)(Obj_Pum_PumColumn)
  DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
  DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
  DataArray := Image_GuiControl("275", 0, 0, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
  ; -------------------------------------------
  ; [pum] > [pumContact]
  DataArray := Image_GuiControl("184", 0, 1, DataArray) ; (184_1)(Obj_Pum_ImageText_EmailAddress)
  DataArray := Image_GuiControl("185", 0, 1, DataArray) ; (185_1)(Obj_Pum_ImageText_ContactName)
  DataArray := Image_GuiControl("186", 0, 0, DataArray) ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
  DataArray := Image_GuiControl("188", 0, 0, DataArray) ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
  DataArray := Image_GuiControl("189", 0, 0, DataArray) ; (189_1)(Obj_Pum_EditFeild_ContactName)
  DataArray := Image_GuiControl("190", 0, 0, DataArray) ; (190_1)(Obj_Pum_EditFeild_EmailBody)
  ; -------------------------------------------
  ; Hide Color Picker
  Num_Hide := 190
  Loop 48
  {
    Num_Hide := Num_Hide + 1
    DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; f_161_HideObjects(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
