﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizeImg.ahk ; Image_ResizeImg(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
#Include C:\Program Files\PopUpMenu_PUM\Image_GetDPI.ahk ; Image_GetDPI(FilePath) ; FilePath > DPI
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ChangeDPI(NewDPI, ImageIn, ImageOut) ; NewDPI, ImageIn, ImageOut > Image_Out
{
  if FileExist(ImageIn) ; > ImageOut
  {
		; -------------------------------------------
		ThisDPI := Image_GetDPI(ImageIn) ; FilePath > DPI
		if (ThisDPI != NewDPI)
		{
      ; -------------------------------------------
      Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
      ; -------------------------------------------
		  ;
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ; Get Image Size
		  ; -------------------------------------------
		  Gui, ImageSize:Add, Picture, hwndJustForSize, %ImageIn% ; (368_5)(Selected Pum Background [Full Path])
		  ControlGetPos, , , Resize_W, Resize_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ;
      RunThis := """" Support_magick """ convert -units PixelsPerInch """ ImageIn """ -resample " NewDPI " """ ImageOut """"
      Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
      RunWait, %RunThis%, , Hide
      ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  Sleep, 250
		  ImageOut := Image_ResizeImg(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
		  ; -------------------------------------------
		} ; if (ThisDPI != NewDPI)
		else ; No Change
		{
			ImageOut := ImageIn
		}
  } ; if FileExist(ImageIn) ; > ImageOut
	; -------------------------------------------
	return ImageOut
	; -------------------------------------------
} ; Function
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
