﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\MsgToFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
IniWrite, Documents      , %ini%, ViewState, FolderType
IniWrite, MyDocuments    , %ini%, ViewState, FolderType
IniWrite, Pictures       , %ini%, ViewState, FolderType
IniWrite, MyPictures     , %ini%, ViewState, FolderType
IniWrite, PhotoAlbum     , %ini%, ViewState, FolderType
IniWrite, Music          , %ini%, ViewState, FolderType
IniWrite, MyMusic        , %ini%, ViewState, FolderType
IniWrite, MusicArtist    , %ini%, ViewState, FolderType
IniWrite, MusicAlbum     , %ini%, ViewState, FolderType
IniWrite, Videos         , %ini%, ViewState, FolderType
IniWrite, MyVideos       , %ini%, ViewState, FolderType
IniWrite, VideoAlbum     , %ini%, ViewState, FolderType
IniWrite, UseLegacyHTT   , %ini%, ViewState, FolderType
IniWrite, CommonDocuments, %ini%, ViewState, FolderType
IniWrite, Generic        , %ini%, ViewState, FolderType
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Folder_SetIcon(ThisFolder, FolderIcon, IsPictureView)
{
  ; -------------------------------------------
  if FileExist(ThisFolder)
  {
    if FileExist(FolderIcon)
    {
      ; -------------------------------------------
      SplitPath, FolderIcon, IconExtName, , IconExt, IconName
      StringLower, IconExt, IconExt
      ; -------------------------------------------
      if (IconExt != "ico") ; FolderIcon id Something Other than a ".ico" (Convert it)
      {
        ; -------------------------------------------
        ThisFolderIcon := ThisFolder "\" IconName ".ico"
        if FileExist(ThisFolderIcon)
        {
          FileDelete, %ThisFolderIcon%
        }
        Image_ImgToIco(FolderIcon, ThisFolderIcon) ; (ImageIn, ImageOut) > ImageOut
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        if (InStr(FolderIcon, ThisFolder) == 0) ; "(FolderIco).ico" is Not in FolderIcon (Copy it)
        {
          FileCopy, %FolderIcon%, %ThisFolder%, 1 ; Copy and Overwrite
          ThisFolderIcon := ThisFolder "\" IconName ".ico"
        }
        else ; "(FolderIco).ico" is Already in FolderIcon
        {
          ThisFolderIcon := FolderIcon
        }
      }
      ; -------------------------------------------
      ThisIniFile := ThisFolder "\desktop.ini"
      ; -------------------------------------------
      if FileExist(ThisIniFile)
      {
        FileDelete, %ThisIniFile%
      }
      ; -------------------------------------------
      if (IsPictureView == 1)
      {
        FolderView := "Pictures"
      }
      else
      {
        FolderView := "Generic"
      }
      ; -------------------------------------------
      if (IconExt != "ico")
      {
        Image_ImgToIco(FolderIcon, ThisFolderIcon) ; (ImageIn, ImageOut) > ImageOut
      }
      else
      {
        if (InStr(FolderIcon, ThisFolder) == 0)
        {
          FileCopy, %FolderIcon%, %ThisFolder%, 1
        }
      }
      ; -------------------------------------------
      ; FileSetAttrib, Attributes, FilePattern, OperateOnFolders?, Recurse?
      FileSetAttrib, +S, %ThisFolder%, 2
      ; -------------------------------------------
      ini=%ThisFolder%\desktop.ini
      ; -------------------------------------------
      IniWrite, %ThisFolderIcon%, %ini%, .ShellClassInfo, IconFile
      IniWrite, 0           , %ini%, .ShellClassInfo, IconIndex
      IniWrite, %FolderView%, %ini%, ViewState, FolderType
      ; -------------------------------------------
      FileSetAttrib, +SH, %ini%, 0
      ; -------------------------------------------
      FileSetAttrib, +SH, %ThisFolderIcon%, 0
      ; -------------------------------------------
    } ; [End] if FileExist(FolderIcon)
  } ; [End] if FileExist(ThisFolder)
} ; [End] Folder_SetIcon(ThisFolder, FolderIcon)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
