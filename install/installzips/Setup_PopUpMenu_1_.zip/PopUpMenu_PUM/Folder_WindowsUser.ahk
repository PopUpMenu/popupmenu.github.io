﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Folder_WindowsUser(Folder, Public) ; Folder, Public [0=ThisUser/1=AllUsers] > FoundFolder
{
  /*
  ; -------------------------------------------
  Folder =
  "Windows", "Music", "Pictures", "Videos", "Documents", "Start Menu", "Desktop", "Downloads"
  ; -------------------------------------------
  */
  DriveLetter := ["Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "M", "N", "L", "K", "J", "I", "H", "G", "F", "E", "D", "C", "B", "A"]
  UserName := A_UserName
  FoundFolder := ""
  SytemDrive := ""
  if !Public
  {
    Public := 0
  }
  ; -------------------------------------------
  { ; Find Windows Folder
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\Windows"
      if FileExist(CkFolder)
      {
        SytemDrive := ThisLetter ":\"
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
  } ; End Find Windows Folder
  ; -------------------------------------------
  { ; Get Windows Version
    objWMIService := ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" A_ComputerName "\root\cimv2")
    for objOperatingSystem in objWMIService.ExecQuery("Select * from Win32_OperatingSystem")
    {
      ThisCaption := objOperatingSystem.Caption , OSArchitecture := objOperatingSystem.OSArchitecture, CSDVersion  := objOperatingSystem.CSDVersion, Version := objOperatingSystem.Version
    }
    if (InStr(ThisCaption, "Windows XP") > 0)
    {
      WinXP := 1
    }
    else
    {
      WinXP := 0
    }
  } ; End Get Windows Version
  ; -------------------------------------------
  if SytemDrive
  {
    if Folder
    {
      if (Folder == "Windows")
      {
        CkFolder := SytemDrive "Windows"
      }
      else if (WinXP == 1) ; Windows XP
      {
        if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        {
          CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents\My " Folder
        } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        else if (Folder == "Documents")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\Documents"
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents"
          } ; End (Public == 0)
        } ; End (Folder == "Documents")
        else if (Folder == "Start Menu" or Folder == "Desktop")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\" Folder
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\" Folder
          } ; End (Public == 0)
        } ; End (Folder == "Start Menu" or Folder == "Desktop")
      } ; End (WinXP == 1)
      else if (WinXP == 0) ; Windows 10
      {
        if (Public == 1)
        {
          if (Folder == "Desktop" or Folder == "Documents")
          {
            CkFolder := SytemDrive "Users\Public\" Folder
          } ; End (Folder == "Desktop" or Folder == "Documents")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "ProgramData\Microsoft\Windows\" Folder "\Programs"
          } ; End (Folder == "Start Menu")
        } ; End (Public == 1)
        else if (Public == 0)
        {
          if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop" or Folder == "Downloads")
          {
            CkFolder := SytemDrive "Users\" UserName "\" Folder
          } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "Users\" UserName "\AppData\Roaming\Microsoft\Windows\" Folder "\Programs"
          } ; End (Folder == "Start Menu")
        } ; End (Public == 0)
      } ; End (WinXP == 0)
      ; -------------------------------------------
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
      } ; End FileExist(CkFolder)
    } ; End if Folder
  } ; End if SytemDrive
  ; -------------------------------------------
  if !FoundFolder
  {
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\" Folder
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
    ; -------------------------------------------
    if !FoundFolder
    {
      FoundFolder := SytemDrive
    } ; End if !FoundFolder
  } ; End if !FoundFolder
  ; -------------------------------------------
  return FoundFolder
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
