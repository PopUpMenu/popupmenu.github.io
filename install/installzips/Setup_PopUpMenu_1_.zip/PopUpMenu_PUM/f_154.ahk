﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_DisplayImageImg.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_154(DataArray) ; (154_1)(Obj_Pum_BgImage)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.154.2 == "" or DataArray.154.2 == 1) ; (154_2)(Obj_Pum_BgImage_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Pum_Building_Construct
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ;
      DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Pum_Building_Construct
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [START UP]  Vars
        ; -------------------------------------------
        { ; [GET] Vars
          ; -------------------------------------------
          UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
          ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
          ; -------------------------------------------
          bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
          Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
          Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
          Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
          Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
          Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
          Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
          Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
          Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
          Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
          Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
          ; -------------------------------------------
          XmlBgType          := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
          ; -------------------------------------------
        } ; End [GET] Vars
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
        ; -------------------------------------------
        Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
        ; -------------------------------------------
      } ; End [START UP] Vars
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      DataArray.366.5 := "pum_pumSetting_pumBgImage" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("154", 2, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
      DataArray := Image_GuiControl("155", 1, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
      DataArray := Image_GuiControl("156", 1, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
      ; -------------------------------------------
      { ; Hide (pumBgText) Buttons
        ; -------------------------------------------
        ; [pumBgText]
        GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
        DataArray := Image_GuiControl("166", 0, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
        DataArray := Image_GuiControl("172", 0, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
        DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
        DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
        ; -------------------------------------------
        ; Hide [pumBgText] Tranparency (177)-(181)
        DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
        DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
        DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
        DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
        DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
        ; -------------------------------------------
        ; [pumDimension]
        DataArray := Image_GuiControl("260", 0, 1, DataArray) ; (260_1)(Obj_Pum_IconSize)
        DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
        DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
        DataArray := Image_GuiControl("263", 0, 1, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
        DataArray := Image_GuiControl("266", 0, 1, DataArray) ; (266_1)(Obj_Pum_PumRow)
        DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
        DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
        DataArray := Image_GuiControl("269", 0, 1, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
        DataArray := Image_GuiControl("272", 0, 1, DataArray) ; (272_1)(Obj_Pum_PumColumn)
        DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
        DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
        DataArray := Image_GuiControl("275", 0, 1, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
        ; -------------------------------------------
        ; Hide Color Picker
        Num_Hide := 190
        Loop 48
        {
          Num_Hide := Num_Hide + 1
          DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
        ; -------------------------------------------
      } ; End Hide (pumBgText) Buttons
      ; -------------------------------------------
      DataArray := Image_GuiControl("165", 1, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ;
      if !FileExist(Temp_Selected_Img)
      {
        if FileExist(bg_Selected_img)
        {
          FileCopy, %bg_Selected_img%, %Temp_Selected_Img%, 1
          Sleep, 10
        }
      }
      ; -------------------------------------------
      if FileExist(Temp_Selected_Img) ; [SET] (362_28) (XmlBgType == 1) [Has a Background Image]
      {
        ; -------------------------------------------
        XmlBgType := 1 ; pumBgImage
        ; -------------------------------------------
        if FileExist(Temp_Display_Img) ; [DISPLAY] (Temp_Display_Img.png)
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          GuiControl, PopUpMenu:, g_254, %Temp_Display_Img% ; (254_1)(Obj_MsgImg300x300)
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
          DataArray.254.3 := Temp_Display_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
        } ; End [DISPLAY] (Temp_Display_Img.png)
        else  ; [CREATE] (Temp_Display_Img.png)
        {
          DataArray := Pum_DisplayImageImg(DataArray) ; > DataArray
        } ; End [CREATE] (Temp_Display_Img.png)
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        { ; [SHOW-HIDE] Controls
          ; -------------------------------------------
          DataArray := Image_GuiControl("182", 1, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
          DataArray := Image_GuiControl("183", 1, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
          ; -------------------------------------------
          if (bg_Image_Type == "C") ; Image is a Crop
          {
            ; -------------------------------------------
            DataArray.241.3 := "" ; (241_3)(Obj_Pum_CropLeft_Img [Image Path])
            DataArray.242.3 := "" ; (242_3)(Obj_Pum_CropRight_Img [Image Path])
            DataArray.243.3 := "" ; (243_3)(Obj_Pum_CropUp_Img [Image Path])
            DataArray.244.3 := "" ; (244_3)(Obj_Pum_CropDown_Img [Image Path])
            DataArray.245.3 := "" ; (245_3)(Obj_Pum_CropCenter_Img [Image Path])
            DataArray.246.3 := "" ; (246_3)(Obj_Pum_ZoomIn_Img [Image Path])
            DataArray.247.3 := "" ; (247_3)(Obj_Pum_ZoomOut_Img [Image Path])
            ; -------------------------------------------
            DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
            ; -------------------------------------------
            if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
            {
              Pum_Gui_X := 0
            }
            if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
            {
              Pum_Gui_Y := 0
            }
            ; -------------------------------------------
            if (Pum_Gui_X == 0)
            {
              DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
            }
            else
            {
              DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
            }
            ; -------------------------------------------
            if ((Pum_Gui_X + Pum_Gui_W) >= Img_Gui_W)
            {
              DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
            }
            else
            {
              DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
            }
            ; -------------------------------------------
            if (Pum_Gui_Y == 0)
            {
              DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
            }
            else
            {
              DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
            }
            ; -------------------------------------------
            if ((Pum_Gui_Y + Pum_Gui_H) >= Img_Gui_H)
            {
              DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
            }
            else
            {
              DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
            }
            ; -------------------------------------------
            DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
            ; -------------------------------------------
            if ((Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H > Pum_Gui_Min_H && Pum_Gui_H < Pum_Gui_Max_H))
            {
              DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
              DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
            }
            else if ((Pum_Gui_W > Pum_Gui_Min_W) && (Pum_Gui_H > Pum_Gui_Min_H))
            {
              DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
              DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
            }
            else if ((Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H < Pum_Gui_Max_H))
            {
              DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
              DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
            }
            ; -------------------------------------------
          } ; End (bg_Image_Type == "C")
          ; -------------------------------------------
          else if (bg_Image_Type == "F") ; Image is a Crop
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
            ; -------------------------------------------
            DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
            DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
            DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
            DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
            DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
            DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
            DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
          } ; End (bg_Image_Type == "F")
          ; -------------------------------------------
        } ; End [SHOW-HIDE] Controls
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        { ; [UPDATE] Vars
          ; -------------------------------------------
          DataArray.362.38 := Bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
          DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
          DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
          DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
          DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
          DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
          DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
          DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
          DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
          DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
          DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
        } ; End [UPDATE] Vars
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
      } ; End [DISPLAY] (Temp_Display_Img.png)
      ; -------------------------------------------
      else ; [SET] (362_28) (XmlBgType == 2) [Does Not Have Image for Background]
      {
        ; -------------------------------------------
        XmlBgType := 2 ; pumBgText
        ; -------------------------------------------
        UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
        ; -------------------------------------------
        ; (154_1)(GUI Object: [pum] [pumBgImage])
        ; -------------------------------------------
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; Message Image (SelectImage)
        Showing_Image := "C:\Program Files\PopUpMenu_PUM\image\pum\SelectImage_" UserLang ".png" ; (365_2)(Current User language)
        GuiControl, PopUpMenu:, g_254, %Showing_Image% ; (254_1)(Obj_MsgImg300x300)
        GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        DataArray.254.3 := Showing_Image ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; Message Image (SelectImage)
        ; -------------------------------------------
      } ; End [SET] (362_28) (XmlBgType == 2) [Does Not Have Image for Background]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
    } ; End Button in Normal State
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
