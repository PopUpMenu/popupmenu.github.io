﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_New135.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_Del135.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_DisplayPumApp.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_290(DataArray) ; (290)(Obj_BrowserPum)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (DataArray.363.12 == "") ; UserPictureFolder
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
    DataArray.363.12 := UserPictureFolder
    ; -------------------------------------------
  } ; if (DataArray.363.12 == "") ; UserPictureFolder
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Animated Building Construct
  ; -------------------------------------------
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------"pumApplication"
  if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) && (InStr(ScriptType, "pumApplication") == 0) )
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; Show (Animate) Pum_Building_Construct
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    if (n_521 == 170)
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ; -------------------------------------------
    } ;  (n_521 == 170)
    else
    {
      global s_521 := 1 ; Show
      SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    } ; [End] else
    ; -------------------------------------------
  } ; [ScriptTypes] == 0
  ; -------------------------------------------
  ; Animated Building Construct
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  
  
  
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Select / UnSelect (290)(Obj_BrowserPum)
  ; -------------------------------------------
  if (DataArray.290.2 == "" or DataArray.290.2 == "0" or DataArray.290.2 == "1") ; [UseCommonBrowser = 1][All Browsers Same Pum]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("290", 2, 1, DataArray) ; [UseCommonBrowser = 2][Each Browser Different pum]
    ; -------------------------------------------
    DataArray.290.2 := 2 ; [UseCommonBrowser = 2][Each Browser Different pum]
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Write New Value to (InternetBrowserPum.txt)
    ; -------------------------------------------
    File_InternetBrowserPum := A_Appdata "\PopUpMenu_PUM\system\InternetBrowserPum.txt"
    ; -------------------------------------------
    if FileExist(File_InternetBrowserPum) ; File Exist
    {
      ; -------------------------------------------
      FileDelete, %File_InternetBrowserPum%
      Sleep, 250
    }
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, 2, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum]
    Sleep, 250
    ; -------------------------------------------
    ; Write New Value to (InternetBrowserPum.txt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [UseCommonBrowser = 2][Each Browser Different pum]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("290", 1, 1, DataArray) ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    DataArray.290.2 := 1 ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Write New Value to (InternetBrowserPum.txt)
    ; -------------------------------------------
    File_InternetBrowserPum := A_Appdata "\PopUpMenu_PUM\system\InternetBrowserPum.txt"
    ; -------------------------------------------
    if FileExist(File_InternetBrowserPum) ; File Exist
    {
      ; -------------------------------------------
      FileDelete, %File_InternetBrowserPum%
      Sleep, 250
    }
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 2][Each Browser Different pum]
    Sleep, 250
    ; -------------------------------------------
    ; Write New Value to (InternetBrowserPum.txt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
  ; Select / UnSelect (290)(Obj_BrowserPum)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Display Objects
  ; -------------------------------------------
  if (DataArray.367.1 != "windows") ; [Windows Desktop is NOT Active]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Windows Desktop is NOT Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Display (135_1)(Obj_ImageSelect2)
    ; -------------------------------------------
    if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; (361)(9)(ThisPumProcessXml [Full File Path])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Windows Desktop is NOT Active]
      ;
      ; [Default pum Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      ; This is when user runs the default pum
      ; from an existing application pum
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Windows Desktop is NOT Active]
        ; [Default pum Active]
        ;
        ; [Internet Browser Application Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Windows Desktop is NOT Active]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [Common Browser pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [Common Browser pum Exist]
          ; -------------------------------------------
          else if !FileExist(ThisPum) ; [Common Browser pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum does NOT Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
            ; -------------------------------------------
            if (InternetConnectCheck() != 0)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
            }
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161)(Obj_Pum_Del))
            DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_New135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [Common Browser pum does NOT Exist]
          ; -------------------------------------------
        } ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Windows Desktop is NOT Active]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [pum Exist]
          ; -------------------------------------------
          else if !FileExist(ThisPum) ; [pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [pum does NOT Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161)(Obj_Pum_Del))
            DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_New135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [pum does NOT Exist]
          ; -------------------------------------------
        } ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; -------------------------------------------
      } ; [Internet Browser Application Active]
      ; -------------------------------------------
    } ; (Default pum) is (Active)
    else ; [Default pum is NOT Active]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Windows Desktop is NOT Active]
      ;
      ; [Default pum is NOT Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Windows Desktop is NOT Active]
        ; [Default pum is NOT Active]
        ;
        ; [Internet Browser Application Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Windows Desktop is NOT Active]
          ; [Default pum is NOT Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [Common Browser pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [Common Browser pum Exist]
          ; -------------------------------------------
          else if !FileExist(ThisPum) ; [Common Browser pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum does NOT Exist] [RUN] Pum_DisplayPumApp("New", DataArray)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
            ; -------------------------------------------
            DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; Pum Settings Image with gear
            ; -------------------------------------------
            if (InternetConnectCheck() != 0)
            {
              DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; Pum Contact Image with Mailbox
            }
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161)(Obj_Pum_Del))
            DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := "C:\Program Files\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_New135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [Common Browser pum does NOT Exist]
          ; -------------------------------------------
        } ; if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ; -------------------------------------------
        else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Windows Desktop is NOT Active]
          ; [Default pum is NOT Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
					AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
					ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ;
            ; [pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
            DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_Del135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [pum Exist]
          ; -------------------------------------------
          else if !FileExist(ThisPum) ; [pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ;
            ; [pum does NOT Exist] [RUN] Pum_DisplayPumApp("New", DataArray)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161)(Obj_Pum_Del))
            DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App))
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ThisAppPath := DataArray.367.5
            ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
            Img135 := Img_New135(ArrayIn)
            DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Animated Building Construct
            ; -------------------------------------------
            ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------"pumApplication"
            if ( (InStr(ScriptType, "pumBgImage") == 0) && (InStr(ScriptType, "pumBgText") == 0) && (InStr(ScriptType, "pumDimension") == 0) && (InStr(ScriptType, "pumContact") == 0) )
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Show (Animate) Pum_Building_Construct
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              } ;  (n_521 == 170)
              else
              {
                ; -------------------------------------------
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
                DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                ; -------------------------------------------
              } ; [End] else
              ; -------------------------------------------
            } ; does NOT Equal any of these pum [ScriptTypes]
            ; -------------------------------------------
            ; Animated Building Construct
			      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; -------------------------------------------
          } ; [pum does NOT Exist]
          ; -------------------------------------------
        } ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; -------------------------------------------
      } ; [Internet Browser Application Active]
      ; -------------------------------------------
    } ; [Default pum is NOT Active]
    ; -------------------------------------------
  } ; [Windows Desktop is NOT Active]
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; f_290(DataArray) ; (290)(Obj_BrowserPum)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
