﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_520: ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
{
  ; -------------------------------------------
  ; URL Animate
  ; -------------------------------------------
  ;
  ; (_w480 x h270_)
  ; This Animation will Repeat
  ; Anamation Continues from Last Frame Shown
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (URL)
  ; global n_520 := 1 ; Start Frame Number
  ; global s_520 := 1 ; Show
  ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (URL)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (URL)
  ; global s_520 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (URL)
  ;
  ; [ANIMATE] Start/Show in This File
  ; (071_1)(Obj_RunUrlOfl_URL)
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 60
  ; -------------------------------------------
  if (s_520 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_520 > Total_Images)
    {
      global n_520 := 1
    }
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_137, C:\Program Files\PopUpMenu_PUM\image\gui\(520)_%n_520%.png ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    Gui_ObjectSize("137", DataArray) ; > Nothing
    ; -------------------------------------------
    if (ShowAnimationChange == 0)
    {
      GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
      global ShowAnimationChange := 1
    }
    ; -------------------------------------------
    global n_520 := n_520 + 1
    ; -------------------------------------------
  } ; [End] Show Animation
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_520, Off ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; (004_1)(GUI Object: Ok Button)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
