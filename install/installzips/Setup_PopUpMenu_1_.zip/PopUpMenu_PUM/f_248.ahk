﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Select_FileFolder.ahk
#Include C:\Program Files\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_248(DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
{
  ; -------------------------------------------
  Obj_Ofl_1LAppIco_Img := DataArray.248.3 ; (248_3)(Obj_Ofl_1LAppIco_Img [Image Path])
  SplitPath, Obj_Ofl_1LAppIco_Img, , Folder_OflIcon
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Selected_Array := Select_FileFolder(DataArray.365.2, "AnyImage", Folder_OflIcon, ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ThisFolderIcon := Selected_Array.1
  ; -------------------------------------------
  if FileExist(ThisFolderIcon)
  {
    ; -------------------------------------------
    DataArray := f_102(ThisFolderIcon, DataArray) ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  } ; [End] if FileExist(ThisFolderIcon)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
