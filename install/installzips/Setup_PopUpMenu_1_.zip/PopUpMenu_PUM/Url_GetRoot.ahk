﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetRoot(Url_Address) ; > Url_Root (http://somename.xxx) or (http://xxx.somename.xxx)
{
  ; -------------------------------------------
  Url_Root := ""
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (StrLen(Url_Address) > 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Common) Get Root Address
    ; -------------------------------------------
    Url_Address := StrReplace(Url_Address, "http://", "") ; (307_2)(Url_Address)
    Url_Address := StrReplace(Url_Address, "https://", "") ; (307_2)(Url_Address)
    Url_Address := StrReplace(Url_Address, "ftps://", "") ; (307_2)(Url_Address)
    ; -------------------------------------------
    SlashPos := InStr(Url_Address, "/")
    ; -------------------------------------------
    if (SlashPos > 0) ; First Forward Slash
    {
      ; -------------------------------------------
      Ckeck_Address := SubStr(Url_Address, SlashPos) ; Remove Everything Before First Forward Slash
      Check_Len := StrLen(Ckeck_Address)
      Url_Root := SubStr(Url_Address, 1, SlashPos) ; http://www.ThisAddress.com
      ; -------------------------------------------
    }
    else
    {
      Url_Root := Url_Address
    }
    ; -------------------------------------------
    Url_Root := StrReplace(Url_Root, "/", "")
    ; -------------------------------------------
    Url_Root := "http://" Url_Root
    ; -------------------------------------------
    ; (Common) Get Root Address
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (StrLen(Url_Address) > 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return Url_Root
  ; -------------------------------------------
} ; [End] Url_GetRoot(Url_Address) ; > [Url_Root, WasRoot]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
