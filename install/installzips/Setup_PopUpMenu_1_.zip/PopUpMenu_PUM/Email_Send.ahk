﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Email_Info.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Email_Subject := "(App Request)(" AppName ")(" UserLang ")"
; Email_Subject := "(Contact)"
; Email_Subject := "(ID MisMatch)"
; Email_Subject := "(InStaller Error)"
; Email_Subject := "(Plugin Install)(" AddonProcessName ")(" AddonProcessLang ")"
; Email_Subject := "(SysRefresh Not Deleted)"
; Email_Subject := "(Update)"
; Email_Subject := "(Was Not Installed)"
; Email_Subject := "(InStaller Error)"
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Email_Send(Email_Subject, Email_Body)
{
  ; -------------------------------------------
  HasConnection := InternetConnectCheck()
  ; -------------------------------------------
  if (HasConnection == 1 && Email_Body != "")  ; Has Internet Connection an Email_Body is NOT Blank
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Email_Info()
    ; -------------------------------------------
    EmailInfoArray  := Email_Info()
    ; -------------------------------------------
    BoardID         := EmailInfoArray.1
    SystemName      := EmailInfoArray.2
    WindowsVersion  := EmailInfoArray.3
    IpPublic        := EmailInfoArray.4
    IpPrivate       := EmailInfoArray.5
    HasAdminRights  := EmailInfoArray.6
    ThisCity        := EmailInfoArray.7
    ThisRegion      := EmailInfoArray.8
    ThisPostal      := EmailInfoArray.9
    ThisCountry     := EmailInfoArray.10
    ThisTimeZone    := EmailInfoArray.11
    LangPopUpMenu   := EmailInfoArray.12
    LangSystem      := EmailInfoArray.13
    ContactName     := EmailInfoArray.14
    ContactEmail    := EmailInfoArray.15
    ; -------------------------------------------
    ; Email_Info()
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Email_Subject := Email_Subject " (" BoardID ")"
    ; -------------------------------------------
    EmailFolder := A_AppData "\PopUpMenu_PUM\emailtemp"
    if !FileExist(EmailFolder)
    {
      FileCreateDir, %EmailFolder%
      Sleep, 10
    }
    ; -------------------------------------------
    PumMailSend  := A_AppData "\PopUpMenu_PUM\emailtemp\PopUpMenu_MailSend.exe"
    ; -------------------------------------------
    ; (PopUpMenu_MailSend.exe) Will Not Work in in (C:\Program Files)
    ; (_07-Apr-2022_14-47-56_)
    ; -------------------------------------------
    if !FileExist(PumMailSend)
    {
      SupportPumMailSend := "C:\Program Files\PopUpMenu_PUM\support\PopUpMenu_MailSend.exe"
      FileCopy, %SupportPumMailSend%, %EmailFolder%, 1
      Sleep, 10
    }
    ; -------------------------------------------
    EmailFile := A_AppData "\PopUpMenu_PUM\emailtemp\EmailFile.bat"
    EmailFileLnk := A_AppData "\PopUpMenu_PUM\emailtemp\EmailFile.lnk"
    ; -------------------------------------------
    EmailTempFolder := A_AppData "\PopUpMenu_PUM\emailtemp"
    if !FileExist(EmailTempFolder)
    {
      FileCreateDir, %EmailTempFolder%
      Sleep, 10
    }
    ; -------------------------------------------
    Email_To       := "popupmenu.system@gmail.com"
    ; -------------------------------------------
    Email_From     := "popupmenu@yahoo.com"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; Old Password
    ; Email_PassWord := """yhanndksgpskbzps"""
    ; -------------------------------------------
    ; New Password (_21_Mar_2024_)(_15_27_39_)
    ;~ Email_PassWord := """aqvicmdykuaisioc"""
    ; -------------------------------------------
    ; New Password (_10_Apr_2025_)(_11_03_51_)
    Email_PassWord := """rlhzcoifuoeshvlo"""
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Email_Subject  := """" Email_Subject """"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (InStr(Email_Subject, "EmailKeepActive") == 0)
    {
      ; -------------------------------------------
      Line_1  := "**************************************"
      Line_2  := "BoardID"                A_Tab A_Tab      BoardID
      Line_3  := "----------------------------------"
      Line_4  := "Entered_Name"           A_Tab A_Tab      ContactName
      Line_5  := "Entered_Email"          A_Tab A_Tab      ContactEmail
      Line_6  := "----------------------------------"
      Line_7  := "System_User_Name"       A_Tab A_Tab      A_UserName
      Line_8  := "Has_Admin_Rights"       A_Tab A_Tab      HasAdminRights
      Line_9  := "PopUpMenu_Lang"         A_Tab A_Tab      LangPopUpMenu
      Line_10  := "System_Lang"           A_Tab A_Tab      LangSystem
      Line_11  := "----------------------------------"
      Line_12  := "AutoHotKey_Version"   A_Tab A_Tab       A_AhkVersion
      Line_13 := "Windows_Version"       A_Tab A_Tab       WindowsVersion
      Line_14 := "System_Name"           A_Tab A_Tab       SystemName
      Line_15 := "Screen_DPI"            A_Tab A_Tab       A_ScreenDPI
      Line_16 := "Screen_Width"          A_Tab A_Tab       A_ScreenWidth
      Line_17 := "Screen_Height"         A_Tab A_Tab       A_ScreenHeight
      Line_18 := "----------------------------------"
      Line_19 := "Public_IP"             A_Tab A_Tab       IpPublic
      Line_20 := "Private_IP"            A_Tab A_Tab       IpPrivate
      Line_25 := "Time_Zone"             A_Tab A_Tab       ThisTimeZone
      Line_21 := "City"                  A_Tab A_Tab       ThisCity
      Line_22 := "Region"                A_Tab A_Tab       ThisRegion
      Line_23 := "Postal_Code"           A_Tab A_Tab       ThisPostal
      Line_24 := "Country"               A_Tab A_Tab       ThisCountry
      Line_25 := "**************************************"
      ; -------------------------------------------
      ThisNum := 0
      Email_Array := ""
      Loop 25
      {
        ThisNum := ThisNum + 1
        ThisLine := Line_%ThisNum%
        Email_Array := EmailSendArrayAdd(Email_Array, ThisLine, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      }
      ; -------------------------------------------
      Email_Body := StrReplace(Email_Body, "`n", "***Return***<<<Return>>>")
      Body_Array := StrSplit(Email_Body, "***Return***")
      for Index, ThisLine in Body_Array
      {
        if (InStr(ThisLine, "<<<Return>>>") > 0)
        {
          ThisLine := StrReplace(ThisLine, "<<<Return>>>", "   ")
        }
        Email_Array := EmailSendArrayAdd(Email_Array, ThisLine, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      }
      ; -------------------------------------------
      WriteBody := ""
      for Index, ThisLine in Email_Array
      {
        WriteBody := WriteBody " -M """ ThisLine """"
      }
      ; -------------------------------------------
    } ; if (InStr(Email_Subject, "EmailKeepActive") == 0)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    WriteLine := PumMailSend " -to " Email_To " -from " Email_From " -ssl -port 465 -auth -smtp smtp.mail.yahoo.com -sub test +cc +bc -v -user popupmenu -pass " Email_PassWord " -subject " Email_Subject WriteBody
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FileDelete, %EmailFile%
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, `n, %EmailFile% ; UTF-8
    FileAppend, `n, %EmailFile% ; UTF-8
    FileAppend, %WriteLine%`n, %EmailFile% ; UTF-8
    Sleep, 250
    ; -------------------------------------------    
    ;
    ; -------------------------------------------
    FileCreateShortcut, %EmailFile%, %EmailFileLnk%
    Sleep, 500
    Run %EmailFileLnk% , , Hide
    Sleep, 500
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Wait until Process is NOT Running
    ; -------------------------------------------
    ThisProcess := "EmailFile.bat"
    Process, Exist, %ThisProcess%
    ; -------------------------------------------
    while (ErrorLevel != 0) ; Process Exist
    {
      ; -------------------------------------------
      Sleep, 500
      ; -------------------------------------------
      Process, Exist, %ThisProcess%
      ; -------------------------------------------
    } ; [End] while (ErrorLevel == 0)
    ; -------------------------------------------
    ; Wait until Process is NOT Running
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Delete Old Files
    ; -------------------------------------------
    FileDelete, %EmailFile%
    FileDelete, %EmailFileLnk%
    ; -------------------------------------------
    ; Delete Old Files
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (HasConnection == 1)  ; Has Internet Connection
  ; -------------------------------------------
} ; [End] Email_Send(Email_Subject, Email_Body)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
EmailSendArrayAdd(ThisArray, AddThis, ThisPos) ; ThisArray, AddThis, ThisPos > ThisArray
{
  ; -------------------------------------------
  if !ThisPos
  {
    ThisPos := "End"
  }
  ; -------------------------------------------
  if AddThis
  {
    CheckThis := ThisArray[1]
    if CheckThis
    {
      if (ThisPos == "End")
      {
        ThisArray.Push(AddThis) ; Adds (AddThis) to End
      }
      else
      {
        if (ThisPos == 0)
        {
          ThisPos := 1
        }
        ThisArray.InsertAt(ThisPos, AddThis) ; Adds (AddThis) at (ThisPos)
      }
    } ; End if CheckThis
    else
    {
      ThisArray := []
      ThisArray[1] := AddThis
    } ; End else
  } ; End if AddThis
  return ThisArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
