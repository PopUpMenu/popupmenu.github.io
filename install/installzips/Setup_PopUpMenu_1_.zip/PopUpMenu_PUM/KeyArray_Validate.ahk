﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyArray_Validate(DataArray)
{
  ; -------------------------------------------
  /* Info
  [CHECK] v_301_2 Length (Longer than 0) ; (301_2)(Key_ArrayNumbers [Array])
  [CHECK] XXX_Down to XXX_Up Keys
  [SET] (123) KeyValid (0,1)
  */
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; StartUpVars
    v_301_2 := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
    KeyArrayLen := v_301_2.MaxIndex() ; (301_2)(Key_ArrayNumbers [Array])
    v_004_2 := 1 ; (004_2)(Obj_ok_Sel [0,1,3])
  } ; End StartUpVars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (KeyArrayLen == "")
  {
    v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
  } ; End !KeyArrayLen
  ; -------------------------------------------
  { ; (VALIDATE) Up,Down Keys
    ; -------------------------------------------
    if (Array_ItemExist(v_301_2, "(009)") != Array_ItemExist(v_301_2, "(012)")) ; (301_2)(Key_ArrayNumbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
    }
    ; -------------------------------------------
    if (Array_ItemExist(v_301_2, "(014)") != Array_ItemExist(v_301_2, "(017)")) ; (301_2)(Key_ArrayNumbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
    }
    ; -------------------------------------------
    if (Array_ItemExist(v_301_2, "(051)") != Array_ItemExist(v_301_2, "(054)")) ; (301_2)(Key_ArrayNumbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
    }
    ; -------------------------------------------
    if (Array_ItemExist(v_301_2, "(058)") != Array_ItemExist(v_301_2, "(061)")) ; (301_2)(Key_ArrayNumbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
    }
    ; -------------------------------------------
  } ; End (VALIDATE) Up,Down Keys
  ; -------------------------------------------
  { ; (VALIDATE) Check if (123)(Edit Text Input) is Enpty
    ; -------------------------------------------
    GuiControlGet, v_123, PopUpMenu:, g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
    ThisStrLen := StrLen(v_123) ; (123_1)(Obj_Key_EditFeild_TextInput)
    ; -------------------------------------------
    if (ThisStrLen == 0 && KeyArrayLen == "")
    {
      v_004_2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
    } ; End (ThisStrLen == 0 && !Check_KeyArray)
  } ; End (VALIDATE) ? is any Key Selected / (123)(Edit Text Input) is Enpty
  ; -------------------------------------------
  DataArray.301.3 := v_004_2 ; (301_3)(Key_ArrayValid [1,3])/(004_2)(Obj_ok_Sel [0,1,3])
  if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  {
    DataArray := Image_GuiControl("004", v_004_2, 0, DataArray) ; (004_1)(Obj_ok)/(004_2)(Obj_ok_Sel [0,1,3])
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
