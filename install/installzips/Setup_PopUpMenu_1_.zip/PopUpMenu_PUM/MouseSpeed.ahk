﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MouseSpeed(ThisMouseSpeed) ; ThisMouseSpeed = 1 (slowest) to 20 (fastest)
{
  SPI_SETMOUSESPEED   := 0x71  ;Mouse seeting to change
  DllCall("SystemParametersInfo", UInt,SPI_SETMOUSESPEED, UInt,0, UInt,ThisMouseSpeed, UInt,0)
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

