﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_GetRestoreFile.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_163(DataArray) ; (163)(Obj_Pum_Restore)
{
	; -------------------------------------------
	if (DataArray.163.2 == "" or DataArray.163.2 == 0 or DataArray.163.2 == 1) ; Was NOT Selected, [SET] to Selected
	{
		; -------------------------------------------
		DataArray := Image_GuiControl("163", 2, 1, DataArray) ; (163)(Obj_Pum_Restore)
		; -------------------------------------------
		File_PumRestore := Pum_GetRestoreFile(UserLang) ; > File_PumRestore
		; -------------------------------------------
		if FileExist(File_PumRestore) ; Pum Restore Zip was Selected
		{
			; -------------------------------------------
			DataArray.163.4 := File_PumRestore ; (163)(04)(Obj_Pum_Restore_Img [Zip File Path])
			; -------------------------------------------
			DataArray.366.5 := "pumRestore" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
			; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      Gui, PopUpMenu:Color, faf277 ; Yellow
      ; -------------------------------------------
			DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
			; -------------------------------------------
		} ; Pum Restore Zip was Selected
		else ; Pum Restore Zip was NOT Selected
		{
			; -------------------------------------------
			DataArray.163.4 := "" ; (163)(04)(Obj_Pum_Restore_Img [Zip File Path])
			; -------------------------------------------
			DataArray := Image_GuiControl("163", 1, 1, DataArray) ; (163)(Obj_Pum_Restore)
			; -------------------------------------------
		} ; Pum Restore Zip was NOT Selected
		; -------------------------------------------
	}
	else if (DataArray.163.2 == 2) ; Was Selected, [SET] to NOT Selected
	{
		; -------------------------------------------
		DataArray.163.4 := "" ; (163)(04)(Obj_Pum_Restore_Img [Zip File Path])
		; -------------------------------------------
		DataArray := Image_GuiControl("163", 1, 1, DataArray) ; (163)(Obj_Pum_Restore)
		; -------------------------------------------
		Sys_EnableDisable("Enable") ; "Enable" or "Disable"
		; -------------------------------------------
		Gui, PopUpMenu:Color, e7d8fe ; Purple
		; -------------------------------------------
	} ; Was NOT Selected, [SET] to Selected
	; -------------------------------------------
	;
	; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
