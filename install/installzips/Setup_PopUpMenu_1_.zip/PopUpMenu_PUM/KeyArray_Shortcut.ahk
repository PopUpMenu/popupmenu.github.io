﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyArray_Shortcut(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ; Creates
  ; (301_8)([key] KeyArray_Keystroke for Shortcut)
  ; From
  ; (301_2)([key] KeyArray_Numbers)
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    Key_ArrayNumbers := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  Ckeck_Array := Key_ArrayNumbers.1 ; (301_2)(Key_ArrayNumbers [Array])
  ; -------------------------------------------
  if (Ckeck_Array != "") ; Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
  {
    ; -------------------------------------------
    Key_KeyArrayShortcut := "" ; (301_8)(Key_KeyArrayShortcut [Array])
    ; -------------------------------------------
    for Index, This_KeyNum in Key_ArrayNumbers ; (301_2)(Key_ArrayNumbers [Array])
    {
      ; -------------------------------------------
      if (SubStr(This_KeyNum, 1, 1) == "~") ; User Written Text
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, This_KeyNum, "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(008)") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt down]" / "[Alt Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Alt Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt up]" / "[Alt Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Alt Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; (008_1)(GUI Object: [key] Alt)
        {
          ; -------------------------------------------
          ; "[Alt"] / "[Alt]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Alt]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (008_1)(GUI Object: [key] Alt)
      ; -------------------------------------------
      else if (This_KeyNum == "(010)") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt left down]" / "[LAlt Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LAlt Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt left up]" / "[LAlt Up]"
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LAlt Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; "[Alt left]" / "[LAlt]"
        {
          ; -------------------------------------------
          ; "[Alt left]" / "[LAlt]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LAlt]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (010_1)(GUI Object: [key] Alt Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(011)") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt right down]" / "[RAlt Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RAlt Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt right up]" / "[RAlt Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RAlt Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; "[Alt right]" / "[RAlt]"
        {
          ; -------------------------------------------
          ; "[Alt right]" / "[RAlt]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RAlt]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (011_1)(GUI Object: [key] Alt Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(013)") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        ; -------------------------------------------  
        ; "[Caps]" / "[CapsLock]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[CapsLock]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (This_KeyNum == "(015)") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl left down]" / "[LCtrl Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LCtrl Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl left up]" / "[LCtrl Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LCtrl Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl left]" / "[LCtrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl left]" / "[LCtrl]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LCtrl]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Ctrl left]" / "[LCtrl]"
      } ; End (015_1)(GUI Object: [key] Ctrl Left)
      ; -------------------------------------------
      else if (Next_KeyNum_1 == "(016)") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl right down]" / "[RCtrl Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RCtrl Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl right up]" / "[RCtrl Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RCtrl Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl right]" / "[RCtrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl right]" / "[RCtrl]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RCtrl]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Ctrl right]" / "[RCtrl]"
      } ; End (016_1)(GUI Object: [key] Ctrl Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(018)") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------  
        ; "[Enter]" / "[Enter]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Enter]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; End (018_1)(GUI Object: [key] Enter)
      ; -------------------------------------------
      else if (This_KeyNum == "(020)") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------  
        ; "[Esc]" / "[Esc]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Esc]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; End (020_1)(GUI Object: [key] Esc)
      ; -------------------------------------------
      else if (This_KeyNum == "(022)") ; (022_1)(GUI Object: [key] F1)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F1]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (This_KeyNum == "(023)") ; (023_1)(GUI Object: [key] F2)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F2]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(024)") ; (024_1)(GUI Object: [key] F3)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F3]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(025)") ; (025_1)(GUI Object: [key] F4)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F4]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(026)") ; (026_1)(GUI Object: [key] F5)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F5]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(027)") ; (027_1)(GUI Object: [key] F6)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F6]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(028)") ; (028_1)(GUI Object: [key] F7)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F7]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(029)") ; (029_1)(GUI Object: [key] F8)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F8]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(030)") ; (030_1)(GUI Object: [key] F9)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F9]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(031)") ; (031_1)(GUI Object: [key] F10)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F10]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(032)") ; (032_1)(GUI Object: [key] F11)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F11]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(033)") ; (033_1)(GUI Object: [key] F12)
      {
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[F12]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(034)") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        ; -------------------------------------------
        ; "[# 0]" / "[Numpad0]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad0]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(035)") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        ; -------------------------------------------
        ; "[# 1]" / "[Numpad1]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad1]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(036)") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        ; -------------------------------------------
        ; "[# 2]" / "[Numpad2]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad2]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(037)") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        ; -------------------------------------------
        ; "[# 3]" / "[Numpad3]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad3]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(038)") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        ; -------------------------------------------
        ; "[# 4]" / "[Numpad4]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad4]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(039)") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        ; -------------------------------------------
        ; "[# 5]" / "[Numpad5]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad5]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(040)") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        ; -------------------------------------------
        ; "[# 6]" / "[Numpad6]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad6]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(041)") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        ; -------------------------------------------
        ; "[# 7]" / "[Numpad7]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad7]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(042)") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        ; -------------------------------------------
        ; "[# 8]" / "[Numpad8]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad8]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(043)") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        ; -------------------------------------------
        ; "[# 9]" / "[Numpad9]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Numpad9]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(044)") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        ; -------------------------------------------
        ; "[# +]" / "[NumpadAdd]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadAdd]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(045)") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        ; -------------------------------------------
        ; "[# /]" / "[NumpadDiv]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadDiv]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(046)") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        ; -------------------------------------------
        ; "[# .]" / "[NumpadDot]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadDot]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(047)") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        ; -------------------------------------------  
        ; "[# Enter]" / "[NumpadEnter]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadEnter]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(048)") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        ; -------------------------------------------
        ; "[# *]" / "[NumpadMult]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadMult]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(049)") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        ; -------------------------------------------
        ; "[# -]" / "[NumpadSub]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[NumpadSub]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(050)") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift down]" / "[Shift Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Shift Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift up]" / "[Shift Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Shift Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; (050_1)(GUI Object: [key] Shift)
        {
          ; -------------------------------------------
          ; "[Shift]" / "[Shift]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Shift]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (050_1)(GUI Object: [key] Shift)
      ; -------------------------------------------
      else if (This_KeyNum == "(052)") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift left down]" / "[LShift Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LShift Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift left up]" / "[LShift Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LShift Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; "[Shift left]" / "[LShift]"
        {
          ; -------------------------------------------
          ; "[Shift left]" / "[LShift]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LShift]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (052_1)(GUI Object: [key] Shift Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(053)") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 2] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift right down]" / "[RShift Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RShift Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift right up]" / "[RShift Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RShift Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
        else ; "[Shift right]" / "[RShift]"
        {
          ; -------------------------------------------
          ; "[Shift right]" / "[RShift]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RShift]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        }
      } ; End (053_1)(GUI Object: [key] Shift Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(055)") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        ; "[Tab]" / "[Tab]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Tab]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; End (055_1)(GUI Object: [key] Tab)
      ; -------------------------------------------
      else if (This_KeyNum == "(057)") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win down]" / "[Win Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Win Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win up]" / "[Win Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Win Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else ; "[Win]" / "[Win]"
        {
          ; -------------------------------------------
          ; "[Win]" / "[Win]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Win]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Win]" / "[Win]"
      } ; End (057_1)(GUI Object: [key] Windows Key)
      ; -------------------------------------------
      else if (This_KeyNum == "(059)") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win left down]" / "[LWin Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LWin Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win left up]" / "[LWin Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LWin Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else
        {
          ; -------------------------------------------
          ; "[Win left]" / "[LWin]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[LWin]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Win left]" / "[LWin]"
      } ; End (059_1)(GUI Object: [key] Windows Key Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(060)") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win right down]" / "[RWin Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RWin Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win right up]" / "[RWin Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RWin Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else
        {
          ; -------------------------------------------
          ; "[Win right]" / "[RWin]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[RWin]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Win right]" / "[RWin]"
      } ; End (060_1)(GUI Object: [key] Windows Key Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(074)") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := Key_ArrayNumbers[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl down]" / "[Ctrl Down]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Ctrl Down]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl up]" / "[Ctrl Up]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Ctrl Up]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl]" / "[Ctrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl]" / "[Ctrl]"
          ; -------------------------------------------
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Ctrl]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
          ; -------------------------------------------
        } ; End "[Ctrl]" / "[Ctrl]"
      } ; End (074_1)(GUI Object: [key] Ctrl)
      ; -------------------------------------------
      else if (This_KeyNum == "(075)") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        ; "[Del]" / "[Delete]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Delete]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(076)") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        ; "[End]" / "[End]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[End]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(077)") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        ; "[Home]" / "[Home]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Home]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(078)") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        ; "[Insert]" / "[Insert]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[Insert]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(079)") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        ; "[PgDn]" / "[PgDn]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[PgDn]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(080)") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        ; "[PgUp]" / "[PgUp]"
        ; -------------------------------------------
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, "[PgUp]", "End") ; (301_8)(Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End for Index, This_KeyNum in (301_2)([key] [Line 3] Keystroke Array)
    ; -------------------------------------------
    DataArray.301.8 := Key_KeyArrayShortcut ; (301_8)(Key_KeyArrayShortcut [Array])
  } ; End if (Ckeck_Array != "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
