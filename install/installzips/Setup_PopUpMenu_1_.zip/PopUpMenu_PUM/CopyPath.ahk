﻿#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CopyPath(PathFrom, PathTo, OverWrite)
{
	; -------------------------------------------
	if FileExist(PathFrom)
	{
	  ; -------------------------------------------
	  Loop, Files, %PathFrom%\*.*, R
	  {
  		; -------------------------------------------
		  ThisFilePath := A_LoopFileFullPath
			SplitPath, ThisFilePath, OutFileName
			; -------------------------------------------
			;
			; -------------------------------------------
			CopyFilePath := StrReplace(ThisFilePath, PathFrom, PathTo)
			SplitPath, CopyFilePath, , CopyFileDir
			; -------------------------------------------
			if !FileExist(CopyFileDir)
			{
			  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			  Msg := Msg "NOT EXIST Copy = " ThisFilePath "`n"
			  CoordMode, ToolTip, Screen
			  ToolTip, %Msg%, 0, 0
			  Msg := ""
			  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			  ;
				; -------------------------------------------
				FileCreateDir, %CopyFileDir%
				Sleep, 1
				; -------------------------------------------
			}
			; -------------------------------------------
			;
			; -------------------------------------------
			if (OverWrite == 1)
			{
		    FileCopy, %ThisFilePath%, %CopyFilePath%, 1
				while !FileExist(CopyFilePath)
				{
					Sleep, 1
				}
			}
			else
			{
				if !FileExist(CheckThisFilePath)
				{
					FileCopy, %ThisFilePath%, %CopyFilePath%
					while !FileExist(CopyFilePath)
					{
						Sleep, 1
					}
				}
		  }
	  }
	}
	else
	{
		Msg := Msg "PathFrom = " PathFrom "`n"
		Msg := Msg "Does Not Exist`n"
		MsgBox, 4096, , %Msg%
		Msg := ""
	}
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
PathFrom := "Z:\MGLauncher_1"
PathTo := "C:\MGLauncher_1"
CopyPath(PathFrom, PathTo, 0)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
