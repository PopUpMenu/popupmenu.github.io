﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Audio_Functions.ahk
;#Include C:\Program Files\PopUpMenu_PUM\SoundExist.ahk ; SoundExist() ;  > 0 -OR- 1
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; If Sound is Heard Right Now (Will Return 1)
; If NO Sound is Heard Right Now (Will Return 0)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SoundExist() ;  > 0 -OR- 1
{
	; -------------------------------------------
	SoundExist_SoundHeard := 0
	triggervol := 0.03
	; -------------------------------------------
	audioMeter := VA_GetAudioMeter()
	VA_IAudioMeterInformation_GetMeteringChannelCount(audioMeter, channelCount)
	VA_GetDevicePeriod("capture", devicePeriod)
	; -------------------------------------------
	VA_IAudioMeterInformation_GetPeakValue(audioMeter, peakValue) 
	if (SoundExist_SoundHeard == 0)
	{
		while (peakValue>triggervol)
		{
			; -------------------------------------------
			Sleep, 100
			VA_IAudioMeterInformation_GetPeakValue(audioMeter, peakValue)	
			; -------------------------------------------
			SoundExist_SoundHeard := 1
			; -------------------------------------------
			break
			; -------------------------------------------
		} ; while (peakValue>triggervol)
	} ; if (SoundExist_SoundHeard == 0)
	; -------------------------------------------
	return SoundExist_SoundHeard
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
