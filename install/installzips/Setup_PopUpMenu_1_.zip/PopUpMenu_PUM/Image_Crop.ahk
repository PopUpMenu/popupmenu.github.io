﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Crop(Crop_Array) ; [ImageOut_W, ImageOut_H, Position_X, Position_Y, ImageIn, ImageOut] > 1 / 0
{
  /*
        ; -------------------------------------------
        ImageOut_W     :=   ; ImageOut_W   = ImageOut Width
        ImageOut_H     :=   ; ImageOut_H   = ImageOut Height
        ;
        Position_X    :=  ; Position_X    = +X (Remove From Left to Right) / -X (Remove From Right to Left)
        Position_Y    :=  ; Position_Y    = +Y (Remove From Top To Bottom) / -Y (Remove From Bottom To Top)
        ;
        ImageIn  :=  ; ImageIn  = Image to Crop
        ImageOut :=  ; ImageOut = Croped Image
        ;
        Crop_Array := [ImageOut_W, ImageOut_H, Position_X, Position_Y, ImageIn, ImageOut]
        Image_Crop(Crop_Array) ; > ImageOut
        ; -------------------------------------------
  */
  ; -------------------------------------------
  ImageOut_W := Crop_Array.1 ; ImageOut_W     = ImageOut Width
  ImageOut_H := Crop_Array.2 ; ImageOut_H     = ImageOut Height
  Position_X := Crop_Array.3 ; Position_X    = +X (Remove From Left to Right) / -X (Remove From Right to Left)
  Position_Y := Crop_Array.4 ; Position_Y    = +Y (Remove From Top To Bottom) / -Y (Remove From Bottom To Top)
  ImageIn    := Crop_Array.5 ; ImageIn  = Image to Crop
  ImageOut   := Crop_Array.6 ; ImageOut = Return Croped Image
  ; -------------------------------------------
  
  if FileExist(ImageIn) ; > ImageOut
  {
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert """ ImageIn """ -crop " ImageOut_W "x" ImageOut_H "+" Position_X "+" Position_Y " +repage """ ImageOut """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    if FileExist(ImageOut)
    {
      ; -------------------------------------------
      Gui, ImageSize:Add, Picture, hwndJustForSize, %Image_Out% ; (368_5)(Selected Pum Background [Full Path])
      ControlGetPos, , , Test_W, Test_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
      ; -------------------------------------------
      if (Test_W == 0 or Test_H == 0 )
      {
        return 0
      }
      else
      {
        return 1
      }
    }
    else
    {
      return 0
    }
    ; -------------------------------------------
  }
} ; End Image_Crop(ImageOut_W, ImageOut_H, Position_X, Position_Y, ImageIn) ; > ImageOut
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
