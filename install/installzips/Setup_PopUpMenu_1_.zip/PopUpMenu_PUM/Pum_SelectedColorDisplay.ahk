﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_DisplayImageTxt.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_SelectedColorDisplay(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [START UP]  Vars
    ; -------------------------------------------
    { ; [GET] Vars
      ; -------------------------------------------
      UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
      ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
      XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
      ; -------------------------------------------
      Img_W          := DataArray.362.34 ; (362_34)(Img_W)
      Img_H          := DataArray.362.35 ; (362_35)(Img_H)
      Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
      Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
      bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
      Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
      Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
      Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
      Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
      PumBody_H      := DataArray.362.43 ; (362_43)((ImgChange_Array [Image Change [Array])
      Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
      Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
      Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
      Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
      Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
      Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
      Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
      Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
      bg_Selected_Rotate    := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
      ; -------------------------------------------
      Mobile_OnOff              := DataArray.362.24 ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
      Mobile_TextColor_HexColor := DataArray.362.25 ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
      Mobile_BgColor_HexColor   := DataArray.362.26 ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
      ; -------------------------------------------
      XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
      XmlBgType          := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      BgColor_Opicity     := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
      ; -------------------------------------------
    } ; End [GET] Vars
    ; -------------------------------------------
    ImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
    ; -------------------------------------------
    Info_bg     := ThisPumProcessFolder "\image\Info_bg.txt" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    File_PumFrame := "C:\Program Files\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
    ; -------------------------------------------
    bg_Selected_Bmp     := ThisPumProcessFolder "\image\bg_Selected_Bmp.bmp" ; (361)(8)(Pum [Specific Folder Path])
    bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Selected_Fit     := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
    Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    bg_Display_Img       := ThisPumProcessFolder "\image\bg_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Display_Txt_Col   := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Display_Txt_Img   := ThisPumProcessFolder "\image\bg_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    File_Pum_Gui       := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
  } ; End [START UP] Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(ScriptType, "pumMobileTextColor") > 0) ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    Color_Array := Pum_ColorVarConvert("HexColor", Mobile_TextColor_HexColor, DataArray) ; (362_25)(Mobile Text [Text Color (Hex)])
    VarNum    := Color_Array.1
    Pum_BgColor_GridNum := Color_Array.2
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (InStr(ScriptType, "pumMobileBgColor") > 0) ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    Color_Array := Pum_ColorVarConvert("HexColor", Mobile_BgColor_HexColor, DataArray) ; (362_26)(Mobile Text [Background Color (Hex)])
    VarNum    := Color_Array.1
    Pum_BgColor_GridNum := Color_Array.2
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (InStr(ScriptType, "pumBgColor") > 0) ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
    VarNum    := Color_Array.1
    Pum_BgColor_GridNum := Color_Array.2
    ; -------------------------------------------
    if (BgColor_Opicity == 0)
    {
      DataArray := Image_GuiControl("181", "Zero", 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
    }
    else
    {
      Opicity_GridNum  := BgColor_Opicity "_" Pum_BgColor_GridNum
      DataArray := Image_GuiControl("181", Opicity_GridNum, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
    }
    ; -------------------------------------------
  } ; End (366_5)(Script Type) ("pumBgColor")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(ScriptType, "Color") > 0) ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    This_VarNum := 190
    Loop 48
    {
      ; -------------------------------------------
      This_VarNum := This_VarNum + 1
      ; -------------------------------------------
      if (VarNum == This_VarNum)
      {
        ; -------------------------------------------
        GridImage := "C:\Program Files\PopUpMenu_PUM\image\pum\ColorGrid_" Pum_BgColor_GridNum "_2.png"
        ; -------------------------------------------
        DataArray[VarNum][2] := 2
        ; -------------------------------------------
        Check_GridImage := DataArray[VarNum][3]
        if (Check_GridImage != GridImage)
        {
          DataArray[VarNum][3] := GridImage
          GuiControl, PopUpMenu:, g_%VarNum%, %GridImage% ; (182_1)(GUI Object: [pum] Transparency [Image] Color)
        }
        GuiControl, PopUpMenu:Show, g_%VarNum%
      } ; End (VarNum == This_VarNum)
      else ; (VarNum != This_VarNum)
      {
        ; -------------------------------------------
        Color_Array := Pum_ColorVarConvert("VarNum", This_VarNum, DataArray)
        This_ColorGrid := Color_Array.2
        ; -------------------------------------------
        This_GridImage := "C:\Program Files\PopUpMenu_PUM\image\pum\ColorGrid_" This_ColorGrid "_1.png"
        ; -------------------------------------------
        DataArray[This_VarNum][2] := 1
        ; -------------------------------------------
        Check_This_GridImage := DataArray[This_VarNum][3]
        if (Check_This_GridImage != This_GridImage)
        {
          DataArray[This_VarNum][3] := This_GridImage
          GuiControl, PopUpMenu:, g_%This_VarNum%, %This_GridImage% ; (182_1)(GUI Object: [pum] Transparency [Image] Color)
        }
        GuiControl, PopUpMenu:Show, g_%This_VarNum%
        ; -------------------------------------------
      } ; End (VarNum != This_VarNum)
      ; -------------------------------------------
    } ; End Loop 48
    ; -------------------------------------------
  } ; End (InStr(ScriptType, "Color") > 0)
  ; -------------------------------------------
  else ; Hide Color Panel
  {
    ; -------------------------------------------
    { ; Hide Color Panel Controls
      ; -------------------------------------------
      DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      ; -------------------------------------------
      DataArray := Image_GuiControl("191", 0, 0, DataArray) ; (191_1)(Obj_Pum_ColorA1)
      DataArray := Image_GuiControl("192", 0, 0, DataArray) ; (192_1)(Obj_Pum_ColorA2)
      DataArray := Image_GuiControl("193", 0, 0, DataArray) ; (193_1)(Obj_Pum_ColorA3)
      DataArray := Image_GuiControl("194", 0, 0, DataArray) ; (194_1)(Obj_Pum_ColorA4)
      DataArray := Image_GuiControl("195", 0, 0, DataArray) ; (195_1)(Obj_Pum_ColorA5)
      DataArray := Image_GuiControl("196", 0, 0, DataArray) ; (196_1)(Obj_Pum_ColorA6)
      DataArray := Image_GuiControl("197", 0, 0, DataArray) ; (197_1)(Obj_Pum_ColorB1)
      DataArray := Image_GuiControl("198", 0, 0, DataArray) ; (198_1)(Obj_Pum_ColorB2)
      DataArray := Image_GuiControl("199", 0, 0, DataArray) ; (199_1)(Obj_Pum_ColorB3)
      DataArray := Image_GuiControl("200", 0, 0, DataArray) ; (200_1)(Obj_Pum_ColorB4)
      DataArray := Image_GuiControl("201", 0, 0, DataArray) ; (201_1)(Obj_Pum_ColorB5)
      DataArray := Image_GuiControl("202", 0, 0, DataArray) ; (202_1)(Obj_Pum_ColorB6)
      DataArray := Image_GuiControl("203", 0, 0, DataArray) ; (203_1)(Obj_Pum_ColorC1)
      DataArray := Image_GuiControl("204", 0, 0, DataArray) ; (204_1)(Obj_Pum_ColorC2)
      DataArray := Image_GuiControl("205", 0, 0, DataArray) ; (205_1)(Obj_Pum_ColorC3)
      DataArray := Image_GuiControl("206", 0, 0, DataArray) ; (206_1)(Obj_Pum_ColorC4)
      DataArray := Image_GuiControl("207", 0, 0, DataArray) ; (207_1)(Obj_Pum_ColorC5)
      DataArray := Image_GuiControl("208", 0, 0, DataArray) ; (208_1)(Obj_Pum_ColorC6)
      DataArray := Image_GuiControl("209", 0, 0, DataArray) ; (209_1)(Obj_Pum_ColorD1)
      DataArray := Image_GuiControl("210", 0, 0, DataArray) ; (210_1)(Obj_Pum_ColorD2)
      DataArray := Image_GuiControl("211", 0, 0, DataArray) ; (211_1)(Obj_Pum_ColorD3)
      DataArray := Image_GuiControl("212", 0, 0, DataArray) ; (212_1)(Obj_Pum_ColorD4)
      DataArray := Image_GuiControl("213", 0, 0, DataArray) ; (213_1)(Obj_Pum_ColorD5)
      DataArray := Image_GuiControl("214", 0, 0, DataArray) ; (214_1)(Obj_Pum_ColorD6)
      DataArray := Image_GuiControl("215", 0, 0, DataArray) ; (215_1)(Obj_Pum_ColorE1)
      DataArray := Image_GuiControl("216", 0, 0, DataArray) ; (216_1)(Obj_Pum_ColorE2)
      DataArray := Image_GuiControl("217", 0, 0, DataArray) ; (217_1)(Obj_Pum_ColorE3)
      DataArray := Image_GuiControl("218", 0, 0, DataArray) ; (218_1)(Obj_Pum_ColorE4)
      DataArray := Image_GuiControl("219", 0, 0, DataArray) ; (219_1)(Obj_Pum_ColorE5)
      DataArray := Image_GuiControl("220", 0, 0, DataArray) ; (220_1)(Obj_Pum_ColorE6)
      DataArray := Image_GuiControl("221", 0, 0, DataArray) ; (221_1)(Obj_Pum_ColorF1)
      DataArray := Image_GuiControl("222", 0, 0, DataArray) ; (222_1)(Obj_Pum_ColorF2)
      DataArray := Image_GuiControl("223", 0, 0, DataArray) ; (223_1)(Obj_Pum_ColorF3)
      DataArray := Image_GuiControl("224", 0, 0, DataArray) ; (224_1)(Obj_Pum_ColorF4)
      DataArray := Image_GuiControl("225", 0, 0, DataArray) ; (225_1)(Obj_Pum_ColorF5)
      DataArray := Image_GuiControl("226", 0, 0, DataArray) ; (226_1)(Obj_Pum_ColorF6)
      DataArray := Image_GuiControl("227", 0, 0, DataArray) ; (227_1)(Obj_Pum_ColorG1)
      DataArray := Image_GuiControl("228", 0, 0, DataArray) ; (228_1)(Obj_Pum_ColorG2)
      DataArray := Image_GuiControl("229", 0, 0, DataArray) ; (229_1)(Obj_Pum_ColorG3)
      DataArray := Image_GuiControl("230", 0, 0, DataArray) ; (230_1)(Obj_Pum_ColorG4)
      DataArray := Image_GuiControl("231", 0, 0, DataArray) ; (231_1)(Obj_Pum_ColorG5)
      DataArray := Image_GuiControl("232", 0, 0, DataArray) ; (232_1)(Obj_Pum_ColorG6)
      DataArray := Image_GuiControl("233", 0, 0, DataArray) ; (233_1)(Obj_Pum_ColorH1)
      DataArray := Image_GuiControl("234", 0, 0, DataArray) ; (234_1)(Obj_Pum_ColorH2)
      DataArray := Image_GuiControl("235", 0, 0, DataArray) ; (235_1)(Obj_Pum_ColorH3)
      DataArray := Image_GuiControl("236", 0, 0, DataArray) ; (236_1)(Obj_Pum_ColorH4)
      DataArray := Image_GuiControl("237", 0, 0, DataArray) ; (237_1)(Obj_Pum_ColorH5)
      DataArray := Image_GuiControl("238", 0, 0, DataArray) ; (238_1)(Obj_Pum_ColorH6)
      ; -------------------------------------------
    } ; End Hide Color Panel Controls
    ; -------------------------------------------
    if ((XmlBgType == 1 && !FileExist(Temp_Display_Txt_Img)) or (XmlBgType == 2 && !FileExist(Temp_Display_Txt_Col)))
    {
      DataArray := Pum_DisplayImageTxt(DataArray)
    }
    else
    {
      if (XmlBgType == 1)
      {
        GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Img% ; (254_1)(Obj_MsgImg300x300)
      }
      else if (XmlBgType == 2)
      {
        GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Col% ; (254_1)(Obj_MsgImg300x300)
      }
      GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
    }
    ; -------------------------------------------
  } ; End Hide Color Panel
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [UPDATE] Vars
    ; -------------------------------------------
    DataArray.365.2  := UserLang ; (365_2)(UserLang [Current User language])
    DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    DataArray.366.5  := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
    DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
    DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
    ; -------------------------------------------
    DataArray.362.34 := Img_W ; (362_34)(Img_W)
    DataArray.362.35 := Img_H ; (362_35)(Img_H)
    DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
    DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
    DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
    DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
    DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
    DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
    DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
    DataArray.362.43 := PumBody_H ; (362_43)((ImgChange_Array [Image Change [Array])
    DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
    DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
    DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
    DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
    DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
    DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
    DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
    DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
    ; -------------------------------------------
    DataArray.362.24 := Mobile_OnOff ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
    DataArray.362.25 := Mobile_TextColor_HexColor ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    DataArray.362.26 := Mobile_BgColor_HexColor ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
    DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
    DataArray.362.28 := XmlBgType ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
    DataArray.362.30 := BgColor_Opicity ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
    ; -------------------------------------------
  } ; End [UPDATE] Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum_SelectedColorDisplay(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
