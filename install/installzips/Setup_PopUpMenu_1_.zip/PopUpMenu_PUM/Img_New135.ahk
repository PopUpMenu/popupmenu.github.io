﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_New135(ArrayIn) ; Img_New135(ArrayIn) ; > FileNew135
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileNew135 := Img_New135(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileNew135 := Img_New135(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileNew135 := Img_New135(ArrayIn)
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileNew135
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    SplitPath, AppProcessPathNameExt, CommonBrowser
    if (CommonBrowser == "pumcommonbrowser.txt") ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; -------------------------------------------
      FileDel135 := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Del135.png"
      FileNew135 := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_New135.png"
      FileRunPng := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
      ; -------------------------------------------
    }
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileDel135", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileDel135 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileNew135", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileNew135 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [CREATE] New135.png
    ; [UserPictureFolder "\(_PopUpMenu_)\System\New135\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileNew135)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [CREATE]
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [CREATE]
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; -------------------------------------------
      New135Temp := A_AppData "\PopUpMenu_PUM\temp\New135Temp.png" ; w50 h50
      ; -------------------------------------------
      if FileExist(New135Temp)
      {
        FileDelete, %New135Temp%
      } ; [End] if !FileExist(New135Temp)
      ; -------------------------------------------
      Image_ResizePng(50, 50, FileRunPng, New135Temp) ; [RESIZE]_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\New135\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\New135.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; -------------------------------------------
      I1 := "C:\Program Files\PopUpMenu_PUM\image\ico\New135.png" ; w130, h100
      X1 := 0 ; X Position (Left)
      Y1 := 0 ; Y Postion (Down)
      ;
      I2  := New135Temp ; w66, h66
      X2 := 40 ; X Position (Left)
      Y2 := 36 ; Y Postion (Down)
      ; -------------------------------------------
      Image_Array := [130, 100, FileNew135, I1, X1, Y1, I2, X2, Y2]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\New135\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\New135.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; -------------------------------------------
      if FileExist(New135Temp)
      {
        FileDelete, %New135Temp%
      } ; [End] if FileExist(New135Temp)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\New135Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(New135)
    ; -------------------------------------------
    ; [UserPictureFolder "\(_PopUpMenu_)\System\New135\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileNew135
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
