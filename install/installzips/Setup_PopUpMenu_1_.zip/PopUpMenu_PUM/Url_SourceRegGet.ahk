﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority,, A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SourceLinkFile := A_AppData "\PopUpMenu_PUM\url_cache\SourceLinkFile.txt"
FileReadLine, Url_Link, %SourceLinkFile%, 1
; -------------------------------------------
global req := ComObjCreate("Msxml2.XMLHTTP")
req.open("GET", Url_Link, true)
req.onreadystatechange := Func("Ready")
req.send()
; -------------------------------------------
#Persistent
Ready()
{
  global req
  if (req.readyState != 4)  ; Not done yet.
  {
    return
  }
  if (req.status == 200) ; OK.
  {
		; -------------------------------------------
		Url_File := A_AppData "\PopUpMenu_PUM\url_cache\Url_Source.txt"
    if FileExist(Url_File)
    {
		  FileDelete, %Url_File%
    }
		; -------------------------------------------
		ThisText := req.responseText
    ; -------------------------------------------
    CheckArray := StrSplit(ThisText, "`n`r")
    ; -------------------------------------------
    for Index, ThisLine in CheckArray
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "404") > 0) ; is Not a Image
      {
        ; -------------------------------------------
        ThisText := "404"
        break
        ; -------------------------------------------
      } ; [End] if (InStr(ThisLine, "html") ; is Not a Image
    } ; [End] for Index, ThisLine in CheckArray
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    FileAppend, %ThisText%, %Url_File% ; UTF-8
		; -------------------------------------------
  }
  ExitApp
} 
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
