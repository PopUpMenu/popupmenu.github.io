﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Run_GetLink(ThisLink, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, LinkUse, LinkIcon, LinkName, TargetExt, TargetDrive]
{
  ; -------------------------------------------
  if FileExist(ThisLink)
  {
    ; -------------------------------------------
    LinkUse := 0
    ; -------------------------------------------
    ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
    SplitPath, ThisLink ,            ,       ,             , LinkName
    ; -------------------------------------------
    ; FileGetShortcut, LinkFile, OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
    FileGetShortcut, %ThisLink%, Target, , Arguments, , LinkIcon
    ; -------------------------------------------
    if (LinkIcon == "")
    {
      LinkIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\defaultapp.ico"
    }
    ; -------------------------------------------
    if (Target == "" && ThisPumPath != "") ; Target is Empty
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Create Shortcut to Selected File in User pum Folder
      ; -------------------------------------------
      PumLinkPath := ThisPumPath "\link"
      if !FileExist(PumLinkPath)
      {
        FileCreateDir, %PumLinkPath%
        Sleep, 100
      }
      ; -------------------------------------------
      FormatTime, TimeRightNow , , yyyyMMddHHmmss
      ThisYear := SubStr(TimeRightNow, 1, 4)
      ThisMonth := SubStr(TimeRightNow, 5, 2)
      ThisDay := SubStr(TimeRightNow, 7, 2)
      ThisHour := SubStr(TimeRightNow, 9, 2)
      ThisMinute := SubStr(TimeRightNow, 11, 2)
      ThisSecond := SubStr(TimeRightNow, 13, 2)
      TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond
      ; -------------------------------------------
      PumShortcut := PumLinkPath "\PumShortcut_" TimeRightNow ".lnk"
      PumTarget := PumLinkPath "\PumTarget_" TimeRightNow ".lnk"
      ; -------------------------------------------
      FileCopy, %ThisLink%, %PumTarget%, 1
      ; -------------------------------------------
      FileCreateShortcut, %PumTarget%, %PumShortcut%, , , , %PumTarget%
      ; -------------------------------------------
      Target := PumShortcut
      Arguments := ""
      LinkUse   := 1
      TargetExt := "lnk"
      ; -------------------------------------------
      ; Create Shortcut to Selected File in User pum Folder
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if (Target == "") ; Target is Empty
    else ; Target is NOT Empty
    {
      ; -------------------------------------------
      SplitPath, Target, , , TargetExt, , TargetDrive
      ; -------------------------------------------
      if (InStr(Target, "{") > 0)
      {
        ; Special Case Like "Microsoft Office 2013"
        ; Were the Executable is a link file not to a actual "exe" file
        ; Here Target would be a FullPath to a Icon
        Target    := ThisLink
        Arguments := ""
        LinkUse   := 1
        TargetExt := "lnk"
      }
      ; -------------------------------------------
      Target    := StrReplace(Target, """", "")
      Arguments := StrReplace(Arguments, """", "")
      ; -------------------------------------------
    } ; [End] else ; Target is NOT Empty
    ; -------------------------------------------
  } ; [End] if FileExist(ThisLink)
  ; -------------------------------------------
  ReturnArray := [Target, Arguments, LinkUse, LinkIcon, LinkName, TargetExt, TargetDrive]
  return ReturnArray
  ; -------------------------------------------
} ; [End] Run_GetLink
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
