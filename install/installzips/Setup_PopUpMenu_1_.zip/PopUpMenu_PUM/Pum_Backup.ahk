﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 162 [pumBackup]
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Backup()
{
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
	Run, %ScriptPath%
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Zip File Name (TimeRightNow)
	; -------------------------------------------
	FormatTime, TimeRightNow , , yyyyMMddHHmmss
	ThisYear := SubStr(TimeRightNow, 1, 4)
	ThisMonth := SubStr(TimeRightNow, 5, 2)
	ThisDay := SubStr(TimeRightNow, 7, 2)
	ThisHour := SubStr(TimeRightNow, 9, 2)
	ThisMinute := SubStr(TimeRightNow, 11, 2)
	ThisSecond := SubStr(TimeRightNow, 13, 2)
	; -------------------------------------------
	{ ; Set Month Name from Number
		; -------------------------------------------
	  if (ThisMonth == "01")
	  {
  		ThisMonth := "Jan"
  	}
  	else if (ThisMonth == "02")
  	{
		  ThisMonth := "Feb"
	  }
	  else if (ThisMonth == "03")
	  {
  		ThisMonth := "Mar"
  	}
  	else if (ThisMonth == "04")
  	{
		  ThisMonth := "Apr"
	  }
	  else if (ThisMonth == "05")
	  {
  		ThisMonth := "May"
  	}
  	else if (ThisMonth == "06")
  	{
		  ThisMonth := "Jun"
	  }
	  else if (ThisMonth == "07")
	  {
  		ThisMonth := "Jul"
  	}
  	else if (ThisMonth == "08")
  	{
		  ThisMonth := "Aug"
	  }
	  else if (ThisMonth == "09")
	  {
  		ThisMonth := "Sep"
  	}
  	else if (ThisMonth == "10")
  	{
		  ThisMonth := "Oct"
	  }
	  else if (ThisMonth == "11")
	  {
  		ThisMonth := "Nov"
  	}
  	else if (ThisMonth == "12")
  	{
		  ThisMonth := "Dec"
	  }
	  ; -------------------------------------------
	} ; Set Month Name from Number
	; -------------------------------------------
	; Zip File Name (TimeRightNow)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	File_PumBackup := A_Desktop "\PopUpMenu_Pum_(" ThisDay "_" ThisMonth "_" ThisYear "_@" ThisHour "-" ThisMinute "-" ThisSecond ").zip"
	PumFolder := A_AppData "\PopUpMenu_PUM"
	; -------------------------------------------
	Support_7z := "C:\Program Files\PopUpMenu_PUM\support\7-Zip\7z.exe"
	; -------------------------------------------
  RunThis := """" Support_7z """ a """ File_PumBackup """ """ PumFolder """"
	; -------------------------------------------
	RunWait, %RunThis%, , Hide
	; -------------------------------------------
	;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
	Script_Close(ScriptPath)
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
