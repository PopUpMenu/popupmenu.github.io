﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_524: ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
{
  ; -------------------------------------------
  ; Writing Request
  ; -------------------------------------------
  ;
  ; (_w480 x h270_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Writing Request)
  ; global n_524 := 1 ; Start Frame Number
  ; global s_524 := 1 ; Show
  ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Writing Request)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Writing Request)
  ; global s_524 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Writing Request)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Application_Request.ahk
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 9
  ; -------------------------------------------
  if (s_524 == 1) ; run animation
  {
    ; -------------------------------------------
    if (n_524 > Total_Images) ; 1 Less than Number of Images
    {
      global n_524 := 1
    }
    ; -------------------------------------------
    UserLang  := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_137, C:\Program Files\PopUpMenu_PUM\image\gui\(524)_%n_524%_%UserLang%.png ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    Gui_ObjectSize("137", DataArray) ; > Nothing
    ; -------------------------------------------
    if (ShowAnimationChange == 0)
    {
      GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
      global ShowAnimationChange := 1
    }
    ; -------------------------------------------
    global n_524 := n_524 + 1
    ; -------------------------------------------
  } ; End run animation
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_524, Off ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
