﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\Folder_SetIcon.ahk
#Include C:\Program Files\PopUpMenu_PUM\Gui_TextWidth.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
#Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Create HotKeyDataArray
  ; -------------------------------------------
  Var_Num := 0
  While (Var_Num < 100)
  {
    ; -------------------------------------------
    Var_Num := Var_Num + 1
    Var_Item := []
    ; -------------------------------------------
    Var_Item := [Var_Num]
    ; -------------------------------------------
    HotKeyDataArray := Array_Add(HotKeyDataArray, Var_Item, "End")
    ; -------------------------------------------
  }
  ; -------------------------------------------
} ; [End] Create HotKeyDataArray
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Context Menu (ContextMenu.txt)
; -------------------------------------------
File_ContextMenu := A_AppData "\PopUpMenu_PUM\system\ContextMenu.txt"
; -------------------------------------------
if FileExist(File_ContextMenu)
{
  ; -------------------------------------------
  FileReadLine, Use_ContextMenu, %File_ContextMenu%, 1
  ; -------------------------------------------
  if (Use_ContextMenu == "")
  {
    ; -------------------------------------------
    FileDelete, %File_ContextMenu%
    ; -------------------------------------------
    Use_ContextMenu := 1 ; NOT Context By Default
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %Use_ContextMenu%, %File_ContextMenu%
    Sleep, 100
    ; -------------------------------------------
  }
  ; -------------------------------------------
}
else
{
  ; -------------------------------------------
  Use_ContextMenu := 1 ; NOT Context By Default
  FileEncoding, UTF-8
  FileAppend, %Use_ContextMenu%, %File_ContextMenu%
  Sleep, 100
  ; -------------------------------------------
}
; -------------------------------------------
HotkeyDataArray.2.1 := Use_ContextMenu
HotkeyDataArray.41.2 := Use_ContextMenu
; -------------------------------------------
; Context Menu (ContextMenu.txt)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (Current User) StartLoad (PopUpMenuStartUp.txt)
; is the Load PopUpMenu at Windows Login
; -------------------------------------------
PumSystemFolder := A_AppData "\PopUpMenu_PUM\system"
if !FileExist(PumSystemFolder)
{
  FileCreateDir, %PumSystemFolder%
} ; [End] if !FileExist(PumSystemFolder)
; -------------------------------------------
PopUpMenuStartUp := A_AppData "\PopUpMenu_PUM\system\PopUpMenuStartUp.txt"
; -------------------------------------------
if !FileExist(PopUpMenuStartUp) ; (PopUpMenuStartUp.txt) (DOES NOT Exist)
{
  ; -------------------------------------------
  StartLoad := 2 ; Load With Windows By Default
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileAppend, %StartLoad%, %PopUpMenuStartUp%
  Sleep, 100
  ; -------------------------------------------
} ; [End] if !FileExist(PopUpMenuStartUp) ; (PopUpMenuStartUp.txt) (DOES NOT Exist)
else ; (PopUpMenuStartUp.txt) (Exist)
{
  ; -------------------------------------------
  FileReadLine, StartLoad, %PopUpMenuStartUp%, 1 ; FileReadLine, OutputVar, Filename, LineNum
  ; -------------------------------------------
  if (StartLoad != 1 && StartLoad != 2)
  {
    ; -------------------------------------------
    FileDelete, %PopUpMenuStartUp%
    Sleep, 10
    ; -------------------------------------------
    StartLoad := 2 ; Load With Windows By Default
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %StartLoad%, %PopUpMenuStartUp%
    Sleep, 100
    ; -------------------------------------------
  }
} ; [End] else ; (PopUpMenuStartUp.txt) (Exist)
; -------------------------------------------
HotkeyDataArray.40.2 := StartLoad
; -------------------------------------------
; (Current User) StartLoad (PopUpMenu.lnk)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Start Up] (LogoImage.png)(GuiFont)(UserLang)
; -------------------------------------------
GuiFont := "Arial"
HotkeyDataArray.5.1 := GuiFont ; (005_1)(ORG_ScriptType)
LogoImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\LogoImage.png"
; -------------------------------------------
; [Start Up] (LogoImage.png)(GuiFont)(UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; User Language [GET] (UserLang)
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileReadLINE, UserLang, %File_UserLang%, 1
  }
  if (UserLang == "")
  {
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileDelete, %File_UserLang%
      Sleep, 100
    } ; [End] if FileExist(File_UserLang)
    ; -------------------------------------------
    if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
    {
      ; -------------------------------------------
      UserLang := "de"
      ; -------------------------------------------
    } ; [End] German (de)
    ; -------------------------------------------
    else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] English (en)
    ; -------------------------------------------
    else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
    {
      ; -------------------------------------------
      UserLang := "es"
      ; -------------------------------------------
    } ; [End] Spanish (es)
    ; -------------------------------------------
    else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
    {
      ; -------------------------------------------
      UserLang := "fr"
      ; -------------------------------------------
    } ; [End] French (fr)
    ; -------------------------------------------
    else if (A_Language == "0410" or A_Language == "0810")
    {
      ; -------------------------------------------
      UserLang := "it"
      ; -------------------------------------------
    } ; [End] Italian (it)
    ; -------------------------------------------
    else if (A_Language == "0415")
    {
      ; -------------------------------------------
      UserLang := "pl"
      ; -------------------------------------------
    } ; [End] Polish (pl)
    ; -------------------------------------------
    else if (A_Language == "0416" or A_Language == "0816")
    {
      ; -------------------------------------------
      UserLang := "pt"
      ; -------------------------------------------
    } ; [End] Portuguese (pt)
    ; -------------------------------------------
    else if (A_Language == "0419")
    {
      ; -------------------------------------------
      UserLang := "ru"
      ; -------------------------------------------
    } ; [End] Russian (ru)
    ; -------------------------------------------
    else if (A_Language == "041d" or A_Language == "081d")
    {
      ; -------------------------------------------
      UserLang := "sv"
      ; -------------------------------------------
    } ; [End] Swedish (sv)
    ; -------------------------------------------
    else if (A_Language == "041f")
    {
      ; -------------------------------------------
      UserLang := "tr"
      ; -------------------------------------------
    } ; [End] Turkish (tr)
    ; -------------------------------------------
    else ; English (en)
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] else ; English (en)
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
    Sleep, 100
    ; -------------------------------------------
  } ; [End] if (UserLang == "")
  ; -------------------------------------------
  HotkeyDataArray.4.1 := UserLang
  ; -------------------------------------------
} ; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [GET] Current Hotkey, [SET] Image Values
  ; -------------------------------------------
  File_UserHotkey := A_AppData "\PopUpMenu_PUM\system\File_UserHotkey.txt"
  if FileExist(File_UserHotkey)
  {
    FileReadLine, UserHotkey, %File_UserHotkey%, 1
  }
  else
  {
    UserHotkey := ""
  }
  ; -------------------------------------------
  HotKeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; (Key Positions)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      ; Update HotkeyDataArray
      ; -------------------------------------------
      h_042_Pos := InStr(UserHotkey, "LButton") ; (042_1)(Obj_MouseLeft)
      h_043_Pos := InStr(UserHotkey, "RButton") ; (043_1)(Obj_MouseRight)
      h_044_Pos := InStr(UserHotkey, "MButton") ; (044_1)(Obj_MouseMiddle)
      h_045_Pos := InStr(UserHotkey, "WheelUp") ; (045_1)(Obj_MouseWheelUp)
      h_046_Pos := InStr(UserHotkey, "WheelDown") ; (046_1)(Obj_MouseWheelDown)
      h_047_Pos := InStr(UserHotkey, "XButton1") ; (047_1)(Obj_MouseX1)
      h_048_Pos := InStr(UserHotkey, "XButton2") ; (048_1)(Obj_MouseX2)
      ; -------------------------------------------
      h_049_Pos := InStr(UserHotkey, "LWin") ; (049_1)(Obj_WinLeft)
      h_050_Pos := InStr(UserHotkey, "RWin") ; (050_1)(Obj_WinRight)
      Win_Pos := InStr(UserHotkey, "#")
      h_051_Pos := InStr(UserHotkey, "^") ; (051_1)(Obj_Ctrl)
      ; -------------------------------------------
      if (h_051_Pos == 0) ; (051_1)(Obj_Ctrl)
      {
        h_051_Pos := InStr(UserHotkey, "Ctrl") ; (051_1)(Obj_Ctrl)
      }
      ; -------------------------------------------
      h_052_Pos := InStr(UserHotkey, "!") ; (052_1)(Obj_Alt)
      ; -------------------------------------------
      if (h_052_Pos == 0) ; (052_1)(Obj_Alt)
      {
        h_052_Pos := InStr(UserHotkey, "Alt") ; (052_1)(Obj_Alt)
      }
      ; -------------------------------------------
      h_053_Pos := InStr(UserHotkey, "+") ; (053_1)(Obj_Shift)
      ; -------------------------------------------
      if (h_053_Pos == 0) ; (053_1)(Obj_Shift)
      {
        h_053_Pos := InStr(UserHotkey, "Shift") ; (053_1)(Obj_Shift)
      }
      ; -------------------------------------------
    } ; End [GET] (Key Positions) (Hot Key is SET)
    else ; [SET] (Key Positions to 0) (Hot Key is NOT Set)
    {
      h_042_Pos := 0 ; (042_1)(Obj_MouseLeft)
      h_043_Pos := 0 ; (043_1)(Obj_MouseRight)
      h_044_Pos := 0 ; (044_1)(Obj_MouseMiddle)
      h_045_Pos := 0 ; (045_1)(Obj_MouseWheelUp)
      h_046_Pos := 0 ; (046_1)(Obj_MouseWheelDown)
      h_047_Pos := 0 ; (047_1)(Obj_MouseX1)
      h_048_Pos := 0 ; (048_1)(Obj_MouseX2)
      h_049_Pos := 0 ; (049_1)(Obj_WinLeft)
      h_050_Pos := 0 ; (050_1)(Obj_WinRight)
      h_051_Pos := 0 ; (051_1)(Obj_Ctrl)
      h_052_Pos := 0 ; (052_1)(Obj_Alt)
      h_053_Pos := 0 ; (053_1)(Obj_Shift)
      Win_Pos := 0
    } ; End [SET] (Key Positions to 0) (Hot Key is NOT Set)
    ; -------------------------------------------
  } ; End (Key Positions)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [SET] (Key Images)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray.40.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(040)_" StartLoad "_" UserLang ".png"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray.41.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(041)_" Use_ContextMenu ".png" ; (041_3)(Obj_Key_Numpad7_Img [Image Path])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_042_Pos == 0) ; (042_1)(Obj_MouseLeft)
    {
      HotkeyDataArray.42.2 := 1 ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      HotkeyDataArray.42.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(042)_1.png" ; (042_3)(Obj_Key_Numpad8_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.42.2 := 2 ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      HotkeyDataArray.42.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(042)_2.png" ; (042_3)(Obj_Key_Numpad8_Img [Image Path])
    }
    ; -------------------------------------------
    if (h_043_Pos == 0) ; (043_1)(Obj_MouseRight)
    {
      HotkeyDataArray.43.2 := 1 ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      HotkeyDataArray.43.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(043)_1.png" ; (043_3)(Obj_Key_Numpad9_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.43.2 := 2 ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      HotkeyDataArray.43.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(043)_2.png" ; (043_3)(Obj_Key_Numpad9_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_044_Pos == 0) ; (044_1)(Obj_MouseMiddle)
    {
      HotkeyDataArray.44.2 := 1 ; (044_2)(Obj_Key_NumpadAdd_Sel [0,1,2,3])
      HotkeyDataArray.44.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(044)_1.png" ; (044_3)(Obj_Key_NumpadAdd_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.44.2 := 2 ; (044_2)(Obj_Key_NumpadAdd_Sel [0,1,2,3])
      HotkeyDataArray.44.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(044)_2.png" ; (044_3)(Obj_Key_NumpadAdd_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_045_Pos == 0) ; (045_1)(Obj_MouseWheelUp)
    {
      HotkeyDataArray.45.2 := 1 ; (045_2)(Obj_Key_NumpadDiv_Sel [0,1,2,3])
      HotkeyDataArray.45.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(045)_1.png" ; (045_3)(Obj_Key_NumpadDiv_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.45.2 := 2 ; (045_2)(Obj_Key_NumpadDiv_Sel [0,1,2,3])
      HotkeyDataArray.45.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(045)_2.png" ; (045_3)(Obj_Key_NumpadDiv_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_046_Pos == 0) ; (046_1)(Obj_MouseWheelDown)
    {
      HotkeyDataArray.46.2 := 1 ; (046_2)(Obj_Key_NumpadDot_Sel [0,1,2,3])
      HotkeyDataArray.46.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(046)_1.png" ; (046_3)(Obj_Key_NumpadDot_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.46.2 := 2 ; (046_2)(Obj_Key_NumpadDot_Sel [0,1,2,3])
      HotkeyDataArray.46.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(046)_2.png" ; (046_3)(Obj_Key_NumpadDot_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_047_Pos == 0) ; (047_1)(Obj_MouseX1)
    {
      HotkeyDataArray.47.2 := 1 ; (047_2)(Obj_Key_NumpadEnter_Sel [0,1,2,3])
      HotkeyDataArray.47.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(047)_1.png" ; (047_3)(Obj_Key_NumpadEnter_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.47.2 := 2 ; (047_2)(Obj_Key_NumpadEnter_Sel [0,1,2,3])
      HotkeyDataArray.47.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(047)_2.png" ; (047_3)(Obj_Key_NumpadEnter_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_048_Pos == 0) ; (048_1)(Obj_MouseX2)
    {
      HotkeyDataArray.48.2 := 1 ; (048_2)(Obj_Key_NumpadMult_Sel [0,1,2,3])
      HotkeyDataArray.48.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(048)_1.png" ; (048_3)(Obj_Key_NumpadMult_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.48.2 := 2 ; (048_2)(Obj_Key_NumpadMult_Sel [0,1,2,3])
      HotkeyDataArray.48.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(048)_2.png" ; (048_3)(Obj_Key_NumpadMult_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_049_Pos == 0 && h_050_Pos == 0) ; (049_1)(Obj_WinLeft)/(050_1)(Obj_WinRight)
    {
      ; -------------------------------------------
      if (Win_Pos == 0)
      {
        HotkeyDataArray.49.2 := 1 ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])
        HotkeyDataArray.50.2 := 1 ; (050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        HotkeyDataArray.49.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(049)_1.png" ; (049_3)(Obj_Key_NumpadSub_Img [Image Path])
        HotkeyDataArray.50.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(050)_1.png" ; (050_3)(Obj_Key_Shift_Img [Image Path])
      }
      else
      {
        HotkeyDataArray.49.2 := 2 ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])
        HotkeyDataArray.50.2 := 2 ; (050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        HotkeyDataArray.49.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(049)_2.png" ; (049_3)(Obj_Key_NumpadSub_Img [Image Path])
        HotkeyDataArray.50.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(050)_2.png" ; (050_3)(Obj_Key_Shift_Img [Image Path])
      }
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      if (h_049_Pos == 0) ; (049_1)(Obj_WinLeft)
      {
        HotkeyDataArray.49.2 := 1 ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])
        HotkeyDataArray.49.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(049)_1.png" ; (049_3)(Obj_Key_NumpadSub_Img [Image Path])
      }
      else
      {
        HotkeyDataArray.49.2 := 2 ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])
        HotkeyDataArray.49.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(049)_2.png" ; (049_3)(Obj_Key_NumpadSub_Img [Image Path])
      }
      ; -------------------------------------------
      if (h_050_Pos == 0) ; (050_1)(Obj_WinRight)
      {
        HotkeyDataArray.50.2 := 1 ; (050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        HotkeyDataArray.50.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(050)_1.png" ; (050_3)(Obj_Key_Shift_Img [Image Path])
      }
      else
      {
        HotkeyDataArray.50.2 := 2 ; (050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        HotkeyDataArray.50.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(050)_2.png" ; (050_3)(Obj_Key_Shift_Img [Image Path])
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_051_Pos == 0) ; (051_1)(Obj_Ctrl)
    {
      HotkeyDataArray.51.2 := 1 ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      HotkeyDataArray.51.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(051)_1_" UserLang ".png" ; (051_3)(Obj_Key_ShiftDown_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.51.2 := 2 ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      HotkeyDataArray.51.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(051)_2_" UserLang ".png" ; (051_3)(Obj_Key_ShiftDown_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_052_Pos == 0) ; (052_1)(Obj_Alt)
    {
      HotkeyDataArray.52.2 := 1 ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      HotkeyDataArray.52.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(052)_1_" UserLang ".png" ; (052_3)(Obj_Key_ShiftLeft_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.52.2 := 2 ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      HotkeyDataArray.52.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(052)_2_" UserLang ".png" ; (052_3)(Obj_Key_ShiftLeft_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (h_053_Pos == 0) ; (053_1)(Obj_Shift)
    {
      HotkeyDataArray.53.2 := 1 ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      HotkeyDataArray.53.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(053)_1_" UserLang ".png" ; (053_3)(Obj_Key_ShiftRight_Img [Image Path])
    }
    else
    {
      HotkeyDataArray.53.2 := 2 ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      HotkeyDataArray.53.3 := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(053)_2_" UserLang ".png" ; (053_3)(Obj_Key_ShiftRight_Img [Image Path])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray.60.2 := 1 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    HotkeyDataArray.60.3 := "C:\Program Files\PopUpMenu_PUM\image\gui\(004)_1.png" ; (060_3)(Obj_Key_WinRight_Img [Image Path])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray.61.2 := 1 ; (061_2)(Obj_Key_WinUp_Sel [0,1,2,3])
    HotkeyDataArray.61.3 := "C:\Program Files\PopUpMenu_PUM\image\gui\(062)_1.png" ; (061_3)(Obj_Key_WinUp_Img [Image Path])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End [SET] (Key Images) from (Key Positions)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] [GET] Current Hotkey, [SET] Image Values
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; GUI Define (Objects)
  ; -------------------------------------------
  Gui, HotKeySelect:Font, c921297 s14 w700, %GuiFont%
  Gui, HotKeySelect:Add, Text, Center            x10  y113 w480      vh_070,
  Gui, HotKeySelect:Add, Text, Center            x10  y138 w480      vh_071,
  Gui, HotKeySelect:Add, Text, Center            x10  y163 w480      vh_072,
  Gui, HotKeySelect:Add, Text, Center            x10  y188 w480      vh_073,
  ; -------------------------------------------
  Gui, HotKeySelect:Add, Picture,                x37  y7   w40  h40,  %LogoImage%
  Gui, HotKeySelect:Add, Picture,                x129 y16  w350 h97   vh_Header, 
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; (Language)
  ; -------------------------------------------
  Gui, HotKeySelect:Add, Picture,                x10  y55  w94  h23  vh_LangFlag,
  Gui, HotKeySelect:Font, c000000 s10 w700, %GuiFont%
  Gui, HotKeySelect:Add, DropDownList,           x10  y81  w94       vh_LangList   ghl_LangList,
  ; -------------------------------------------
  Gui, HotKeySelect:Add, Picture,                x13  y471 w100 h35  vh_061    ghl_061, ; (061)(Obj_Cancel_Button)
  Gui, HotKeySelect:Add, Picture,                x387 y471 w100 h35  vh_060    ghl_060, ; (060)(Obj_OK_Button)
  ; -------------------------------------------
  Gui, HotKeySelect:Add, Picture,                x10  y518 w480 h20  vh_062    ghl_062, C:\Program Files\PopUpMenu_PUM\image\gui\WebAddress.png ; (062)(Obj_WebLink)
  ; -------------------------------------------
  ; End (Language)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; Load at Windows Startup
  Gui, HotKeySelect:Add, Picture,                x13  y313 w100 h130  vh_040   ghl_040, ; (040)(Obj_LoadAtStartUp)
  ; -------------------------------------------
  ; (Context Menu)
  Gui, HotKeySelect:Add, Picture,                x317 y313 w180 h130  vh_041   ghl_041, ; (041)(Obj_Context_Menu)
  ; ------------------------------------------- (Control Keys) (ContextMenu)
  Gui, HotKeySelect:Add, Picture,                x13  y214 w56  h56  vh_049    ghl_049, ; (049)(Obj_LWin)
  Gui, HotKeySelect:Add, Picture,                x104 y214 w56  h56  vh_051    ghl_051, ; (051)(Obj_Ctrl)
  Gui, HotKeySelect:Add, Picture,                x194 y214 w111 h56  vh_053    ghl_053, ; (053)(Obj_Shift)
  Gui, HotKeySelect:Add, Picture,                x340 y214 w56  h56  vh_052    ghl_052, ; (052)(Obj_Alt)
  Gui, HotKeySelect:Add, Picture,                x431 y214 w56  h56  vh_050    ghl_050, ; (050)(Obj_RWin)
  ; ------------------------------------------- (Control Keys) (ContextMenu)
  ;
  ; -------------------------------------------
  Gui, HotKeySelect:Add, Picture,                x182 y278 w134 h223, C:\Program Files\PopUpMenu_PUM\image\hotkey\Mouse.png
  ; ------------------------------------------- (Mouse Keys)
  Gui, HotKeySelect:Add, Picture,                x189 y282 w41  h92  vh_042    ghl_042, ; (042)(Obj_LButton)
  Gui, HotKeySelect:Add, Picture,                x268 y282 w41  h92  vh_043    ghl_043, ; (043)(Obj_RButton)
  Gui, HotKeySelect:Add, Picture,                x237 y304 w24  h43  vh_044    ghl_044, ; (044)(Obj_MButton)
  Gui, HotKeySelect:Add, Picture,                x237 y281 w23  h23  vh_045    ghl_045, ; (045)(Obj_WheeUp)
  Gui, HotKeySelect:Add, Picture,                x237 y347 w23  h23  vh_046    ghl_046, ; (046)(Obj_WheelDown)
  Gui, HotKeySelect:Add, Picture,                x153 y401 w43  h23  vh_047    ghl_047, ; (047)(Obj_XButton1)
  Gui, HotKeySelect:Add, Picture,                x149 y377 w43  h23  vh_048    ghl_048, ; (048)(Obj_XButton2)
  ; ------------------------------------------- (Mouse Keys)
} ; END GUI Define (Objects)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; GUI Show
; -------------------------------------------
GuiControl, HotKeySelect:Focus, h_060
Gui, HotKeySelect:Color , e7d8fe ; Purple
Gui, HotKeySelect:-Caption
; -------------------------------------------
Gui, HotKeySelect:Show, w500 h550, HotKey_Pop_Up_Menu, AlwaysOnTop Window 
; -------------------------------------------
; GUI Show
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Hide Gui from Task Bar
; -------------------------------------------
WinWait HotKey_Pop_Up_Menu
DetectHiddenWindows On
WinHide
WinSet, ExStyle, +0x80 ; 0x80 is WS_EX_TOOLWINDOW
WinShow
; -------------------------------------------
; Hide Gui from Task Bar
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; (Language)
  ; -------------------------------------------
  if (LockKeys == "")
  {
    global LockKeys := 0
  }
  if (UserLang == "de")
  {
    LangListNum := 1
  }
  else if (UserLang == "en")
  {
    LangListNum := 2
  }
  else if (UserLang == "es")
  {
    LangListNum := 3
  }
  else if (UserLang == "fr")
  {
    LangListNum := 4
  }
  else if (UserLang == "it")
  {
    LangListNum := 5
  }
  else if (UserLang == "pl")
  {
    LangListNum := 6
  }
  else if (UserLang == "pt")
  {
    LangListNum := 7
  }
  else if (UserLang == "ru")
  {
    LangListNum := 8
  }
  else if (UserLang == "sv")
  {
    LangListNum := 9
  }
  else if (UserLang == "tr")
  {
    LangListNum := 10
  }
  ; -------------------------------------------
  Lanh_de := "Deutsch"
  Lanh_en := "English"
  Lanh_es := "Español"
  Lanh_fr := "Français"
  Lanh_it := "Italiano"
  Lanh_pl := "Polskie"
  Lanh_pt := "Português"
  Lanh_ru := "Pусский"
  Lanh_sv := "Svenska"
  Lanh_tr := "Türk"
  LangListBox := "|" Lanh_de "|" Lanh_en "|" Lanh_es "|" Lanh_fr "|" Lanh_it "|" Lanh_pl "|" Lanh_pt "|" Lanh_ru "|" Lanh_sv "|" Lanh_tr
  ; -------------------------------------------
  HotkeyDataArray.63.1 := LangListBox ; (063_1)(Obj_SelectIconImage)
  HotkeyDataArray.64.1 := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"] ; (064_1)(Obj_HotKey_ContextMenu)
  ; -------------------------------------------
  ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(142)_" UserLang ".png"
  GuiControl, HotKeySelect:, h_LangFlag, %ThisImage%
  ; -------------------------------------------
  GuiControl, HotKeySelect:, h_LangList, %LangListBox%
  GuiControl, HotKeySelect:Choose, h_LangList, %LangListNum%
  ; ------------------------------------------
} ; End (Language)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HeaderImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\Header_" UserLang ".png"
GuiControl, HotKeySelect:, h_Header, %HeaderImage%
GuiControl, HotKeySelect:Show, h_Header
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
for Index, ThisVar in HotkeyDataArray
{
  ; -------------------------------------------
  ThisVar := ThisVar.1
  ; -------------------------------------------
  if (ThisVar == 40)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.40.3 ; (003_1)(Obj_KeyOfl_3RAppIco)
    GuiControl, HotKeySelect:, h_040, %ThisImage%
    GuiControl, HotKeySelect:Show, h_040
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 41) ; (041_1)(Obj_ContextMenu)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.41.3 ; (041_3)(Obj_Key_Numpad7_Img [Image Path])
    GuiControl, HotKeySelect:, h_041, %ThisImage%
    GuiControl, HotKeySelect:Show, h_041
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 42) ; (042_1)(Obj_MouseLeft)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.42.3 ; (042_3)(Obj_Key_Numpad8_Img [Image Path])
    GuiControl, HotKeySelect:, h_042, %ThisImage%
    GuiControl, HotKeySelect:Show, h_042
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 43) ; (043_1)(Obj_MouseRight)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.43.3 ; (043_3)(Obj_Key_Numpad9_Img [Image Path])
    GuiControl, HotKeySelect:, h_043, %ThisImage%
    GuiControl, HotKeySelect:Show, h_043
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 44) ; (044_1)(Obj_MouseMiddle)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.44.3 ; (044_3)(Obj_Key_NumpadAdd_Img [Image Path])
    GuiControl, HotKeySelect:, h_044, %ThisImage%
    GuiControl, HotKeySelect:Show, h_044
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 45) ; (045_1)(Obj_MouseWheelUp)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.45.3 ; (045_3)(Obj_Key_NumpadDiv_Img [Image Path])
    GuiControl, HotKeySelect:, h_045, %ThisImage%
    GuiControl, HotKeySelect:Show, h_045
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 46) ; (046_1)(Obj_MouseWheelDown)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.46.3 ; (046_3)(Obj_Key_NumpadDot_Img [Image Path])
    GuiControl, HotKeySelect:, h_046, %ThisImage%
    GuiControl, HotKeySelect:Show, h_046
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 47) ; (047_1)(Obj_MouseX1)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.47.3 ; (047_3)(Obj_Key_NumpadEnter_Img [Image Path])
    GuiControl, HotKeySelect:, h_047, %ThisImage%
    GuiControl, HotKeySelect:Show, h_047
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 48) ; (048_1)(Obj_MouseX2)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.48.3 ; (048_3)(Obj_Key_NumpadMult_Img [Image Path])
    GuiControl, HotKeySelect:, h_048, %ThisImage%
    GuiControl, HotKeySelect:Show, h_048
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 49) ; (049_1)(Obj_WinLeft)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.49.3 ; (049_3)(Obj_Key_NumpadSub_Img [Image Path])
    GuiControl, HotKeySelect:, h_049, %ThisImage%
    GuiControl, HotKeySelect:Show, h_049
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 50) ; (050_1)(Obj_WinRight)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.50.3 ; (050_3)(Obj_Key_Shift_Img [Image Path])
    GuiControl, HotKeySelect:, h_050, %ThisImage%
    GuiControl, HotKeySelect:Show, h_050
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 51) ; (051_1)(Obj_Ctrl)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.51.3 ; (051_3)(Obj_Key_ShiftDown_Img [Image Path])
    GuiControl, HotKeySelect:, h_051, %ThisImage%
    GuiControl, HotKeySelect:Show, h_051
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 52) ; (053_1)(Obj_Shift)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.52.3 ; (052_3)(Obj_Key_ShiftLeft_Img [Image Path])
    GuiControl, HotKeySelect:, h_052, %ThisImage%
    GuiControl, HotKeySelect:Show, h_052
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisVar == 53) ; (053_1)(Obj_Shift)
  {
    ; -------------------------------------------
    ThisImage := HotkeyDataArray.53.3 ; (053_3)(Obj_Key_ShiftRight_Img [Image Path])
    GuiControl, HotKeySelect:, h_053, %ThisImage%
    GuiControl, HotKeySelect:Show, h_053
    ; -------------------------------------------
  }
  ; -------------------------------------------
} ; [End] for Index, ThisVar in HotkeyDataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HotkeyDataArray := HotKey_Validate(HotkeyDataArray) ; > HotkeyDataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Hotkey Gui Labels
  ; -------------------------------------------
  hl_LangList:
  {
    ; -------------------------------------------
    HotkeyDataArray := HotKey_LangList(HotkeyDataArray) ; > HotkeyDataArray
    ; -------------------------------------------
    HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
    ; -------------------------------------------
  } ; [End] hl_LangList:
  return
  hl_040: ; (040)(Obj_LoadAtStartUp)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1 
      ; -------------------------------------------
      if (HotkeyDataArray.40.2 == 1)
      {
        StartLoad := 2 ; Load at Windows Startup
        HotkeyDataArray.40.2 := 2 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(040)_2_" HotkeyDataArray.4.1 ".png"
      } ; [End] (002_1)(UseContextMenu) == 1
      else ; (002_1)(UseContextMenu) == 2
      {
        StartLoad := 1 ; DO NOT Load at Windows Startup
        HotkeyDataArray.40.2 := 1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(040)_1_" HotkeyDataArray.4.1 ".png" ; (004_1)(Obj_ok)
      } ; [End] (002_1)(UseContextMenu) == 2
      ; -------------------------------------------
      GuiControl, HotKeySelect:, h_040, %ThisImage%
      GuiControl, HotKeySelect:Show, h_040
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    } ; [End] if (LockKeys == 0)
    ; -------------------------------------------
  } ; [End] (041_1)(Obj_ContextMenu)
  return
  hl_041: ; (041)(Obj_Context_Menu)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.2.1 == 1) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      {
        Use_ContextMenu := 2 ; Change from 1 to 2
        HotkeyDataArray.2.1 := 2 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(041)_2.png"
      } ; [End] (002_1)(UseContextMenu) == 1
      else ; (002_1)(UseContextMenu) == 2
      {
        Use_ContextMenu := 1 ; Change from 2 to 1
        HotkeyDataArray.2.1 := 1 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(041)_1.png"
      } ; [End] (002_1)(UseContextMenu) == 2
      ; -------------------------------------------
      GuiControl, HotKeySelect:, h_041, %ThisImage%
      GuiControl, HotKeySelect:Show, h_041
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    } ; [End] if (LockKeys == 0)
    ; -------------------------------------------
  } ; [End] (041_1)(Obj_ContextMenu)
  return
  hl_042: ; (042)(Obj_LButton)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.42.2 == 1) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("042", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("042", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_043: ; (043)(Obj_RButton)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.43.2 == 1) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("043", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("043", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_044: ; (044)(Obj_MButton)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.44.2 == 1) ; (044_2)(Obj_Key_NumpadAdd_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("044", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("044", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_045: ; (045)(Obj_WheeUp)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.45.2 == 1) ; (045_2)(Obj_Key_NumpadDiv_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("045", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("045", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_046: ; (046)(Obj_WheelDown)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.46.2 == 1) ; (046_2)(Obj_Key_NumpadDot_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("046", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("046", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_047: ; (047)(Obj_XButton1)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.47.2 == 1) ; (047_2)(Obj_Key_NumpadEnter_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("047", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("047", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_048: ; (048)(Obj_XButton2)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.48.2 == 1) ; (048_2)(Obj_Key_NumpadMult_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("048", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("048", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_049: ; (049)(Obj_LWin)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.49.2 == 1) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("049", HotkeyDataArray) ; (049_1)(Obj_WinLeft)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("049", HotkeyDataArray) ; (049_1)(Obj_WinLeft)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_050: ; (050)(Obj_RWin)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.50.2 == 1) ; (050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("050", HotkeyDataArray) ; (050_1)(Obj_WinRight)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("050", HotkeyDataArray) ; (050_1)(Obj_WinRight)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_051: ; (051)(Obj_Ctrl)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.51.2 == 1) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("051", HotkeyDataArray) ; (051_1)(Obj_Ctrl)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("051", HotkeyDataArray) ; (051_1)(Obj_Ctrl)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_052: ; (052)(Obj_Alt)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.52.2 == 1) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("052", HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("052", HotkeyDataArray)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_053: ; (053)(Obj_Shift)
  {
    ; -------------------------------------------
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (HotkeyDataArray.53.2 == 1) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := HotKey_SelectKey("053", HotkeyDataArray) ; (053_1)(Obj_Shift)
      }
      else
      {
        HotkeyDataArray := HotKey_UnSelectKey("053", HotkeyDataArray) ; (053_1)(Obj_Shift)
      }
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  hl_060: ; (060)(Obj_OK_Button)
  {
    if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      HotkeyDataArray := HotKey_Ok(HotkeyDataArray)
      ; -------------------------------------------
    }
  } ; [End] (060_1)(Obj_Ok)
  return
  hl_061: ; (061)(Obj_Cancel_Button)
  {
    ; -------------------------------------------
    HotkeyDataArray := HotKey_Cancel() ; > HotkeyDataArray
    ; -------------------------------------------
  } ; [End]
  return
  hl_062: ; (062)(Obj_WebLink)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Check if There ia a Internet Connection
    ; -------------------------------------------
    HasConnection := InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
    ; -------------------------------------------
    ; Check if There ia a Internet Connection
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HasConnection == 1) ; Internet Connection OK
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Get Current PopUpMenu Web Site
      ; -------------------------------------------
      PopupmenuSiteDomain := "https://popupmenu.github.io"
      ; -------------------------------------------
      ; Get Current PopUpMenu Web Site
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Open Current PopUpMenu Web Site
        ; -------------------------------------------
        UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
        ; -------------------------------------------
        LangListBox := HotkeyDataArray.63.1 ; (063_1)(Obj_SelectIconImage)
        LangListBox_Array := StrSplit(LangListBox, "|", "")
        LangListBox_Array.RemoveAt(1)
        ; -------------------------------------------
        UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        ; -------------------------------------------
        LangListArray := HotkeyDataArray.64.1 ; (064_1)(Obj_HotKey_ContextMenu)
        ; ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
        ; -------------------------------------------
        GuiControlGet, CurrentLang, HotKeySelect:, h_LangList
        ; -------------------------------------------
        for Index, ThisLang in LangListBox_Array
        {
          ; -------------------------------------------
          if (ThisLang == CurrentLang)
          {
            ; -------------------------------------------
            UserLang := LangListArray[Index] ; (004_1)(UserLang)
            HotkeyDataArray.4.1 := UserLang ; (004_1)(Obj_ok)
            GuiControl, HotKeySelect:Choose, h_LangList, %Index%
            ; -------------------------------------------
          }
        }
        PopUpMenuWebSite := PopupmenuSiteDomain "/" UserLang ".html"
        Run, %PopUpMenuWebSite%,,, Priority_PopUpMenuWebSite
        Process, Priority, %Priority_PopUpMenuWebSite%, High
        ; -------------------------------------------
        ; Open Current PopUpMenu Web Site
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Close Hotkey/Settings Gui
        ; -------------------------------------------
        if WinExist("HotKey_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
        {
          ; -------------------------------------------
          ; 1 = A window's title must start with the specified WinTitle to be a match.
          SetTitleMatchMode, 1
          WinGet, Hotkey_Id, ID , HotKey_Pop_Up_Menu ahk_class AutoHotkeyGUI
          WinClose, ahk_id %Hotkey_Id%
          ; -------------------------------------------
          ScriptPath := "C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk"
          if (Script_Running(ScriptPath) > 0) ; (running)
          {
            Script_Close(ScriptPath)
          }
          ; -------------------------------------------          
        } ; [End] if WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI")
        ; -------------------------------------------
        ; Close Hotkey/Settings Gui
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
      ; -------------------------------------------
    } ; [End] if (HasConnection == 1) ; Internet Connection OK
    ; -------------------------------------------
  } ; [End] (062_1)(Obj_WebLink)
  return
  ; -------------------------------------------
} ; Hotkey Gui Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
HotKey_TextAdjustSelect(VarName, VarValue, GuiFont, FontSize, FontColor, MaxWidth) ; > Nothing
{
  ; -------------------------------------------
  GuiControlGet, Old_Value ,, %VarName%
  if (Old_Value != VarValue)
  {
    ; -------------------------------------------
    ThisWidth := ""
    ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
    ; -------------------------------------------
    FontChange := 0
    if (MaxWidth == 480)
    {
      if (FontSize == 14 && ThisWidth > 473)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 450)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 476)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth = 480)
    ; -------------------------------------------
    else if (MaxWidth == 275)
    {
      if (FontSize == 14 && ThisWidth > 275)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 270)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 273)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 275)
    ; -------------------------------------------
    else if (MaxWidth == 200)
    {
      ; -------------------------------------------
      if (FontSize == 14 && ThisWidth > 194)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      ; -------------------------------------------
      if (FontSize == 12 && ThisWidth > 169)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      ; -------------------------------------------
      if (FontSize == 10 && ThisWidth > 196)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    else if (MaxWidth == 173)
    {
      if (FontSize == 14 && ThisWidth > 176)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 171)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 175)
      {
        FontChange := 1
        FontSize := 8
      } ; End (FontSize == 10 && ThisWidth > 420)
    } ; End (MaxWidth == 173)
    ; -------------------------------------------
    else if (MaxWidth == 158)
    {
      if (FontSize == 14 && ThisWidth > 154)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 153)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 154)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    else if (MaxWidth == 40)
    {
      if (FontSize == 14 && ThisWidth > 33)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 36)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 35)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    GuiControl, HotKeySelect:, %VarName%, %VarValue%
    ; -------------------------------------------
    if (FontChange == 1 or FontColor)
    {
      if FontSize
      {
        Gui, HotKeySelect:Font, s%FontSize%, %GuiFont%
      } ; End if FontSize
      if FontColor
      {
        Gui, HotKeySelect:Font, c%FontColor%, %GuiFont%
      } ; End if FontColor
      else
      {
        Gui, HotKeySelect:Font, cBlack, %GuiFont%
      } ; End else
      GuiControl, HotKeySelect:+Redraw, %VarName%,
      GuiControl, HotKeySelect:Font, %VarName%
    } ; End (FontChange == 1 or FontColor)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  GuiControl, HotKeySelect:Show, %VarName%
  ; -------------------------------------------
} ; [End] HotKey_TextAdjustSelect(VarName, VarValue, GuiFont, FontSize, FontColor, MaxWidth) ; > Nothing
; -------------------------------------------
HotKey_UnSelectKey(ThisKey, HotkeyDataArray) ; > HotkeyDataArray
{
  ; -------------------------------------------
  if (ThisKey == "042") ; (042_1)(Obj_MouseLeft)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "042") ; (042_1)(Obj_MouseLeft)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "043") ; (043_1)(Obj_MouseRight)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "043") ; (043_1)(Obj_MouseRight)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "044") ; (044_1)(Obj_MouseMiddle)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      ; -------------------------------------------
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      ; -------------------------------------------
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "044") ; (044_1)(Obj_MouseMiddle)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "045") ; (045_1)(Obj_MouseWheelUp)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "WheelUP", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "045") ; (045_1)(Obj_MouseWheelUp)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "046") ; (046_1)(Obj_MouseWheelDown)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "046") ; (046_1)(Obj_MouseWheelDown)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "047") ; (047_1)(Obj_MouseX1)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "047") ; (047_1)(Obj_MouseX1)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "048") ; (048_1)(Obj_MouseX2)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray) ; (148_1)(Obj_HotKey_MouseX2)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "048") ; (048_1)(Obj_MouseX2)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "049") ; (049_1)(Obj_WinLeft)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "#", "")
    UserHotkey := StrReplace(UserHotkey, "LWin", "")
    UserHotkey := StrReplace(UserHotkey, "RWin", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("049", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([42, 43], HotkeyDataArray) == 0) ; (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.42.2 == 2) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 2) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
    } ; [End] (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "049") ; (049_1)(Obj_WinLeft)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "050") ; (050_1)(Obj_WinRight)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "#", "")
    UserHotkey := StrReplace(UserHotkey, "LWin", "")
    UserHotkey := StrReplace(UserHotkey, "RWin", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("049", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([42, 43], HotkeyDataArray) == 0) ; (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.42.2 == 2) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 2) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
    } ; [End] (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "050") ; (050_1)(Obj_WinRight)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "051") ; (051_1)(Obj_Ctrl)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "^", "")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      UserHotkey := StrReplace(UserHotkey, "#", "LWin")
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("051", 1, 1, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([42, 43], HotkeyDataArray) == 0) ; (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.42.2 == 2) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 2) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
    } ; [End] (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "051") ; (051_1)(Obj_Ctrl)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "052") ; (052_1)(Obj_Alt)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "!", "")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      UserHotkey := StrReplace(UserHotkey, "#", "LWin")
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("052", 1, 1, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([42, 43], HotkeyDataArray) == 0) ; (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.42.2 == 2) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 2) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
    } ; [End] (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than Shift 053 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.53.2 == 2) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Shift 053 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "052") ; (052_1)(Obj_Alt)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "053") ; (053_1)(Obj_Shift)
  {
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "+", "")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "")
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      UserHotkey := StrReplace(UserHotkey, "#", "LWin")
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("053", 1, 1, HotkeyDataArray)
    ; -------------------------------------------
    if (HotKey_CheckSelected([42, 43], HotkeyDataArray) == 0) ; (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.42.2 == 2) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 2) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
    } ; [End] (Other Than Mouse Left 042/Right 043 Keys)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than Ctrl 051 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.51.2 == 2) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Ctrl 051 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than Alt 052 Key)(No Keys Selected)
    {
      if (HotkeyDataArray.52.2 == 2) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
    } ; [End] (Other Than Alt 052 Key)(No Keys Selected)
    ; -------------------------------------------
    if (HotKey_CheckSelected([49, 50], HotkeyDataArray) == 0) ; (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    {
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
        UserHotkey := StrReplace(UserHotkey, "#", "LWin")
        HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
    } ; [End] (Other Than Windows Left 049/Right 050 Keys)(No Keys Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "053") ; (053_1)(Obj_Shift)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return HotkeyDataArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] HotKey_UnSelectKey(ThisKey, HotkeyDataArray) ; > HotkeyDataArray
; -------------------------------------------
HotKey_SelectKey(ThisKey, HotkeyDataArray) ; HotkeyDataArray
{
  ; -------------------------------------------
  UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "042") ; (042_1)(Obj_MouseLeft)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := UserHotkey "LButton"
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Other Mouse Keys)(No Keys Selected)
    if (HotKey_CheckSelected([42, 43, 44, 45, 46, 47, 48], HotkeyDataArray) == 0)
    {
      HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
    }
    else
    {
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      ; -------------------------------------------
      { ; Control Keys
        ; -------------------------------------------
        if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
        }
        if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
        }
        if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
        }
        ; -------------------------------------------
      } ; End Control Keys
      ; -------------------------------------------
      { ; Windows Key
        ; -------------------------------------------
        if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
          HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
        }
        ; -------------------------------------------
      } ; End Windows Key
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "042")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "043") ; (043_1)(Obj_MouseRight)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := UserHotkey "RButton"
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Other Mouse Keys)(No Keys Selected)
    if (HotKey_CheckSelected([42, 43, 44, 45, 46, 47, 48], HotkeyDataArray) == 0)
    {
      HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
    }
    else
    {
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      ; -------------------------------------------
      { ; Control Keys
        ; -------------------------------------------
        if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
        }
        if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
        }
        if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
        }
        ; -------------------------------------------
      } ; End Control Keys
      ; -------------------------------------------
      { ; Windows Key
        ; -------------------------------------------
        if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
        {
          HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
          HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
        } ; [End] (049_2)(Obj_WinLeft_Sel [0,1,2,3])/(050_2)(Obj_WinRight_Sel [0,1,2,3])
        ; -------------------------------------------
      } ; End Windows Key
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "043")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "044") ; (044_1)(Obj_MouseMiddle)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := UserHotkey "MButton"
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("044", 2, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "044")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "045") ; (045_1)(Obj_MouseWheelUp)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := UserHotkey "WheelUp"
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("045", 2, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "045")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "046") ; (046_1)(Obj_MouseWheelDown)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := UserHotkey "WheelDown"
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("046", 2, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "046")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "047") ; (047_1)(Obj_MouseX1)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := UserHotkey "XButton1"
    UserHotkey := StrReplace(UserHotkey, "XButton2", "")
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("047", 2, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "048") ; (048_1)(Obj_MouseX2)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    UserHotkey := StrReplace(UserHotkey, "LWin", "#")
    UserHotkey := StrReplace(UserHotkey, "RWin", "#")
    UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
    UserHotkey := StrReplace(UserHotkey, "Alt", "!")
    UserHotkey := StrReplace(UserHotkey, "Shift", "+")
    ; -------------------------------------------
    UserHotkey := StrReplace(UserHotkey, "LButton", "")
    UserHotkey := StrReplace(UserHotkey, "RButton", "")
    UserHotkey := StrReplace(UserHotkey, "MButton", "")
    UserHotkey := StrReplace(UserHotkey, "WheelUp", "")
    UserHotkey := StrReplace(UserHotkey, "WheelDown", "")
    UserHotkey := StrReplace(UserHotkey, "XButton1", "")
    UserHotkey := UserHotkey "XButton2"
    HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    ; -------------------------------------------
    HotkeyDataArray := GuiImageControl("048", 2, 0, HotkeyDataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
    }
    if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
    {
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "048")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "049") ; (049_1)(Obj_WinLeft)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotKey_CheckSelected([149, 150], HotkeyDataArray) == 0) ; (Other Windows Keys 049 050)(No Keys Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "LWin"
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
      ; -------------------------------------------
    } ; [End] (Other Windows Keys 049 050)(No Keys Selected)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else ; (Other Windows Keys 049 050)(One or More Selected)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "#" UserHotkey
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HotkeyDataArray.42.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 3) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End (Other Windows Keys 049 050)(One or More Selected)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "049")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "050") ; (050_1)(Obj_WinRight)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotKey_CheckSelected([149, 150], HotkeyDataArray) == 0) ; (Other Windows Keys 049 050)(No Keys Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "LWin"
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
      ; -------------------------------------------
    } ; [End] (Other Windows Keys 049 050)(No Keys Selected)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else ; (Other Windows Keys 049 050)(One or More Selected)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "#" UserHotkey
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HotkeyDataArray.42.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 3) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End ; (Other Windows Keys 049 050)(One or More Selected)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "050")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "051") ; (051_1)(Obj_Ctrl)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotKey_CheckSelected([51], HotkeyDataArray) == 0) ; (Other Than_051)(Ctrl Key)(No Keys Selected)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "^"
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (Other Than_051)(Ctrl Key)(No Keys Selected)
    ; -------------------------------------------
    else ; (NOT Ctrl)(One or More Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HotKey_CheckSelected([49, 50, 51, 52, 53], HotkeyDataArray) == 0) ; (Mouse Keys)(No Keys Selected)
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#")
        UserHotkey := StrReplace(UserHotkey, "Alt", "!")
        UserHotkey := StrReplace(UserHotkey, "Shift", "+")
        UserHotkey := UserHotkey "Ctrl"
      } ; [End] ; (Mouse Keys)(No Keys Selected)
      else ; (Mouse Keys)(One or More Selected)
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#^")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#^")
        UserHotkey := StrReplace(UserHotkey, "LButton", "^LButton")
        UserHotkey := StrReplace(UserHotkey, "RButton", "^RButton")
        UserHotkey := StrReplace(UserHotkey, "MButton", "^MButton")
        UserHotkey := StrReplace(UserHotkey, "WheelUp", "^WheelUp")
        UserHotkey := StrReplace(UserHotkey, "WheelDown", "^WheelDown")
        UserHotkey := StrReplace(UserHotkey, "XButton1", "^XButton1")
        UserHotkey := StrReplace(UserHotkey, "XButton2", "^XButton2")
      } ; [End] (Mouse Keys)(One or More Selected)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HotkeyDataArray.42.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.43.2 == 3) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End (NOT Ctrl)(One or More Selected)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (ThisKey == "051")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "052") ; (052_1)(Obj_Alt)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HotKey_CheckSelected([52], HotkeyDataArray) == 0) ; (Other Than_052)(Alt Key)(No Keys Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "!"
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      ; -------------------------------------------
    } ; [End] (Other Than_052)(Alt Key)(No Keys Selected)
    ; -------------------------------------------
    else ; (Other Than Alt Key)(One or More Selected)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      if (HotKey_CheckSelected([49, 50, 51, 52, 53], HotkeyDataArray) == 0) ; (Mouse Keys)(No Keys Selected)
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#")
        UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
        UserHotkey := StrReplace(UserHotkey, "Shift", "+")
        UserHotkey := UserHotkey "Alt"
      } ; [End] (Mouse Keys)(No Keys Selected)
      ; -------------------------------------------
      else ; a Mouse Key is Selected
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#!")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#!")
        UserHotkey := StrReplace(UserHotkey, "LButton", "!LButton")
        UserHotkey := StrReplace(UserHotkey, "RButton", "!RButton")
        UserHotkey := StrReplace(UserHotkey, "MButton", "!MButton")
        UserHotkey := StrReplace(UserHotkey, "WheelUp", "!WheelUp")
        UserHotkey := StrReplace(UserHotkey, "WheelDown", "!WheelDown")
        UserHotkey := StrReplace(UserHotkey, "XButton1", "!XButton1")
        UserHotkey := StrReplace(UserHotkey, "XButton2", "!XButton2")
      } ; [End] a Mouse Key is Selected
      ; -------------------------------------------
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HotkeyDataArray.42.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 3) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.53.2 == 3) ; (053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End (Other Than Alt Key)(One or More Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "052")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ThisKey == "053") ; (053_1)(Obj_Shift)
  {
    ; -------------------------------------------
    if (HotKey_CheckSelected([53], HotkeyDataArray) == 0) ; (Other Than_053)(Shift Key)(No Keys Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      UserHotkey := "+"
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      ; -------------------------------------------
    } ; [End] (Other Than_053)(Shift Key)(No Keys Selected)
    ; -------------------------------------------
    else ; (Other Than Shift Key)(One or More Selected)
    {
      ; -------------------------------------------
      UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      if (HotKey_CheckSelected([49, 50, 51, 52, 53], HotkeyDataArray) == 0) ; (Mouse Keys)(No Keys Selected)
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#")
        UserHotkey := StrReplace(UserHotkey, "Ctrl", "^")
        UserHotkey := StrReplace(UserHotkey, "Alt", "!")
        UserHotkey := UserHotkey "Shift"
      }
      else ; a Mouse Key is Selected
      {
        UserHotkey := StrReplace(UserHotkey, "LWin", "#+")
        UserHotkey := StrReplace(UserHotkey, "RWin", "#+")
        UserHotkey := StrReplace(UserHotkey, "LButton", "+LButton")
        UserHotkey := StrReplace(UserHotkey, "RButton", "+RButton")
        UserHotkey := StrReplace(UserHotkey, "MButton", "+MButton")
        UserHotkey := StrReplace(UserHotkey, "WheelUp", "+WheelUp")
        UserHotkey := StrReplace(UserHotkey, "WheelDown", "+WheelDown")
        UserHotkey := StrReplace(UserHotkey, "XButton1", "+XButton1")
        UserHotkey := StrReplace(UserHotkey, "XButton2", "+XButton2")
      } ; [End] a Mouse Key is Selected
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      HotkeyDataArray.1.1 := UserHotkey ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      ; -------------------------------------------
      HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      if (HotkeyDataArray.42.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.43.2 == 3) ; (043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      if (HotkeyDataArray.51.2 == 3) ; (051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      }
      if (HotkeyDataArray.52.2 == 3) ; (052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (HotkeyDataArray.49.2 == 2 or HotkeyDataArray.50.2 == 2) ; (049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
    } ; End (Other Than Shift Key)(One or More Selected)
    ; -------------------------------------------
  } ; [End] if (ThisKey == "053")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return HotkeyDataArray
  ; -------------------------------------------
} ; [End] HotKey_SelectKey(ThisKey, HotkeyDataArray) ; HotkeyDataArray
; -------------------------------------------
HotKey_LangList(HotkeyDataArray) ; > HotkeyDataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [SET] UserLang from Currently Selected DropDownList
  ; -------------------------------------------
  UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
  ; -------------------------------------------
  LangListBox := HotkeyDataArray.63.1 ; (063_1)(Obj_SelectIconImage)
  LangListBox_Array := StrSplit(LangListBox, "|", "")
  LangListBox_Array.RemoveAt(1)
  ; -------------------------------------------
  UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
  ; -------------------------------------------
  LangListArray := HotkeyDataArray.64.1 ; (064_1)(Obj_HotKey_ContextMenu)
  ; ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  GuiControlGet, CurrentLang, HotKeySelect:, h_LangList
  ; -------------------------------------------
  for Index, ThisLang in LangListBox_Array
  {
    ; -------------------------------------------
    if (ThisLang == CurrentLang)
    {
      ; -------------------------------------------
      UserLang := LangListArray[Index] ; (004_1)(UserLang)
      HotkeyDataArray.4.1 := UserLang ; (004_1)(Obj_ok)
      GuiControl, HotKeySelect:Choose, h_LangList, %Index%
      ; -------------------------------------------
    }
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; (Key Positions) (Key Images)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      h_042_Pos := InStr(UserHotkey, "LButton") ; (042_1)(Obj_MouseLeft)
      h_043_Pos := InStr(UserHotkey, "RButton") ; (043_1)(Obj_MouseRight)
      h_044_Pos := InStr(UserHotkey, "MButton") ; (044_1)(Obj_MouseMiddle)
      h_045_Pos := InStr(UserHotkey, "WheelUp") ; (045_1)(Obj_MouseWheelUp)
      h_046_Pos := InStr(UserHotkey, "WheelDown") ; (046_1)(Obj_MouseWheelDown)
      h_047_Pos := InStr(UserHotkey, "XButton1") ; (047_1)(Obj_MouseX1)
      h_048_Pos := InStr(UserHotkey, "XButton2") ; (048_1)(Obj_MouseX2)
      ; -------------------------------------------
      h_049_Pos := InStr(UserHotkey, "LWin") ; (049_1)(Obj_WinLeft)
      h_050_Pos := InStr(UserHotkey, "RWin") ; (050_1)(Obj_WinRight)
      Win_Pos := InStr(UserHotkey, "#")
      h_051_Pos := InStr(UserHotkey, "^") ; (051_1)(Obj_Ctrl)
      ; -------------------------------------------
      if (h_051_Pos == 0) ; (051_1)(Obj_Ctrl)
      {
        h_051_Pos := InStr(UserHotkey, "Ctrl") ; (051_1)(Obj_Ctrl)
      }
      ; -------------------------------------------
      h_052_Pos := InStr(UserHotkey, "!") ; (052_1)(Obj_Alt)
      ; -------------------------------------------
      if (h_052_Pos == 0) ; (052_1)(Obj_Alt)
      {
        h_052_Pos := InStr(UserHotkey, "Alt") ; (052_1)(Obj_Alt)
      }
      ; -------------------------------------------
      h_053_Pos := InStr(UserHotkey, "+") ; (053_1)(Obj_Shift)
      ; -------------------------------------------
      if (h_053_Pos == 0) ; (053_1)(Obj_Shift)
      {
        h_053_Pos := InStr(UserHotkey, "Shift") ; (053_1)(Obj_Shift)
      }
      ; -------------------------------------------
    } ; End [GET] (Key Positions) (Hot Key is SET)
    else ; [SET] (Key Positions to 0) (Hot Key is NOT Set)
    {
      h_042_Pos := 0 ; (042_1)(Obj_MouseLeft)
      h_043_Pos := 0 ; (043_1)(Obj_MouseRight)
      h_044_Pos := 0 ; (044_1)(Obj_MouseMiddle)
      h_045_Pos := 0 ; (045_1)(Obj_MouseWheelUp)
      h_046_Pos := 0 ; (046_1)(Obj_MouseWheelDown)
      h_047_Pos := 0 ; (047_1)(Obj_MouseX1)
      h_048_Pos := 0 ; (048_1)(Obj_MouseX2)
      h_049_Pos := 0 ; (049_1)(Obj_WinLeft)
      h_050_Pos := 0 ; (050_1)(Obj_WinRight)
      h_051_Pos := 0 ; (051_1)(Obj_Ctrl)
      h_052_Pos := 0 ; (052_1)(Obj_Alt)
      h_053_Pos := 0 ; (053_1)(Obj_Shift)
      Win_Pos := 0
    } ; End [SET] (Key Positions to 0) (Hot Key is NOT Set)
    ; -------------------------------------------
    ; End (Key Positions)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>          
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] (Key Images)
    ; -------------------------------------------
    if (h_042_Pos == 0) ; <Control Key> (042_1)(Obj_MouseLeft)
    {
      HotkeyDataArray := GuiImageControl("042", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else ; 
    {
      ; ------------------------------------------- <Control Key> (042_1)(Obj_MouseLeft)
      if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 2, 0, HotkeyDataArray)
      }
      else if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("042", 3, 0, HotkeyDataArray)
      }
      ; ------------------------------------------- <Control Key> (042_1)(Obj_MouseLeft)
    }
    ; -------------------------------------------
    if (h_043_Pos == 0) ; <Control Key> (043_1)(Obj_MouseRight)
    {
      HotkeyDataArray := GuiImageControl("043", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      ; ------------------------------------------- <Control Key> (043_1)(Obj_MouseRight)
      if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 2, 0, HotkeyDataArray)
      }
      else if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("043", 3, 0, HotkeyDataArray)
      }
      ; ------------------------------------------- <Control Key> (043_1)(Obj_MouseRight)
    }
    ; -------------------------------------------
    if (h_044_Pos == 0) ; (044_1)(Obj_MouseMiddle)
    {
      HotkeyDataArray := GuiImageControl("044", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      HotkeyDataArray := GuiImageControl("044", 2, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    if (h_045_Pos == 0) ; (045_1)(Obj_MouseWheelUp)
    {
      HotkeyDataArray := GuiImageControl("045", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      HotkeyDataArray := GuiImageControl("045", 2, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    if (h_046_Pos == 0) ; (046_1)(Obj_MouseWheelDown)
    {
      HotkeyDataArray := GuiImageControl("046", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      HotkeyDataArray := GuiImageControl("046", 2, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    if (h_047_Pos == 0) ; (047_1)(Obj_MouseX1)
    {
      HotkeyDataArray := GuiImageControl("047", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      HotkeyDataArray := GuiImageControl("047", 2, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    if (h_048_Pos == 0) ; (048_1)(Obj_MouseX2)
    {
      HotkeyDataArray := GuiImageControl("048", 1, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      HotkeyDataArray := GuiImageControl("048", 2, 0, HotkeyDataArray)
    }
    ; -------------------------------------------
    if (h_049_Pos == 0 && h_050_Pos == 0) ; (049_1)(Obj_WinLeft)/(050_1)(Obj_WinRight)
    {
      ; -------------------------------------------
      if (Win_Pos == 0)
      {
        HotkeyDataArray := GuiImageControl("049", 1, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
        HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      if (h_049_Pos == 0) ; (049_1)(Obj_WinLeft)
      {
        HotkeyDataArray := GuiImageControl("049", 1, 0, HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := GuiImageControl("049", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
      if (h_050_Pos == 0) ; (050_1)(Obj_WinRight)
      {
        HotkeyDataArray := GuiImageControl("050", 1, 0, HotkeyDataArray)
      }
      else
      {
        HotkeyDataArray := GuiImageControl("050", 2, 0, HotkeyDataArray)
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (h_051_Pos == 0) ; <Control Key> (051_1)(Obj_Ctrl)
    {
      HotkeyDataArray := GuiImageControl("051", 1, 1, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      ; ------------------------------------------- <Control Key> (051_1)(Obj_Ctrl)
      if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 2, 1, HotkeyDataArray)
      }
      else if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("051", 3, 1, HotkeyDataArray)
      }
      ; ------------------------------------------- <Control Key> (051_1)(Obj_Ctrl)
    }
    ; -------------------------------------------
    if (h_052_Pos == 0) ; <Control Key> (052_1)(Obj_Alt)
    {
      HotkeyDataArray := GuiImageControl("052", 1, 1, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      ; ------------------------------------------- <Control Key> (052_1)(Obj_Alt)
      if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 2, 1, HotkeyDataArray)
      }
      else if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("052", 3, 1, HotkeyDataArray)
      }
      ; ------------------------------------------- <Control Key> (052_1)(Obj_Alt)
    }
    ; -------------------------------------------
    if (h_053_Pos == 0) ; <Control Key> (053_1)(Obj_Shift)
    {
      HotkeyDataArray := GuiImageControl("053", 1, 1, HotkeyDataArray)
    }
    ; -------------------------------------------
    else
    {
      ; ------------------------------------------- <Control Key> (053_1)(Obj_Shift)
      if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 2, 1, HotkeyDataArray)
      }
      else if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        HotkeyDataArray := GuiImageControl("053", 3, 1, HotkeyDataArray)
      }
      ; ------------------------------------------- <Control Key> (053_1)(Obj_Shift)
    }
    ; -------------------------------------------
  } ; [End] (Key Positions) (Key Images)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Language (Flag, Header, StartLoad)
  ; -------------------------------------------
  ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(142)_" UserLang ".png"
  GuiControl, HotKeySelect:, h_LangFlag, %ThisImage%
  ; -------------------------------------------
  HeaderImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\Header_" UserLang ".png"
  GuiControl, HotKeySelect:, h_Header, %HeaderImage%
  ; -------------------------------------------
  if (HotkeyDataArray.40.2 == 2) ; (040_2)(Obj_Key_Numpad6_Sel [0,1,2,3])
  {
    ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(040)_2_" UserLang ".png"
  } ; [End] (002_1)(UseContextMenu) == 1
  else ; (002_1)(UseContextMenu) == 2
  {
    ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(040)_1_" UserLang ".png"
  } ; [End] (002_1)(UseContextMenu) == 2
  ; -------------------------------------------
  GuiControl, HotKeySelect:, h_040, %ThisImage%
  GuiControl, HotKeySelect:Show, h_040
  ; -------------------------------------------
  ; [End] Language (Flag, Header, StartLoad)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  HotkeyDataArray := HotKey_Validate(HotkeyDataArray)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [UPDATE] File_UserLang.txt
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
  if (Script_Running(ScriptPath) == 0) ; (NOT Running)
  {
    ; -------------------------------------------
    UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
    ; -------------------------------------------
    File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
    if FileExist(File_UserLang)
    {
      FileDelete, %File_UserLang%
    }
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
    Sleep, 100
    ; -------------------------------------------
  } ; [End] if (Script_Running(ScriptPath) == 0)
  ; -------------------------------------------
  ; [UPDATE] File_UserLang.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return HotkeyDataArray
  ; -------------------------------------------
} ; [End] HotKey_LangList(HotkeyDataArray) ; > HotkeyDataArray
; -------------------------------------------
HotKey_Validate(HotkeyDataArray) ; > HotkeyDataArray
{
  ; -------------------------------------------
  UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
  HotkeyDataArray.60.2 := 1 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
  ; -------------------------------------------
  { ; (Disable / Enable) OK
    ; -------------------------------------------
    Use_ContextMenu := HotkeyDataArray.2.1 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
    ; -------------------------------------------
    ; (All Keys)(None Selected)
    if (HotkeyDataArray.42.2 == 1 && HotkeyDataArray.43.2 == 1 && HotkeyDataArray.44.2 == 1 && HotkeyDataArray.45.2 == 1 && HotkeyDataArray.46.2 == 1 && HotkeyDataArray.47.2 == 1 && HotkeyDataArray.48.2 == 1 && HotkeyDataArray.49.2 == 1 && HotkeyDataArray.50.2 == 1 && HotkeyDataArray.51.2 == 1 && HotkeyDataArray.52.2 == 1 && HotkeyDataArray.53.2 == 1) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])/(043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])/(044_2)(Obj_Key_NumpadAdd_Sel [0,1,2,3])/(045_2)(Obj_Key_NumpadDiv_Sel [0,1,2,3])/(046_2)(Obj_Key_NumpadDot_Sel [0,1,2,3])/(047_2)(Obj_Key_NumpadEnter_Sel [0,1,2,3])/(048_2)(Obj_Key_NumpadMult_Sel [0,1,2,3])/(049_2)(Obj_Key_NumpadSub_Sel [0,1,2,3])/(050_2)(Obj_Key_Shift_Sel [0,1,2,3])/(051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])/(052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])/(053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      if (HotkeyDataArray.2.1 == 1) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      {
        HotkeyDataArray.60.2 := 3 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      }
      else
      {
         HotkeyDataArray.60.2 := 1 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      }
    } ; End (All Keys)(None Selected)
    ; -------------------------------------------
    ; (Control Keys, Mouse Left/Right Keys)(One Not Valid)
    else if (HotkeyDataArray.42.2 == 3 or HotkeyDataArray.43.2 == 3 or HotkeyDataArray.51.2 == 3 or HotkeyDataArray.52.2 == 3 or HotkeyDataArray.53.2 == 3) ; (042_2)(Obj_Key_Numpad8_Sel [0,1,2,3])/(043_2)(Obj_Key_Numpad9_Sel [0,1,2,3])/(051_2)(Obj_Key_ShiftDown_Sel [0,1,2,3])/(052_2)(Obj_Key_ShiftLeft_Sel [0,1,2,3])/(053_2)(Obj_Key_ShiftRight_Sel [0,1,2,3])
    {
      HotkeyDataArray.60.2 := 3 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    } ; End (Control Keys, Mouse Left/Right Keys)(One Not Valid)
    else
    {
      HotkeyDataArray.60.2 := 1 ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    }
    ; -------------------------------------------
  } ; [End] (Disable / Enable) OK
  ; -------------------------------------------
  { ; Images [Ok,Cancel]
    ; -------------------------------------------
    if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    {
      ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(004)_1.png" 
    }
    if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
    {
      ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(004)_3.png" 
    }
    HotkeyDataArray.60.3 := ThisImage ; (060_3)(Obj_Key_WinRight_Img [Image Path])
    GuiControl, HotKeySelect:, h_060, %ThisImage% ; (Obj_Ok)
    GuiControl, HotKeySelect:Show, h_060 ; (Obj_Ok)
    ; -------------------------------------------
    ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(062)_1.png" 
    GuiControl, HotKeySelect:, h_061, %ThisImage% ; (Obj_Cancel)
    GuiControl, HotKeySelect:Show, h_061 ; (Obj_Cancel)
    ; -------------------------------------------
  } ; [End] Images [Ok,Cancel]
  ; -------------------------------------------
  { ; [SET] Display Text
    ; -------------------------------------------
    HotkeyDataArray := HotKey_TextDisplay(HotkeyDataArray)
    ; -------------------------------------------
    KeyStrokeMsg := HotkeyDataArray.21.1 ; (021_1)(Obj_Key_EscX2)
    ; -------------------------------------------
    HotkeyMsg2 := HotkeyDataArray.23.1 ; (023_1)(Obj_Key_F2)
    HotkeyMsg3 := HotkeyDataArray.24.1 ; (024_1)(Obj_Key_F3)
    HotkeyMsg4 := HotkeyDataArray.25.1 ; (025_1)(Obj_Key_F4)
    HotkeyMsg5 := HotkeyDataArray.26.1 ; (026_1)(Obj_Key_F5)
    HotkeyMsg6 := HotkeyDataArray.27.1 ; (027_1)(Obj_Key_F6)
    HotkeyMsg7 := HotkeyDataArray.28.1 ; (028_1)(Obj_Key_F7)
    HotkeyMsg8 := HotkeyDataArray.29.1 ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    FontSize := 12
    MaxWidth := 480
    GuiFont := HotkeyDataArray.5.1 ; (005_1)(ORG_ScriptType)
    ; -------------------------------------------
    ; HotkeyMsg2 = "This is a good Keystroke"
    ; HotkeyMsg3 = "This keystroke is not good"
    ; HotkeyMsg4 = "(Recommended) Choose a Keystroke"
    ; HotkeyMsg5 = "Right Click Menu (Selected)"
    ; HotkeyMsg6 = "Right Click Menu (Not Selected)"
    ; HotkeyMsg7 := "Must Choose a Keystroke"
    ; HotkeyMsg8 := "or Select Right Click Menu"
    ; -------------------------------------------
    if (HotkeyDataArray.1.1 == "" && HotkeyDataArray.2.1 == 1) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)/(002_1)(Obj_KeyOflRunRwh_2RAppIco)
    {
      ; -------------------------------------------
      ; Hotkey  - Not Selected
      ; Context - Not Selected
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; HotkeyMsg7 := "Must Choose a Keystroke"
      ; HotkeyMsg8 := "or Select Right Click Menu"
      ; -------------------------------------------
      FontColor := "a30404" ; (Red)
      ; FontColor := "199524" ; (Green)
      ; FontColor := "087417" ; (Green Dark)
      ; FontColor := "c000a0" ; (Purple)
      ; FontColor := "c6700b" ; (Yellow/Brown)
      ; -------------------------------------------
      HotKey_TextAdjustSelect("h_070", HotkeyMsg7, GuiFont, FontSize, FontColor, MaxWidth)
      HotKey_TextAdjustSelect("h_071", HotkeyMsg8, GuiFont, FontSize, FontColor, MaxWidth)
      ; -------------------------------------------
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Blank No Keystroke
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      HotkeyDataArray.72.3 := "" ; (072_3)(Obj_Key_AppOnly_Img [Image Path])
      ; -------------------------------------------
      GuiControl, HotKeySelect:Hide, h_072
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; -------------------------------------------
      ; HotkeyMsg6 = "Right Click Menu (Not Selected)"
      ; -------------------------------------------
      ; FontColor := "a30404" ; (Red)
      ; FontColor := "199524" ; (Green)
      ; FontColor := "087417" ; (Green Dark)
      ; FontColor := "c000a0" ; (Purple)
      FontColor := "c6700b" ; (Yellow/Brown)
      ; -------------------------------------------
      HotKey_TextAdjustSelect("h_073", HotkeyMsg6, GuiFont, FontSize, FontColor, MaxWidth)
      ; -------------------------------------------
    }
    else if (HotkeyDataArray.1.1 == "" && HotkeyDataArray.2.1 == 2) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)/(002_1)(Obj_KeyOflRunRwh_2RAppIco)
    {
      ; -------------------------------------------
      ; Hotkey  - Not Selected
      ; Context - Selected
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; HotkeyMsg4 = "(Recommended) Choose a Keystroke"
      ; -------------------------------------------
      ; FontColor := "a30404" ; (Red)
      ; FontColor := "199524" ; (Green)
      ; FontColor := "087417" ; (Green Dark)
      FontColor := "c000a0" ; (Purple)
      ; FontColor := "c6700b" ; (Yellow/Brown)
      ; -------------------------------------------
      HotKey_TextAdjustSelect("h_070", HotkeyMsg4, GuiFont, FontSize, FontColor, MaxWidth)
      GuiControl, HotKeySelect:Hide, h_071
      ; -------------------------------------------
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Blank No Keystroke
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      HotkeyDataArray.72.3 := "" ; (072_3)(Obj_Key_AppOnly_Img [Image Path])
      ; -------------------------------------------
      GuiControl, HotKeySelect:Hide, h_072
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; -------------------------------------------
      ; HotkeyMsg5 = "Right Click Menu (Selected)"
      ; -------------------------------------------
      ; FontColor := "a30404" ; (Red)
      ; FontColor := "199524" ; (Green)
      FontColor := "087417" ; (Green Dark)
      ; FontColor := "c000a0" ; (Purple)
      ; FontColor := "c6700b" ; (Yellow/Brown)
      ; -------------------------------------------
      HotKey_TextAdjustSelect("h_073", HotkeyMsg5, GuiFont, FontSize, FontColor, MaxWidth)
      ; -------------------------------------------
    } ; [End] (001_1)(UserHotkey) == "" && (002_1)(UseContextMenu) == 2
    else ; (001_1)(UserHotkey) != "" or (002_1)(UseContextMenu) != 2
    {
      ; -------------------------------------------
      ; One or More Keys Selected
      ; -------------------------------------------
      if (HotkeyDataArray.60.2 == 3) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        ; -------------------------------------------
        ; Hotkey  - InValid Keystroke
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text1
        ; HotkeyMsg3 = "This keystroke is not good"
        ; -------------------------------------------
        FontColor := "a30404" ; (Red)
        ; FontColor := "199524" ; (Green)
        ; FontColor := "087417" ; (Green Dark)
        ; FontColor := "c000a0" ; (Purple)
        ; FontColor := "c6700b" ; (Yellow/Brown)
        ; -------------------------------------------
        HotKey_TextAdjustSelect("h_070", HotkeyMsg3, GuiFont, FontSize, FontColor, MaxWidth)
        GuiControl, HotKeySelect:Hide, h_071
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text1
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text2
        if (HotkeyDataArray.1.1 == "") ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        {
          ; -------------------------------------------
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Blank No Keystroke
          ; -------------------------------------------
          HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
          HotkeyDataArray.72.3 := "" ; (072_3)(Obj_Key_AppOnly_Img [Image Path])
          ; -------------------------------------------
          GuiControl, HotKeySelect:Hide, h_072
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; -------------------------------------------
        } ; [End] (001_1)(UserHotkey) is ""
        else ; (001_1)(UserHotkey) is NOT ""
        {
          ; -------------------------------------------
          ; KeyStrokeMsg
          ; -------------------------------------------
          ; FontColor := "a30404" ; (Red)
          ; FontColor := "199524" ; (Green)
          ; FontColor := "087417" ; (Green Dark)
          ; FontColor := "c000a0" ; (Purple)
          FontColor := "c6700b" ; (Yellow/Brown)
          ; -------------------------------------------
          HotKey_TextAdjustSelect("h_072", KeyStrokeMsg, GuiFont, FontSize, FontColor, MaxWidth)
          ; -------------------------------------------
        } ; [End] (001_1)(UserHotkey) is NOT ""
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text2
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text3
        if (HotkeyDataArray.2.1 == 1) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        {
          ; -------------------------------------------
          ; HotkeyMsg6 = "Right Click Menu (Not Selected)"
          ; -------------------------------------------
          ; FontColor := "a30404" ; (Red)
          ; FontColor := "199524" ; (Green)
          ; FontColor := "087417" ; (Green Dark)
          ; FontColor := "c000a0" ; (Purple)
          FontColor := "c6700b" ; (Yellow/Brown)
          ; -------------------------------------------
          HotKey_TextAdjustSelect("h_073", HotkeyMsg6, GuiFont, FontSize, FontColor, MaxWidth)
          ; -------------------------------------------
        } ; [End] (002_1)(UseContextMenu) == 1
        else if (HotkeyDataArray.2.1 == 2) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        {
          ; -------------------------------------------
          ; HotkeyMsg5 = "Right Click Menu (Selected)"
          ; -------------------------------------------
          ; FontColor := "a30404" ; (Red)
          ; FontColor := "199524" ; (Green)
          FontColor := "087417" ; (Green Dark)
          ; FontColor := "c000a0" ; (Purple)
          ; FontColor := "c6700b" ; (Yellow/Brown)
          ; -------------------------------------------
          HotKey_TextAdjustSelect("h_073", HotkeyMsg5, GuiFont, FontSize, FontColor, MaxWidth)
          ; -------------------------------------------
        } ; [End] (002_1)(UseContextMenu) == 2
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text3
      } ; [End] (060_2)(Obj_Ok_Sel [0,1,2,3]) == 3
      else if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
      {
        ; -------------------------------------------
        ; Hotkey  - Valid Keystroke
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text1
        ; HotkeyMsg2 = "This is a good Keystroke"
        ; -------------------------------------------
        ; FontColor := "a30404" ; (Red)
        ; FontColor := "199524" ; (Green)
        ; FontColor := "087417" ; (Green Dark)
        FontColor := "c000a0" ; (Purple)
        ; FontColor := "c6700b" ; (Yellow/Brown)
        ; -------------------------------------------
        HotKey_TextAdjustSelect("h_070", HotkeyMsg2, GuiFont, FontSize, FontColor, MaxWidth)
        GuiControl, HotKeySelect:Hide, h_071
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text1
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text2
        ; KeyStrokeMsg
        ; -------------------------------------------
        ; FontColor := "a30404" ; (Red)
        ; FontColor := "199524" ; (Green)
        FontColor := "087417" ; (Green Dark)
        ; FontColor := "c000a0" ; (Purple)
        ; FontColor := "c6700b" ; (Yellow/Brown)
        HotKey_TextAdjustSelect("h_072", KeyStrokeMsg, GuiFont, FontSize, FontColor, MaxWidth)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text2
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text3
        if (HotkeyDataArray.2.1 == 1) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        {
          ; -------------------------------------------
          ; HotkeyMsg6 = "Right Click Menu (Not Selected)"
          ; -------------------------------------------
          ; FontColor := "a30404" ; (Red)
          ; FontColor := "199524" ; (Green)
          ; FontColor := "087417" ; (Green Dark)
          ; FontColor := "c000a0" ; (Purple)
          FontColor := "c6700b" ; (Yellow/Brown)
          ; -------------------------------------------
          HotKey_TextAdjustSelect("h_073", HotkeyMsg6, GuiFont, FontSize, FontColor, MaxWidth)
          ; -------------------------------------------
        } ; [End] (002_1)(UseContextMenu) == 1
        else if (HotkeyDataArray.2.1 == 2) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        {
          ; -------------------------------------------
          ; HotkeyMsg5 = "Right Click Menu (Selected)"
          ; -------------------------------------------
          ; FontColor := "a30404" ; (Red)
          ; FontColor := "199524" ; (Green)
          FontColor := "087417" ; (Green Dark)
          ; FontColor := "c000a0" ; (Purple)
          ; FontColor := "c6700b" ; (Yellow/Brown)
          ; -------------------------------------------
          HotKey_TextAdjustSelect("h_073", HotkeyMsg5, GuiFont, FontSize, FontColor, MaxWidth)
          ; -------------------------------------------
        } ; [End] (002_1)(UseContextMenu) == 2
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Text3
      } ; [End] (060_2)(Obj_Ok_Sel [0,1,2,3]) == 1
    } ; [End] (001_1)(UserHotkey) != "" or (002_1)(UseContextMenu) != 2
    ; -------------------------------------------
    if (HotkeyDataArray.1.1 == "") ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    {
      ; -------------------------------------------
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Blank No Keystroke
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      HotkeyDataArray.72.3 := "" ; (072_3)(Obj_Key_AppOnly_Img [Image Path])
      ; -------------------------------------------
      GuiControl, HotKeySelect:Hide, h_072
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; End [SET] Display Text
  ; -------------------------------------------
  return HotkeyDataArray
  ; -------------------------------------------
} ; [End] HotKey_Validate(HotkeyDataArray) ; > HotkeyDataArray
; -------------------------------------------
HotKey_TextDisplay(HotkeyDataArray)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
  UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
  KeyStrokeMsg := ""
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "de")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Dies ist ein guter Keystroke" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Dieser Tastendruck ist nicht gut" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Empfohlen) Wählen Sie einen Tastenanschlag" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Rechtsklickmenü (Ausgewählte)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Rechtsklickmenü (nicht ausgewählt)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Muss einen Tastendruck wählen" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "oder das Rechtsklickmenü auswählen" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Windows Schlüssel"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Linker Windows Schlüssel"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Rechter Windows Schlüssel"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Strg"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Umsch"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Linke Maustaste"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Rechte Maus-Taste"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Mittlere Maus-Taste"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Maus-Rad nach oben"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Mausrad nach unten"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Maus X1 Taste"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Maus X2 Taste"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Linke Maustaste"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rechte Maus-Taste"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mittlere Maus-Taste"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus-Rad nach oben"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mausrad nach unten"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X1 Taste"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X2 Taste"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Linke Maustaste"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rechte Maus-Taste"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mittlere Maus-Taste"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus-Rad nach oben"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mausrad nach unten"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X1 Taste"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X2 Taste"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Strg"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Umsch"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Linke Maustaste"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rechte Maus-Taste"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mittlere Maus-Taste"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus-Rad nach oben"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mausrad nach unten"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X1 Taste"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X2 Taste"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Linke Maustaste"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rechte Maus-Taste"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mittlere Maus-Taste"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus-Rad nach oben"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mausrad nach unten"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X1 Taste"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maus X2 Taste"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "de")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "en")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "This is a good Keystroke" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "This keystroke is not good" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Recommended) Choose a Keystroke" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Right Click Menu (Selected)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Right Click Menu (Not Selected)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Must Choose a Keystroke" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "or Select Right Click Menu" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Windows Key"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Left Windows Key"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Right Windows Key"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Shift"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Left Mouse Button"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Right Mouse Button"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Middle Mouse Button"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Mouse Wheel Up"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Mouse Wheel Down"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Mouse X1 Button"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Mouse X2 Button"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Left Mouse Button"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Right Mouse Button"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Middle Mouse Button"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Up"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Down"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X1 Button"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X2 Button"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Left Mouse Button"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Right Mouse Button"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Middle Mouse Button"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Up"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Down"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X1 Button"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X2 Button"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Left Mouse Button"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Right Mouse Button"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Middle Mouse Button"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Up"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Down"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X1 Button"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X2 Button"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Left Mouse Button"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Right Mouse Button"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Middle Mouse Button"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Up"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse Wheel Down"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X1 Button"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mouse X2 Button"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "en")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "es")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Esta es una buena pulsación de teclas" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Esta pulsación de tecla no es buena" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Recomendado) Elija una pulsación de tecla" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menú del botón derecho (Seleccionado)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menú del botón derecho (No seleccionado)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Debe elegir una pulsación de tecla" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "o seleccionar el menú del botón derecho" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Clave Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Tecla de Windows izquierda"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Tecla de Windows derecha"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Mayús"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Botón izquierdo del ratón"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Botón derecho del ratón"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Botón central del ratón"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Rueda del ratón hacia arriba"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Rueda del ratón hacia abajo"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Botón Mouse X1"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Botón Mouse X2"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón izquierdo del ratón"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón derecho del ratón"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón central del ratón"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia arriba"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia abajo"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X1"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X2"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón izquierdo del ratón"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón derecho del ratón"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón central del ratón"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia arriba"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia abajo"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X1"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X2"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mayús"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón izquierdo del ratón"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón derecho del ratón"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón central del ratón"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia arriba"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia abajo"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X1"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X2"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón izquierdo del ratón"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón derecho del ratón"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón central del ratón"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia arriba"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rueda del ratón hacia abajo"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X1"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botón Mouse X2"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "es")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "fr")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "C’est une bonne frappe au clavier" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Cette frappe n'est pas bonne" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Recommandé) Choisissez une frappe" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menu clic droit (Sélectionné)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menu clic droit (Non sélectionné)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Il faut choisir une combinaison de touches" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "ou sélectionner le menu du clic droit" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Clé Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Touche Windows gauche"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Touche Windows droite"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Maj"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Bouton souris gauche"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Bouton Droit De La Souris"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Bouton Milieu De La Souris"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Roue de souris vers le haut"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Roue de souris vers le bas"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Souris X1 Bouton"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Souris X2 Bouton"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton souris gauche"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Droit De La Souris"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Milieu De La Souris"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le haut"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le bas"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X1 Bouton"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X2 Bouton"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton souris gauche"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Droit De La Souris"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Milieu De La Souris"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le haut"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le bas"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X1 Bouton"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X2 Bouton"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maj"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton souris gauche"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Droit De La Souris"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Milieu De La Souris"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le haut"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le bas"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X1 Bouton"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X2 Bouton"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton souris gauche"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Droit De La Souris"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Bouton Milieu De La Souris"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le haut"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roue de souris vers le bas"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X1 Bouton"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Souris X2 Bouton"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "fr")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "it")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Questa è una buona sequenza di tasti" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "(Consigliato) Scegli una sequenza di tasti" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Recommended) Choose a Keystroke" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menu del clic destro (Selezionato)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menu del clic destro (Non selezionato)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Deve scegliere una sequenza di tasti" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "o selezionare il menu di scelta rapida" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Chiave Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Tasto Windows sinistro"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Tasto Windows Destro"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Maiusc"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Pulsante sinistro del mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Pulsante destro del mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Pulsante centrale del mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Rotellina del mouse verso l'alto"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Rotellina del mouse verso il basso"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Pulsante Mouse X1"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Pulsante Mouse X2"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante sinistro del mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante destro del mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante centrale del mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso l'alto"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso il basso"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X1"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X2"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante sinistro del mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante destro del mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante centrale del mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso l'alto"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso il basso"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X1"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X2"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Maiusc"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante sinistro del mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante destro del mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante centrale del mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso l'alto"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso il basso"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X1"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X2"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante sinistro del mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante destro del mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante centrale del mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso l'alto"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Rotellina del mouse verso il basso"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X1"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Pulsante Mouse X2"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "it")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "pl")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "To dobry klawisz" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "To naciśnięcie klawisza nie jest dobre" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Zalecane) Wybierz klawisz" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menu prawego przycisku myszy (Wybrane)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menu prawego przycisku myszy (Nie wybrano)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Musisz wybrać przycisk klawiszowy" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "lub wybrać prawy przycisk" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Klucz Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Lewy klawisz Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Prawy Klawisz Windows"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Shift"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Lewy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Prawy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Srodkowy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Kólko myszy w góre"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Kólko myszy w dól"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Przycisk Myszy X1"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Przycisk Myszy X2"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Lewy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Prawy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Srodkowy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w góre"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w dól"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X1"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X2"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Lewy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Prawy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Srodkowy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w góre"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w dól"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X1"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X2"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Lewy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Prawy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Srodkowy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w góre"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w dól"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X1"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X2"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Lewy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Prawy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Srodkowy Przycisk Myszy"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w góre"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kólko myszy w dól"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X1"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Przycisk Myszy X2"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "pl")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "pt")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Este é um bom pressionamento de tecla" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Este toque de tecla não é bom" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Recomendado) Escolha um Keystroke" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menu com o botão direito do rato (Seleccionado)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menu com o botão direito do rato (Não Seleccionado)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Deve Escolher um Keystroke" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "ou Seleccionar o Menu com o botão direito" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Chave Do Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Chave Esquerda Do Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Chave Direita Do Windows"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Shift"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Botão esquerdo do mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Botão direito do mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Botão do meio do mouse"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Roda do mouse para cima"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Roda do mouse para baixo"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Botão Mouse X1"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Botão Mouse X2"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão esquerdo do mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão direito do mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão do meio do mouse"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para cima"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para baixo"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X1"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X2"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão esquerdo do mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão direito do mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão do meio do mouse"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para cima"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para baixo"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X1"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X2"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão esquerdo do mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão direito do mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão do meio do mouse"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para cima"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para baixo"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X1"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X2"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão esquerdo do mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão direito do mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão do meio do mouse"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para cima"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Roda do mouse para baixo"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X1"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Botão Mouse X2"
        }
        ; -------------------------------------------
        HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "pt")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "ru")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Это хорошее нажатие клавиши" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Это нажатие клавиши нехорошо" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Рекомендуется) Выбор нажатия клавиши" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Меню правой кнопки мыши (Выбранный)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Меню правой кнопки мыши (Не выбран)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Должен выбрать нажатие клавиши" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "или выбрать меню правой кнопки мыши" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Ключ Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Левая клавиша Windows"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Правая клавиша Windows"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Shift"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Левая кнопка мыши"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Правая кнопка мыши"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Средняя кнопка мыши"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Колесо мыши вверх"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Колесо мыши вниз"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Кнопка мыши X1"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Кнопка мыши X2"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Левая кнопка мыши"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Правая кнопка мыши"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Средняя кнопка мыши"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вверх"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вниз"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X1"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X2"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Левая кнопка мыши"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Правая кнопка мыши"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Средняя кнопка мыши"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вверх"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вниз"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X1"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X2"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Shift"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Левая кнопка мыши"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Правая кнопка мыши"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Средняя кнопка мыши"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вверх"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вниз"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X1"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X2"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Левая кнопка мыши"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Правая кнопка мыши"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Средняя кнопка мыши"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вверх"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Колесо мыши вниз"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X1"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Кнопка мыши X2"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "ru")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "sv")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Detta är en bra tangenttryckning" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Det här tangentdraget är inte bra" ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Rekommenderas) Välj en tangenttryckning" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Menyn Höger klick (Vald)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Menyn Höger klick (Ej valt)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Måste välja en tangentstroke" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "eller välja meny med högerklick" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Windows-tangenten"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Vänster Windows-tangent"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Höger Windows-tangent"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Ctrl"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Alt"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Skift"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Vänster musknapp"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Höger musknapp"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Mitten musknapp"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Mushjulet uppåt"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Mushjulet nedåt"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Mus X1-knapp"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Mus X2-knapp"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Vänster musknapp"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Höger musknapp"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mitten musknapp"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet uppåt"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet nedåt"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X1-knapp"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X2-knapp"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Vänster musknapp"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Höger musknapp"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mitten musknapp"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet uppåt"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet nedåt"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X1-knapp"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X2-knapp"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Ctrl"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Alt"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Skift"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Vänster musknapp"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Höger musknapp"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mitten musknapp"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet uppåt"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet nedåt"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X1-knapp"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X2-knapp"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Vänster musknapp"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Höger musknapp"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mitten musknapp"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet uppåt"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mushjulet nedåt"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X1-knapp"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Mus X2-knapp"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------    
  } ; [End] if (UserLang == "sv")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (UserLang == "tr")
  {
    ; -------------------------------------------
    HotkeyDataArray.23.1 := "Bu iyi bir tuş vuruşu" ; (023_1)(Obj_Key_F2)
    HotkeyDataArray.24.1 := "Bu tuş vuruşu iyi değil." ; (024_1)(Obj_Key_F3)
    HotkeyDataArray.25.1 := "(Önerilen) Tuş Vuruşu Seçin" ; (025_1)(Obj_Key_F4)
    HotkeyDataArray.26.1 := "Sağ tıklayın menüsü (Seçilmiş)" ; (026_1)(Obj_Key_F5)
    HotkeyDataArray.27.1 := "Right Click Menu (Seçili değil)" ; (027_1)(Obj_Key_F6)
    HotkeyDataArray.28.1 := "Bir tuş vuruşu seçmeli" ; (028_1)(Obj_Key_F7)
    HotkeyDataArray.29.1 := "veya sağ tıklatmayı seçmeli" ; (029_1)(Obj_Key_F8)
    ; -------------------------------------------
    if (UserHotkey != "")
    {
      ; -------------------------------------------
      { ; First
        ; -------------------------------------------
        if (SubStr(UserHotkey, 1, 1) == "#")
        {
          KeyStrokeMsg := "Windows Tuşu"
        }
        if (SubStr(UserHotkey, 1, 4) == "LWin")
        {
          KeyStrokeMsg := "Sol Windows Tuşu"
        }
        if (SubStr(UserHotkey, 1, 4) == "RWin")
        {
          KeyStrokeMsg := "Sağ Windows Tuşu"
        }
        if (SubStr(UserHotkey, 1, 1) == "^")
        {
          KeyStrokeMsg := "Kontrol"
        }
        if (SubStr(UserHotkey, 1, 1) == "!")
        {
          KeyStrokeMsg := "Sçnk"
        }
        if (SubStr(UserHotkey, 1, 1) == "+")
        {
          KeyStrokeMsg := "Üst"
        }
        if (SubStr(UserHotkey, 1, 7) == "LButton")
        {
          KeyStrokeMsg := "Sol Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 1, 7) == "RButton")
        {
          KeyStrokeMsg := "Sağ Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 1, 7) == "MButton")
        {
          KeyStrokeMsg := "Orta Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 1, 7) == "WheelUp")
        {
          KeyStrokeMsg := "Fare Tekerleği Yukarı"
        }
        if (SubStr(UserHotkey, 1, 9) == "WheelDown")
        {
          KeyStrokeMsg := "Fare Tekerleği Aşağı"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton1")
        {
          KeyStrokeMsg := "Fare X1 Düğmesi"
        }
        if (SubStr(UserHotkey, 1, 8) == "XButton2")
        {
          KeyStrokeMsg := "Fare X2 Düğmesi"
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(UserHotkey, 2, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 2, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 2, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 2, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 2, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 2, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 2, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sol Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 2, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sağ Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 2, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Orta Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 2, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Yukarı"
        }
        if (SubStr(UserHotkey, 2, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Aşağı"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X1 Düğmesi"
        }
        if (SubStr(UserHotkey, 2, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X2 Düğmesi"
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(UserHotkey, 3, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 3, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 3, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 3, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 3, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 3, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 3, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sol Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 3, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sağ Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 3, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Orta Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 3, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Yukarı"
        }
        if (SubStr(UserHotkey, 3, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Aşağı"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X1 Düğmesi"
        }
        if (SubStr(UserHotkey, 3, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X2 Düğmesi"
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 4, 1) == "^")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 4, 1) == "!")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 4, 1) == "+")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 4, 4) == "Ctrl")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Kontrol"
        }
        if (SubStr(UserHotkey, 4, 3) == "Alt")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sçnk"
        }
        if (SubStr(UserHotkey, 4, 5) == "Shift")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Üst"
        }
        if (SubStr(UserHotkey, 4, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sol Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 4, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sağ Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 4, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Orta Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 4, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Yukarı"
        }
        if (SubStr(UserHotkey, 4, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Aşağı"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X1 Düğmesi"
        }
        if (SubStr(UserHotkey, 4, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X2 Düğmesi"
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(UserHotkey, 5, 7) == "LButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sol Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 5, 7) == "RButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Sağ Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 5, 7) == "MButton")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Orta Fare Düğmesi"
        }
        if (SubStr(UserHotkey, 5, 7) == "WheelUp")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Yukarı"
        }
        if (SubStr(UserHotkey, 5, 9) == "WheelDown")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare Tekerleği Aşağı"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton1")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X1 Düğmesi"
        }
        if (SubStr(UserHotkey, 5, 8) == "XButton2")
        {
          KeyStrokeMsg := KeyStrokeMsg " + Fare X2 Düğmesi"
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
      HotkeyDataArray.21.1 := KeyStrokeMsg ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    } ; [End] if (UserHotkey != "")
    else
    {
      ; -------------------------------------------
      HotkeyDataArray.21.1 := "" ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] if (UserLang == "tr")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return HotkeyDataArray
  ; -------------------------------------------
} ; [End] HotKey_TextDisplay(HotkeyDataArray) ; > HotkeyDataArray
; -------------------------------------------
HotKey_Cancel()
{
  ; -------------------------------------------
  Gui, HotKeySelect:Destroy
  ExitApp
  ; -------------------------------------------
} ; [End] HotKey_Cancel()
; -------------------------------------------
GuiImageControl(GuiVarNum, SelectType, HasLanguage, HotkeyDataArray) ; > HotkeyDataArray
{
  ; -------------------------------------------
  UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
  ; -------------------------------------------
  if (GuiVarNum != "" or SelectType != "" or HasLanguage != "")
  {
    ; -------------------------------------------
    DataVarNum := GuiVarNum
    ; -------------------------------------------
    if (SubStr(DataVarNum, 1, 1) == "0") ; 00# Remove 0's
    {
      DataVarNum := SubStr(DataVarNum, 2)
    }
    ; -------------------------------------------
    if (SubStr(DataVarNum, 1, 1) == "0") ; 0# Remove 0's
    {
      DataVarNum := SubStr(DataVarNum, 2)
    }
    ; -------------------------------------------
    HotkeyDataArray[DataVarNum][2] := SelectType ; [SET] HotkeyDataArray to SelectType
    ; -------------------------------------------
    if (SelectType == 0)
    {
      HotkeyDataArray[DataVarNum][3] := ""
      GuiControl, HotKeySelect:Hide, h_%GuiVarNum%
    }
    ; -------------------------------------------
    else if (SelectType == 1 or SelectType == 2 or SelectType == 3)
    {
      ; -------------------------------------------
      UserLang := HotkeyDataArray.004.1 ; (004_1)(Obj_ok)
      ; -------------------------------------------
      if (HasLanguage == 0)
      {
        ; -------------------------------------------
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(" GuiVarNum ")_" SelectType ".png"
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (HasLanguage == 1)
      {
        ; -------------------------------------------
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\hotkey\(" GuiVarNum ")_" SelectType "_" UserLang ".png"
        ; -------------------------------------------
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      CurrentImage := HotkeyDataArray[DataVarNum][3]
      ; -------------------------------------------
      if (CurrentImage == "")
      {
        ChangeImage := 1
      }
      ; -------------------------------------------
      else if (CurrentImage != ThisImage)
      {
        ChangeImage := 1
      }
      ; -------------------------------------------
      if FileExist(ThisImage)
      {
        if (ChangeImage == 1)
        {
          HotkeyDataArray[DataVarNum][3] := ThisImage
          GuiControl, HotKeySelect:, h_%GuiVarNum%, %ThisImage%
          ; -------------------------------------------
          GuiHotkey_ObjectSize(GuiVarNum) ; > Nothing
          ; -------------------------------------------
        }
      }
      ; -------------------------------------------
      GuiControl, HotKeySelect:Show, h_%GuiVarNum%
      ; -------------------------------------------
    } ; End (SelectType == 1 or SelectType == 2 or SelectType == 3)
    ; -------------------------------------------
  } ; End (VarNum != "" or SelectType != "" or HasLanguage != "")
  ; -------------------------------------------
  return HotkeyDataArray
  ; -------------------------------------------
} ; [End] GuiImageControl(GuiVarNum, SelectType, HasLanguage, HotkeyDataArray) ; > HotkeyDataArray
; -------------------------------------------
HotKey_Ok(HotkeyDataArray) ; > ExitApp
{
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    Script_Close(ScriptPath)
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (HotkeyDataArray.60.2 == 1) ; (060_2)(Obj_Key_WinRight_Sel [0,1,2,3])
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [UPDATE] File_UserLang.txt
    ; -------------------------------------------
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysLoad.ahk"
    ; -------------------------------------------
    if (Script_Running(ScriptPath) == 0) ; (NOT Running)
    {
      ; -------------------------------------------
      UserLang := HotkeyDataArray.4.1 ; (004_1)(Obj_ok)
      ; -------------------------------------------
      File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
      if FileExist(File_UserLang)
      {
        FileDelete, %File_UserLang%
      }
      ; -------------------------------------------
      FileEncoding, UTF-8
      FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8 
      Sleep, 100
      ; -------------------------------------------
    } ; [End] if (Script_Running(ScriptPath) == 0)
    ; -------------------------------------------
    ; [UPDATE] File_UserLang.txt
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; PopUpMenu Windows Startup
    ; -------------------------------------------
    StartLoad := HotkeyDataArray.40.2 ; (040_2)(Obj_Key_Numpad6_Sel [0,1,2,3])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (A_StartMenuCommon) C:\ProgramData\Microsoft\Windows\Start Menu
    ; (All Users) [StartMenu] [FOLDER] [SET Icon]
    ; -------------------------------------------
    StartMenuCommonFolderIcon   := A_StartMenuCommon "\Programs\PopUpMenu\(FolderIco).ico"
    StartMenuCommonFolderIni    := A_StartMenuCommon "\Programs\PopUpMenu\desktop.ini"
    StartMenuCommonFolder       := A_StartMenuCommon "\Programs\PopUpMenu"
    Default_StartMenuFolderIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\startmenu_folder.ico"
    ; -------------------------------------------
    if (!FileExist(StartMenuCommonFolderIcon) or !FileExist(StartMenuCommonFolderIni))
    {
      ; -------------------------------------------
      if !FileExist(StartMenuCommonFolder)
      {
        FileCreateDir, %StartMenuCommonFolder%
        Sleep, 10
      } ; [End] if !FileExist(StartMenuCommonFolder)
      ; -------------------------------------------
      FileDelete, %StartMenuCommonFolderIcon%
      FileDelete, %StartMenuCommonFolderIni%
      Sleep, 10
      ; -------------------------------------------
      FileCopy, %Default_StartMenuFolderIcon%, %StartMenuCommonFolderIcon%, 1
      Sleep, 10
      Folder_SetIcon(StartMenuCommonFolder, StartMenuCommonFolderIcon, 0)
      ; -------------------------------------------
    } ; [End] if (!FileExist(StartMenuCommonFolderIcon) or !FileExist(StartMenuCommonFolderIni))
    ; -------------------------------------------
    ; (All Users) [StartMenu] [FOLDER] [SET Icon]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; 
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (A_StartMenuCommon) C:\ProgramData\Microsoft\Windows\Start Menu
    ; (All Users) [StartMenu] [LINK]
    ; -------------------------------------------
    StartMenuCommonPopUpMenuLink := A_StartMenuCommon "\Programs\PopUpMenu\PopUpMenu.lnk"
    StartMenuCommonUninstallLink := A_StartMenuCommon "\Programs\PopUpMenu\Uninstall.lnk"
    ; -------------------------------------------
    if (!FileExist(StartMenuCommonPopUpMenuLink) or !FileExist(StartMenuCommonUninstallLink))
    {
      ; -------------------------------------------
      FileDelete, %StartMenuCommonPopUpMenuLink%
      FileDelete, %StartMenuCommonUninstallLink%
      ; -------------------------------------------
      if (UserLang == "de") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Je mehr Sie es benutzen, desto mehr lieben Sie es"
        UninstallDesc := "Deinstallieren Sie Popupmenu"
      }
      else if (UserLang == "en") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "The more you use it, the more you love it"
        UninstallDesc := "Uninstall PopUpMenu"
      }
      else if (UserLang == "es") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Cuanto más lo usas, más te gusta"
        UninstallDesc := "Desinstalar PopUpMenu"
      }
      else if (UserLang == "fr") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Plus vous l'utilisez, plus vous l'aimez"
        UninstallDesc := "Désinstallez PopUpMenu"
      }
      else if (UserLang == "it") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Più lo si usa, più lo si ama"
        UninstallDesc := "Disinstallare PopUpMenu"
      }
      else if (UserLang == "pl") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Im częściej go używasz, tym bardziej go kochasz"
        UninstallDesc := "Odinstaluj PopUpMenu"
      }
      else if (UserLang == "pt") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Quanto mais se usa, mais se adora"
        UninstallDesc := "Desinstalar PopUpMenu"
      }
      else if (UserLang == "ru") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Чем больше вы им пользуетесь, тем больше он вам нравится"
        UninstallDesc := "Удалите PopUpMenu"
      }
      else if (UserLang == "sv") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Ju mer du använder den, desto mer älskar du den"
        UninstallDesc := "Avinstallera PopUpMenu"
      }
      else if (UserLang == "tr") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
      {
        LinkD_PopUpMenu := "Ne kadar çok kullanırsanız, o kadar çok seversiniz"
        UninstallDesc := "PopUpMenu'yu kaldir"
      }
      else
      {
        LinkD_PopUpMenu := "The more you use it, the more you love it"
        UninstallDesc := "Uninstall PopUpMenu"
      }
      ; -------------------------------------------
      LinkT_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\PopUpMenu.ahk"
      LinkI_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\image\ico\PopUpMenu.ico"
      ; -------------------------------------------
      FileCreateShortcut, %LinkT_PopUpMenu%, %StartMenuCommonPopUpMenuLink%, , , %LinkD_PopUpMenu%, %LinkI_PopUpMenu%
      ; -------------------------------------------
      UninstallTarget := "C:\Program Files\PopUpMenu_PUM\uninstall.ahk"
      UninstallIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\uninstall.ico"
      ; -------------------------------------------
      FileCreateShortcut, %UninstallTarget%, %StartMenuCommonUninstallLink%, , , %UninstallDesc%, %UninstallIcon%
      ; -------------------------------------------
    } ; [End] if (!FileExist(StartMenuCommonPopUpMenuLink) or !FileExist(StartMenuCommonUninstallLink))
    ; -------------------------------------------
    ; (All Users) [StartMenu] [LINK]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (A_StartMenu) C:\Users\<UserName>\AppData\Roaming\Microsoft\Windows\Start Menu
    ; (Current User) [StartMenu] [FOLDER] [SET Icon]
    ; -------------------------------------------
    StartMenuFolderIcon         := A_StartMenu "\Programs\PopUpMenu\(FolderIco).ico"
    StartMenuFolderIni          := A_StartMenu "\Programs\PopUpMenu\desktop.ini"
    StartMenuFolder             := A_StartMenu "\Programs\PopUpMenu"
    ; -------------------------------------------
    if (!FileExist(StartMenuFolderIcon) or !FileExist(StartMenuFolderIni))
    {
      ; -------------------------------------------
      if !FileExist(StartMenuFolder)
      {
        FileCreateDir, %StartMenuFolder%
        Sleep, 10
      } ; [End] if !FileExist(StartMenuCommonFolder)
      ; -------------------------------------------
      FileDelete, %StartMenuFolderIcon%
      FileDelete, %StartMenuFolderIni%
      Sleep, 10
      ; -------------------------------------------
      FileCopy, %Default_StartMenuFolderIcon%, %StartMenuFolderIcon%, 1
      Sleep, 10
      Folder_SetIcon(StartMenuFolder, StartMenuFolderIcon, 0)
      ; -------------------------------------------
    } ; [End] if (!FileExist(StartMenuFolderIcon) or !FileExist(StartMenuFolderIni))
    ; -------------------------------------------
    ; (Current User) [StartMenu] [FOLDER] [SET Icon]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Current User) [StartMenu] [LINK]
    ; -------------------------------------------
    StartMenuPopUpMenuLink   := A_StartMenu "\Programs\PopUpMenu\PopUpMenu.lnk"
    StartMenuUninstallLink   := A_StartMenu "\Programs\PopUpMenu\Uninstall.lnk"
    ; -------------------------------------------
    if !FileExist(StartMenuPopUpMenuLink)
    {
      ; -------------------------------------------
      FileCopy, %StartMenuCommonPopUpMenuLink%, %StartMenuFolder%, 1
      ; -------------------------------------------
      if (A_IsAdmin == 1)
      {
        if !FileExist(StartMenuUninstallLink)
        {
          FileCopy, %StartMenuCommonUninstallLink%, %StartMenuFolder%, 1
        }
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; (Current User) [StartMenu] [LINK]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Current User) [StartUp] Start PopUpMenu at Login
    ; -------------------------------------------
    if (A_IsAdmin == 1)
    {
      StartupPopUpMenuScript := "C:\Program Files\PopUpMenu_PUM\PopUpMenuStartUp.ahk"
      CheckFile := A_Startup "\PopUpMenuStartUp.ahk"
      if !FileExist(CheckFile)
      {
        FileCopy, %StartupPopUpMenuScript%, %A_Startup%
      }
    }
    ; -------------------------------------------
    PopUpMenuStartUp := A_AppData "\PopUpMenu_PUM\system\PopUpMenuStartUp.txt"
    ; -------------------------------------------
    FileReadLine, CheckStartLoad, %PopUpMenuStartUp%, 1 ; FileReadLine, OutputVar, Filename, LineNum
    if (CheckStartLoad != StartLoad) ; Load at Startup Has Changed
    {
      ; -------------------------------------------
      FileDelete, %PopUpMenuStartUp%
      Sleep, 10
      FileEncoding, UTF-8
      FileAppend, %StartLoad%, %PopUpMenuStartUp%
      Sleep, 100
      ; -------------------------------------------
    } ; [End] if (CheckStartLoad != StartLoad) ; Load at Startup Has Changed
    ; -------------------------------------------
    if (StartLoad == 1) ; DO NOT Load PopUpMenu at Windows Startup
    {
      ; -------------------------------------------
      CheckLink := A_Desktop "\PopUpMenu.lnk"
      if !FileExist(CheckLink) ; No Desktop PopUpMenu.lnk
      {
        ; -------------------------------------------
        if (UserLang == "de") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Je mehr Sie es benutzen, desto mehr lieben Sie es"
        }
        else if (UserLang == "en") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "The more you use it, the more you love it"
        }
        else if (UserLang == "es") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Cuanto más lo usas, más te gusta"
        }
        else if (UserLang == "fr") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Plus vous l'utilisez, plus vous l'aimez"
        }
        else if (UserLang == "it") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Più lo si usa, più lo si ama"
        }
        else if (UserLang == "pl") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Im częściej go używasz, tym bardziej go kochasz"
        }
        else if (UserLang == "pt") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Quanto mais se usa, mais se adora"
        }
        else if (UserLang == "ru") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Чем больше вы им пользуетесь, тем больше он вам нравится"
        }
        else if (UserLang == "sv") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Ju mer du använder den, desto mer älskar du den"
        }
        else if (UserLang == "tr") ; Link Description (LinkD_PopUpMenu) (UninstallDesc)
        {
          LinkD_PopUpMenu := "Ne kadar çok kullanırsanız, o kadar çok seversiniz"
        }
        else
        {
          LinkD_PopUpMenu := "The more you use it, the more you love it"
        }
        ; -------------------------------------------
        LinkT_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\PopUpMenu.ahk"
        LinkI_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\image\ico\PopUpMenu.ico"
        LinkS_PopUpMenu := A_Desktop "\PopUpMenu.lnk"
        ; -------------------------------------------
        FileCreateShortcut, %LinkT_PopUpMenu%, %LinkS_PopUpMenu%, , , %LinkD_PopUpMenu%, %LinkI_PopUpMenu%
        ; -------------------------------------------
      } ; [End] if !FileExist(CheckLink) ; No Desktop PopUpMenu.lnk
      ; -------------------------------------------
    } ; [End] if (StartLoad == 1) ; DO NOT Load PopUpMenu at Windows Startup
    ; -------------------------------------------
    ; (Current User) [StartUp] Start PopUpMenu at Login
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Pum Launch in Context Menu
    ; -------------------------------------------
    Use_ContextMenu := HotkeyDataArray.2.1 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
    File_ContextMenu := A_AppData "\PopUpMenu_PUM\system\ContextMenu.txt"
    FileDelete, %File_ContextMenu%
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %Use_ContextMenu%, %File_ContextMenu%
    Sleep, 100
    ; -------------------------------------------
    ; Pum Launch in Context Menu
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Pum Launch Hotkey
    ; -------------------------------------------
    UserHotkey := HotkeyDataArray.1.1 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    ; -------------------------------------------
    if (UserHotkey == "#^")
    {
      UserHotkey := "#Ctrl"
    }
    ; -------------------------------------------
    else if (UserHotkey == "#+")
    {
      UserHotkey := "#Shift"
    }
    ; -------------------------------------------
    else if (UserHotkey == "#!")
    {
      UserHotkey := "#Alt"
    }
    ; -------------------------------------------
    File_UserHotkey := A_AppData "\PopUpMenu_PUM\system\File_UserHotkey.txt"
    ; -------------------------------------------
    if FileExist(File_UserHotkey)
    {
      FileDelete, %File_UserHotkey%
    }
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %UserHotkey%, %File_UserHotkey% ; UTF-8
    Sleep, 100
    ; -------------------------------------------
    ; Pum Launch Hotkey
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
    ScriptRunning := Script_Running(ScriptPath)
    if (ScriptRunning > 0)
    {
      Script_Close(ScriptPath)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Close Hotkey Gui and run (PopUpMenu_Start)
    ; -------------------------------------------
    Gui, HotKeySelect:Destroy
    ; -------------------------------------------
    Run, C:\Program Files\PopUpMenu_PUM\SysLoad.ahk
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
    ; Close Hotkey Gui and run (PopUpMenu_Start)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
} ; [End] HotKey_Ok(HotkeyDataArray) ; > ExitApp
; -------------------------------------------
HotKey_CheckSelected(SubArray, HoykeyDataArray) ; > IsSelected
{
  ; -------------------------------------------
  ; (042_1)(Obj_MouseLeft)
  ; (043_1)(Obj_MouseRight)
  ; (044_1)(Obj_MouseMiddle)
  ; (045_1)(Obj_MouseWheelUp)
  ; (046_1)(Obj_MouseWheelDown)
  ; (047_1)(Obj_MouseX1)
  ; (048_1)(Obj_MouseX2)
  ; (049_1)(Obj_WinLeft)
  ; (050_1)(Obj_WinRight)
  ; (051_1)(Obj_Ctrl)
  ; (052_1)(Obj_Alt)
  ; (053_1)(Obj_Shift)
  ; -------------------------------------------
  VarNumArray := [042, 043, 044, 045, 046, 047, 048, 049, 050, 051, 052, 053]
  SubArrayLen := SubArray.MaxIndex()
  for Index, CheckKey in VarNumArray
  {
    Num := 0
    AddToArray := 1
    Loop %SubArrayLen%
    {
      Num := Num + 1
      if (CheckKey == SubArray[Num])
      {
        AddToArray := 0
      }
    }
    if (AddToArray == 1)
    {
      VarArray := Array_Add(VarArray, CheckKey, "End")
    }
  }
  ; -------------------------------------------
  IsSelected := 0
  ; -------------------------------------------
  for Index, VarNum in VarArray
  {
    SelectType := HoykeyDataArray[VarNum][2]
    if (SelectType == 2 or SelectType == 3)
    {
      IsSelected := 1
      break
    } ; End (SelectType == 2 or SelectType == 3)
  }
  ; -------------------------------------------
  return IsSelected
  ; -------------------------------------------
} ; [End] HotKey_CheckSelected(SubArray, HoykeyDataArray) ; > IsSelected
; -------------------------------------------
GuiHotkey_ObjectSize(ThisGuiVar) ; > Nothing
{
  if (ThisGuiVar == "Header")
  {
    MoveHD_W := 350
    MoveHD_H := 97
  }
  else if (ThisGuiVar == "LangFlag")
  {
    MoveHD_W := 94
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "040")
  {
    MoveHD_W := 100
    MoveHD_H := 130
  }
  else if (ThisGuiVar == "041")
  {
    MoveHD_W := 180
    MoveHD_H := 130
  }
  else if (ThisGuiVar == "042")
  {
    MoveHD_W := 41
    MoveHD_H := 92
  }
  else if (ThisGuiVar == "043")
  {
    MoveHD_W := 41
    MoveHD_H := 92
  }
  else if (ThisGuiVar == "044")
  {
    MoveHD_W := 24
    MoveHD_H := 43
  }
  else if (ThisGuiVar == "045")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "046")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "047")
  {
    MoveHD_W := 43
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "048")
  {
    MoveHD_W := 43
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "049")
  {
    MoveHD_W := 56
    MoveHD_H := 56
  }
  else if (ThisGuiVar == "050")
  {
    MoveHD_W := 56
    MoveHD_H := 56
  }
  else if (ThisGuiVar == "051")
  {
    MoveHD_W := 56
    MoveHD_H := 56
  }
  else if (ThisGuiVar == "052")
  {
    MoveHD_W := 56
    MoveHD_H := 56
  }
  else if (ThisGuiVar == "053")
  {
    MoveHD_W := 111
    MoveHD_H := 56
  }
  else if (ThisGuiVar == "060")
  {
    MoveHD_W := 100
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "061")
  {
    MoveHD_W := 100
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "062")
  {
    MoveHD_W := 480
    MoveHD_H := 20
  }
  ; -------------------------------------------
  if (MoveHD_W != "" && MoveHD_H != "")
  {
    GuiControl, HotKeySelect:Move, g_%ThisGuiVar%, w%MoveHD_W% h%MoveHD_H%
  }
  ; -------------------------------------------
} ; [End] GuiHotkey_ObjectSize(ThisGuiVar) ; > Nothing
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
~Esc::
{
  ; -------------------------------------------
  Run, C:\Program Files\PopUpMenu_PUM\Script_SplashClose.ahk
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    Script_Close(ScriptPath)
  }
  ; -------------------------------------------
} ; [End] ~Esc::
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Alt & Tab:: ; Disable Alt Tab
{
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
