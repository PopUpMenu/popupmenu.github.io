﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HideWindow(Window)
{
  SetTitleMatchMode, 2
  WinActivate, %Window%
  WinWait %Window%
  DetectHiddenWindows On
  WinHide
  WinSet, ExStyle, +0x80 ; 0x80 is WS_EX_TOOLWINDOW
  WinShow
} ; [End] HideWindow(Window)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
