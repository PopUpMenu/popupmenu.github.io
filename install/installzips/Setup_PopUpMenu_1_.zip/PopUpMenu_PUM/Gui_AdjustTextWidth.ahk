﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_TextWidth.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Gui_AdjustTextWidth(VarName, VarValue, GuiFont, FontSize, FontColor, MaxWidth)
{
  /* Info
  ; -------------------------------------------
  ; Does Not GuiControl, PopUpMenu:Show,
  ; -------------------------------------------
  ; (MaxWidth == 480)
  ; (105)_(---)(Decriptive Top Text 2)_(2)Select_(3)Value
  ; (107)_(---)(Decriptive Bottom Text 2)_(2)Select_(3)Value
  ; (113)_(rwh)(url)(Decriptive Opening Application Text)_(2)Select_(3)Value
  ; "0123456789012345678901234567890123456789012" ; Max 14
  ; > 473 Change to 12 "12345678901234567890123456789012345678901234567890123" ; Max 12
  ; > 475 Change to 10 "12345678901234567890123456789012345678901234567890123456789012345678" ; Max 10
  ; > 377 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; (MaxWidth == 275)
  ; (114)_(---)(Decriptive Title Text 1)_(2)Select_(3)Value
  ; (115)_(---)(Decriptive Title Text 2)_(2)Select_(3)Value
  ; "1234567890123456789123456" ; Max 14
  ; > 273 Change to 12 "123456789012345678901234567890" ; Max 12
  ; > 276 Change to 10 "123456789012345678901234567890123456789" ; Max 10
  ; > 216 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; (MaxWidth == 200)
  ; (141)_(---)(Decriptive Title Text 3)_(2)Select_(3)Value
  ; "123456789012345678" ; Max 14
  ; > 199 Change to 12 "1234567890123456789012" ; Max 12
  ; > 200 Change to 10 "1234567890123456789012345678" ; Max 10
  ; > 160 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; (MaxWidth == 173)
  ; > 173 Change to 12 "1234567890123456789" ; Max 12
  ; > 167 Change to 10 "1234567890123456789012345" ; Max 10
  ; > 139 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; (MaxWidth == 158)
  ; (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value
  ; (111)_(mnu)(cpl)(Center List Text)_(2)Select_(3)Value
  ; (112)_(mnu)(cpl)(Right List Text)_(2)Select_(3)Value
  ; > 147 Change to 12 "12345678901234567" ; Max 12
  ; > 153 Change to 10 "1234567890123456789012" ; Max 10
  ; > 130 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; (MaxWidth == 40)
  ; ; (106)_(run)(rwh)(Extra App Icons)_(2)Select_(3)Image
  ; > 30 Change to 12 "1234" ; Max 12
  ; > 35 Change to 10 "12345" ; Max 10
  ; > 34 Change to 8
  ; -------------------------------------------
  ; -------------------------------------------
  ; Nothing Returned
  ; -------------------------------------------
  */
  ; -------------------------------------------
  /*
  Gui_AdjustTextWidth("g_100", v_100_3, v_366_2, FontSize, FontColor, MaxWidth) ; (100_3)(Obj_DisplayText_Top1_Val [Text Value])/(366_2)(GuiFont [Set in DataArray_Set])/(100_1)(Obj_DisplayText_Top1)
  GuiControlGet, OutputVar , PopUpMenu:SubCommand, ControlID, Value
  GuiControlGet, OutputVar , PopUpMenu:, ControlID
  */
  if (Old_Value != VarValue)
  {
    ; -------------------------------------------
    ThisWidth := ""
    ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
    ; -------------------------------------------
    FontChange := 0
    if (MaxWidth == 480)
    {
      if (FontSize == 14 && ThisWidth > 473)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 450)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 476)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth = 480)
    ; -------------------------------------------
    else if (MaxWidth == 275)
    {
      if (FontSize == 14 && ThisWidth > 275)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 270)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 273)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 275)
    ; -------------------------------------------
    else if (MaxWidth == 200)
    {
      ; -------------------------------------------
      if (FontSize == 14 && ThisWidth > 194)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      ; -------------------------------------------
      if (FontSize == 12 && ThisWidth > 169)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      ; -------------------------------------------
      if (FontSize == 10 && ThisWidth > 196)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    else if (MaxWidth == 173)
    {
      if (FontSize == 14 && ThisWidth > 176)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 171)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 175)
      {
        FontChange := 1
        FontSize := 8
      } ; End (FontSize == 10 && ThisWidth > 420)
    } ; End (MaxWidth == 173)
    ; -------------------------------------------
    else if (MaxWidth == 158) ; (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value
    {
      if (FontSize == 14 && ThisWidth > 154)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 153)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 154)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    else if (MaxWidth == 40) ; (106)_(run)(rwh)(Extra App Icons)_(2)Select_(3)Image
    {
      if (FontSize == 14 && ThisWidth > 33)
      {
        FontChange := 1
        FontSize := 12
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 12 && ThisWidth > 36)
      {
        FontChange := 1
        FontSize := 10
        ThisWidth := Gui_TextWidth(VarValue, GuiFont, FontSize)
      }
      if (FontSize == 10 && ThisWidth > 35)
      {
        FontChange := 1
        FontSize := 8
      }
    } ; End (MaxWidth == 158)
    ; -------------------------------------------
    GuiControl, PopUpMenu:, %VarName%, %VarValue%
    ; -------------------------------------------
    if (FontChange == 1 or FontColor)
    {
      if FontSize
      {
        Gui, PopUpMenu:Font, s%FontSize%, %GuiFont%
      } ; End if FontSize
      if FontColor
      {
        Gui, PopUpMenu:Font, c%FontColor%, %GuiFont%
      } ; End if FontColor
      else
      {
        Gui, PopUpMenu:Font, cBlack, %GuiFont%
      } ; End else
      GuiControl, PopUpMenu:+Redraw, %VarName%,
      GuiControl, PopUpMenu:Font, %VarName%
    } ; End (FontChange == 1 or FontColor)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  GuiControl, PopUpMenu:Show, %VarName%
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
