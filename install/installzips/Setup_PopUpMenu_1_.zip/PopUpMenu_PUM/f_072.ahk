﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_072(DataArray) ; (072_1)(Obj_Key_AppOnly)
{
  ; -------------------------------------------
  {
    ; -------------------------------------------
    ; 1 = Any App
    ; 2 = App Only
    ; -------------------------------------------
    if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    {
      ; -------------------------------------------
      Obj_KeyMnu_AppOnly_Sel := 2 ; (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
      ; -------------------------------------------
      DataArray.301.6 := StrReplace(DataArray.367.2, ".exe", "") ; (301_6)(keyMnu_ProcessName)/(367_2)(AppProcessExtName [Name,Ext])
      DataArray.301.9 := DataArray.367.2 ; (301_9)(KeyMnu_ProcessExtName)/(367_2)(AppProcessExtName [Name,Ext])
      DataArray.301.5 := DataArray.367.3 ; (301_5)(KeyMnu_Class)/(367_3)(AppProcessClass)
      DataArray.301.10 := DataArray.367.5 ; (301_10)(KeyMnu_ProcessPathExtName)/(367_5)(AppProcessPathNameExt [Path,Name,Ext])
      ; -------------------------------------------
    } ; (072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    else if (DataArray.72.2 == 2) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    {
      Obj_KeyMnu_AppOnly_Sel := 1 ; (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
    } ; (072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    ; -------------------------------------------
    DataArray.72.2 := Obj_KeyMnu_AppOnly_Sel ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    DataArray := Image_GuiControl("072", Obj_KeyMnu_AppOnly_Sel, 1, DataArray) ; (072_1)(Obj_Key_AppOnly)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; (072_1)(GUI Object: [key] Application Only)/(114_1)(GUI Object: <Displayed Text> Title 1)/(141_1)(GUI Object: <Displayed Text> Title 3)
  LimitedArray := [["v_072_1"], ["v_114_1"], ["v_141_1"]] ; (072_1)(Obj_Key_AppOnly)/(114_1)(Obj_DisplayText_Title1)/(141_1)(Obj_DisplayText_Title3)
  DataArray.363.9 := LimitedArray ; (363_9)(LinitDataArray [Limited DataArray])
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
