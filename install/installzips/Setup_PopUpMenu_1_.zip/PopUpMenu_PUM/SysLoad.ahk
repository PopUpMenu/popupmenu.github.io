﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\XmlBackup.ahk
#Include C:\Program Files\PopUpMenu_PUM\Email_Send.ahk
#Include C:\Program Files\PopUpMenu_PUM\File_UnZip.ahk
#Include C:\Program Files\PopUpMenu_PUM\Folder_SetIcon.ahk
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Default.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\MsgToFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyFile := "C:\Program Files\PopUpMenu_PUM\Image_Rebuild.ahk"
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
if FileExist(KeyFile)
{
  Filedelete, %KeyFile%
}
; -------------------------------------------
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Splash_Script("500", 0) ; (500_1)(Splash Anamated: PopUpMenu Loading)
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
PreventFunctionError := 1
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; User Language [GET] (UserLang)
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileReadLINE, UserLang, %File_UserLang%, 1
  }
  if (UserLang == "")
  {
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileDelete, %File_UserLang%
      Sleep, 100
    } ; [End] if FileExist(File_UserLang)
    ; -------------------------------------------
    if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
    {
      ; -------------------------------------------
      UserLang := "de"
      ; -------------------------------------------
    } ; [End] German (de)
    ; -------------------------------------------
    else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] English (en)
    ; -------------------------------------------
    else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
    {
      ; -------------------------------------------
      UserLang := "es"
      ; -------------------------------------------
    } ; [End] Spanish (es)
    ; -------------------------------------------
    else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
    {
      ; -------------------------------------------
      UserLang := "fr"
      ; -------------------------------------------
    } ; [End] French (fr)
    ; -------------------------------------------
    else if (A_Language == "0410" or A_Language == "0810")
    {
      ; -------------------------------------------
      UserLang := "it"
      ; -------------------------------------------
    } ; [End] Italian (it)
    ; -------------------------------------------
    else if (A_Language == "0415")
    {
      ; -------------------------------------------
      UserLang := "pl"
      ; -------------------------------------------
    } ; [End] Polish (pl)
    ; -------------------------------------------
    else if (A_Language == "0416" or A_Language == "0816")
    {
      ; -------------------------------------------
      UserLang := "pt"
      ; -------------------------------------------
    } ; [End] Portuguese (pt)
    ; -------------------------------------------
    else if (A_Language == "0419")
    {
      ; -------------------------------------------
      UserLang := "ru"
      ; -------------------------------------------
    } ; [End] Russian (ru)
    ; -------------------------------------------
    else if (A_Language == "041d" or A_Language == "081d")
    {
      ; -------------------------------------------
      UserLang := "sv"
      ; -------------------------------------------
    } ; [End] Swedish (sv)
    ; -------------------------------------------
    else if (A_Language == "041f")
    {
      ; -------------------------------------------
      UserLang := "tr"
      ; -------------------------------------------
    } ; [End] Turkish (tr)
    ; -------------------------------------------
    else ; English (en)
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] else ; English (en)
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
    ; -------------------------------------------
  } ; [End] if (UserLang == "")
  ; -------------------------------------------
} ; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Create Current Pum List
  ; -------------------------------------------
  PumPath := A_AppData "\PopUpMenu_PUM\pums"
  PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
  if FileExist(PumList)
  {
    FileDelete, %PumList%
  }
  Loop Files, %PumPath%\pum_*.exe, R
  {
    ; -------------------------------------------
    ThisPumPath := A_LoopFileFullPath
    SplitPath, ThisPumPath, ThisPum
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    FileAppend, %ThisPum%`n, %PumList% ; UTF-8
    ; -------------------------------------------
  }
  ; -------------------------------------------
} ; Create Current Pum List
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Copy a Backup of All Pum XML Files
  ; -------------------------------------------
  XmlBackup() ; > Nothing
  ; -------------------------------------------
} 
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [CLEAN] C:\Users\<User>\AppData\Roaming\PopUpMenu_PUM\pums\<pum Name>\pumiconcache
; -------------------------------------------
Run, C:\Program Files\PopUpMenu_PUM\PumCleanIcons.ahk
; -------------------------------------------
; [CLEAN] C:\Users\<User>\AppData\Roaming\PopUpMenu_PUM\pums\<pum Name>\pumiconcache
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Close pum Disable Scripts
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    Script_Close(ScriptPath)
    MobileOnOff := ""
    MobileTxColor := ""
    MobileTxSize := ""
  }
  ; -------------------------------------------
} ; Close pum Disable Scripts
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [FOLDER] [EXIST CHECK]
  ; -------------------------------------------
  if (A_IsAdmin == 1)
  {
    ; -------------------------------------------
    SMC_Folder        := A_StartMenuCommon "\Programs\PopUpMenu"
    if !FileExist(SMC_Folder)
    {
      FileCreateDir, %SMC_Folder%
      Sleep, 10
    }
    ; -------------------------------------------
    SplitPath, A_AppData, , , , , OutDrive
    ; -------------------------------------------
    FilePath := OutDrive "\Users\*.*"
    ; -------------------------------------------
    Loop Files, %FilePath%, D
    {
      ; -------------------------------------------
      ThisFolderPath := A_LoopFileFullPath
      SplitPath, ThisFolderPath, , , , UserName
      ; -------------------------------------------
      FO01 := OutDrive "\Users\" UserName "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\PopUpMenu"
      ; -------------------------------------------
      FO02 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Windows_)"
      FO03 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Folder_)"
      FO04 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Keyboard_)"
      FO05 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Application_)\Png"
      FO06 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Application_)\Ico"
      FO07 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Application_)\(_Item_)"
      FO08 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\(_Folder_)(_App_)"
      FO09 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Error440"
      FO10 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Error450"
      FO11 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Error460"
      FO12 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Error470"
      FO13 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\New135"
      FO14 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Del135"
      FO15 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\New254"
      FO16 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Del254"
      FO17 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Mnu134"
      FO18 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\Mnu137"
      FO19 := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)\System\RwhUrl103"
      ; -------------------------------------------
      FO20 := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\emailtemp"
      FO21 := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\pums"
      FO22 := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\system"
      FO23 := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\temp"
      FO24 := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\url_cache"
      ; -------------------------------------------
      FolderArray := [FO01, FO02, FO03, FO04, FO05, FO06, FO07, FO08, FO09, FO10, FO11, FO12, FO13, FO14, FO15, FO16, FO17, FO18, FO19, FO20, FO21, FO22, FO23, FO24]
      for index, ThisFolder in FolderArray
      {
        if !FileExist(ThisFolder)
        {
          FileCreateDir, %ThisFolder%
        }
      }
    }
  } ; [End] if (A_IsAdmin == 1)
  ; -------------------------------------------
} ; [FOLDER] [EXIST CHECK]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [CREATE SHORTCUT] (Admin User Uninstall.lnk) (A_StartMenuCommon PopUpMenu,lnk)
  ; -------------------------------------------
  LinkS_PopUpMenu := A_StartMenuCommon "\Programs\PopUpMenu\PopUpMenu.lnk"
  LinkS_Uninstall := A_StartMenu "\Programs\PopUpMenu\Uninstall.lnk"
  ; -------------------------------------------
  LinkT_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\PopUpMenu.ahk"
  LinkT_Uninstall := "C:\Program Files\PopUpMenu_PUM\uninstall.ahk"
  ; -------------------------------------------
  LinkI_Uninstall := "C:\Program Files\PopUpMenu_PUM\image\ico\uninstall.ico"
  LinkI_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\image\ico\PopUpMenu.ico"
  ; -------------------------------------------
  if (UserLang == "de") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Je mehr Sie es benutzen, desto mehr lieben Sie es"
    LinkD_Uninstall := "Deinstallieren Sie Popupmenu"
  }
  else if (UserLang == "en") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "The more you use it, the more you love it"
    LinkD_Uninstall := "Uninstall PopUpMenu"
  }
  else if (UserLang == "es") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Cuanto más lo usas, más te gusta"
    LinkD_Uninstall := "Desinstalar PopUpMenu"
  }
  else if (UserLang == "fr") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Plus vous l'utilisez, plus vous l'aimez"
    LinkD_Uninstall := "Désinstallez PopUpMenu"
  }
  else if (UserLang == "it") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Più lo si usa, più lo si ama"
    LinkD_Uninstall := "Disinstallare PopUpMenu"
  }
  else if (UserLang == "pl") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Im częściej go używasz, tym bardziej go kochasz"
    LinkD_Uninstall := "Odinstaluj PopUpMenu"
  }
  else if (UserLang == "pt") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Quanto mais se usa, mais se adora"
    LinkD_Uninstall := "Desinstalar PopUpMenu"
  }
  else if (UserLang == "ru") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Чем больше вы им пользуетесь, тем больше он вам нравится"
    LinkD_Uninstall := "Удалите PopUpMenu"
  }
  else if (UserLang == "sv") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Ju mer du använder den, desto mer älskar du den"
    LinkD_Uninstall := "Avinstallera PopUpMenu"
  }
  else if (UserLang == "tr") ; Link Description (LinkD_PopUpMenu) (LinkD_Uninstall)
  {
    LinkD_PopUpMenu := "Ne kadar çok kullanırsanız, o kadar çok seversiniz"
    LinkD_Uninstall := "PopUpMenu'yu kaldir"
  }
  else
  {
    LinkD_PopUpMenu := "The more you use it, the more you love it"
    LinkD_Uninstall := "Uninstall PopUpMenu"
  }
  ; -------------------------------------------
  if (A_IsAdmin == 1) ; User Had Admin Rights
  {
    if !FileExist(LinkS_PopUpMenu)
    {
      FileCreateShortcut, %LinkT_PopUpMenu%, %LinkS_PopUpMenu%, , , %LinkD_PopUpMenu%, %LinkI_PopUpMenu%
      FileCopy, %LinkS_PopUpMenu%, C:\Program Files\PopUpMenu_PUM\, 1
    }
    if !FileExist(LinkS_Uninstall)
    {
      FileCreateShortcut, %LinkT_Uninstall%, %LinkS_Uninstall%, , , %LinkD_Uninstall%, %LinkI_Uninstall%
      FileCopy, %LinkS_Uninstall%, C:\Program Files\PopUpMenu_PUM, 1
    }
  }
  ; -------------------------------------------
} ; [StartMenu FOLDER] [EXIST, ICON, LINK CHECK] AdMin NOT Reqired
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [FOLDER] [FILES]
  ; -------------------------------------------
  if (A_IsAdmin == 1)
  {
    ; -------------------------------------------
    FileMail := "C:\Program Files\PopUpMenu_PUM\support\PopUpMenu_MailSend.exe"
    FileLink := A_StartMenuCommon "\Programs\PopUpMenu\PopUpMenu.lnk"
    ; -------------------------------------------
    SplitPath, A_AppData, , , , , OutDrive
    ; -------------------------------------------
    FilePath := OutDrive "\Users\*.*"
    ; -------------------------------------------
    Loop Files, %FilePath%, D
    {
      ; -------------------------------------------
      SplitPath, A_LoopFileFullPath, , , , UserName
      ; -------------------------------------------
      FolderMail := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM\emailtemp"
      Ck_FileMail := FolderMail "\PopUpMenu_MailSend.exe"
      if !FileExist(Ck_FileMail)
      {
        FileCopy, %FileMail%, %FolderMail%, 1
      }
      ; -------------------------------------------
      FolderLink := OutDrive "\Users\" UserName "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\PopUpMenu"
      Ck_FileLink := FolderLink "\PopUpMenu.lnk"
      if !FileExist(Ck_FileLink)
      {
        FileCopy, %FileLink%, %FolderLink%, 1
      }
      ; -------------------------------------------
    }
  } ; [End] if (A_IsAdmin == 1)
  ; -------------------------------------------
} ; [FOLDER] [FILES]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [FOLDER] [ICON]
  ; -------------------------------------------
  ProFolderIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\profoldericon.ico"
  PumFolderIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\pumfoldericon.ico"
  ;
  SMC_Folder        := A_StartMenuCommon "\Programs\PopUpMenu"
  PopUpMenu_Folder  := "C:\Program Files\PopUpMenu_PUM"
  ; -------------------------------------------
  if (A_IsAdmin == 1) ; Admin Required to Change (A_StartMenuCommon) ("C:\Program Files")
  {
    if (!FileExist(SMC_Icon) or !FileExist(SMC_Ini))
    {
      ; -------------------------------------------
      FolderIcon(SMC_Folder, ProFolderIcon)
      ; -------------------------------------------
    }
    if (!FileExist(PopUpMenu_Icon) or !FileExist(PopUpMenu_Ini))
    {
      ; -------------------------------------------
      FolderIcon(PopUpMenu_Folder, ProFolderIcon)
      ; -------------------------------------------
    }
    ; -------------------------------------------
    FilePath := A_AppData
    SplitPath, FilePath, , , , , OutDrive
    ; -------------------------------------------
    FilePath := OutDrive "\Users\*.*"
    ; -------------------------------------------
    Loop Files, %FilePath%, D
    {
      ; -------------------------------------------
      ThisFolderPath := A_LoopFileFullPath
      SplitPath, ThisFolderPath, , , , UserName
      ; -------------------------------------------
      SM_Folder := OutDrive "\Users\" UserName "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\PopUpMenu"
      Pum_Folder := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM"
      Pic_Folder := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)"
      ; -------------------------------------------
      if !FileExist(SM_Ini)
      {
        FolderIcon(SM_Folder, ProFolderIcon)
      }
      if !FileExist(Pum_Ini)
      {
        FolderIcon(Pum_Folder, PumFolderIcon)
      }
      if !FileExist(Pic_Ini)
      {
        FolderIcon(Pic_Folder, ProFolderIcon)
      }
    } ; [End] Loop Files, %FilePath%, D
  }
  ; -------------------------------------------
} ; [FOLDER] [ICON]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; Check if Context Menu Enabled
  ; -------------------------------------------
  File_ContextMenu := A_AppData "\PopUpMenu_PUM\system\ContextMenu.txt"
  ; -------------------------------------------
  if FileExist(File_ContextMenu)
  {
    ; -------------------------------------------
    FileReadLine, Use_ContextMenu, %File_ContextMenu%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
    ; -------------------------------------------
    if (Use_ContextMenu == "")
    {
      ; -------------------------------------------
      if FileExist(File_ContextMenu)
      {
        FileDelete, %File_ContextMenu%
        Sleep, 100
      }
      ; -------------------------------------------
      Use_ContextMenu := 1 ; NOT Context By Default
      ; -------------------------------------------
      FileAppend, %Use_ContextMenu%, %File_ContextMenu%, UTF-8
      ; -------------------------------------------
    }
  } ; [End] if FileExist(File_ContextMenu)
  else
  {
    ; -------------------------------------------
    Use_ContextMenu := 1 ; NOT Context By Default
    ; -------------------------------------------
    FileAppend, %Use_ContextMenu%, %File_ContextMenu%, UTF-8
    ; -------------------------------------------
  }
  ; -------------------------------------------
}  ; Check if Context Menu Enabled
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{  ; Check if Current_UserHotKey is Set
  ; -------------------------------------------
  Current_UserHotKey := ""
  File_UserHotkey := A_AppData "\PopUpMenu_PUM\system\File_UserHotkey.txt"
  ; -------------------------------------------
  if FileExist(File_UserHotkey) ; [EXIST] File_UserHotkey
  {
    ; -------------------------------------------
    FileReadLine, Current_UserHotKey, %File_UserHotkey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
    ; -------------------------------------------
    if (Current_UserHotKey == "")
    {
      ; -------------------------------------------
      if FileExist(File_UserHotkey)
      {
        FileDelete, %File_UserHotkey%
        Sleep, 100
      } ; [End] if FileExist(File_UserHotkey)
      ; -------------------------------------------
    } ; [End] if (Current_UserHotKey == "")
    ; -------------------------------------------
  } ; [End] if FileExist(File_UserHotkey) ; [EXIST] File_UserHotkey
  ; -------------------------------------------
} ; Check if UserHotkey is Set
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
{ ; Check if pum_pumdefault.exe Exist
  ; -------------------------------------------
  File_PumDefault := A_AppData "\PopUpMenu_PUM\pums\pumdefault\pum_pumdefault.exe"
  ; -------------------------------------------
  if !FileExist(File_PumDefault)
  {
    Pum_Default()
  } ; [End] if !FileExist(File_PumDefault)
  ; -------------------------------------------
} ; Check if pum_pumdefault.exe Exist (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
{ ; [CHECK]/[CREATE]/[UNZIP] [FOLDER] (Folder_Key) (Folder_Windows) (Folder_Ofl)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; All Icons in [UserPictureFolder]
  ; -------------------------------------------
  ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderKey", UserLang, UserPictureFolder]
  ArrayOut   := Image_PathFolderOrName(ArrayIn)
  FolderKey := ArrayOut.1
  Icons_Keyboard := FolderKey "\*.ico"
  ; -------------------------------------------
  ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderWindows", UserLang, UserPictureFolder]
  ArrayOut   := Image_PathFolderOrName(ArrayIn)
  FolderWindows := ArrayOut.1
  Icons_Windows := FolderWindows "\*.ico"
  ; -------------------------------------------
  ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderOfl", UserLang, UserPictureFolder]
  ArrayOut   := Image_PathFolderOrName(ArrayIn)
  FolderOfl := ArrayOut.1
  ; -------------------------------------------
  Icons_Ofl := FolderOfl "\(1) Top\(1)\*.ico"
  ; -------------------------------------------
  if (!FileExist(Icons_Keyboard) or !FileExist(Icons_Windows) or !FileExist(Icons_Ofl))
  {
    ; -------------------------------------------
    StartTime := A_TickCount
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("515", 0) ; (515_1)(Splash Anamated: Installing Keyboard Icons)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; "FolderKey" [UserPictureFolder "\(_PopUpMenu_)\(_Keyboard_)"]
    ; -------------------------------------------
    FileCreateDir, %FolderKey%
    ; -------------------------------------------
    FolderKey_ZipFile := "C:\Program Files\PopUpMenu_PUM\image\ico\FolderKey.zip"
    File_UnZip(FolderKey_ZipFile, FolderKey)
    ; -------------------------------------------
    File_ListKeyIcon := A_AppData "\PopUpMenu_PUM\system\File_ListKeyIcon.txt"
    FileDelete, %File_ListKeyIcon%
    ; -------------------------------------------
    ; "FolderKey" [UserPictureFolder "\(_PopUpMenu_)\(_Keyboard_)"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; "FolderWindows" [UserPictureFolder "\(_PopUpMenu_)\(_Windows_)"]
    ; -------------------------------------------
    FileCreateDir, %FolderWindows%
    ; -------------------------------------------
    FolderWindows_1_ZipFile := "C:\Program Files\PopUpMenu_PUM\image\ico\FolderWindows_1.zip"
    File_UnZip(FolderWindows_1_ZipFile, FolderWindows)
    ; -------------------------------------------
    Sleep, 500
    ; -------------------------------------------
    FolderWindows_2_ZipFile := "C:\Program Files\PopUpMenu_PUM\image\ico\FolderWindows_2.zip"
    File_UnZip(FolderWindows_2_ZipFile, FolderWindows)
    ; -------------------------------------------
    File_ListWindowsIcon := A_AppData "\PopUpMenu_PUM\system\File_ListWindowsIcon.txt"
    FileDelete, %File_ListWindowsIcon%
    ; -------------------------------------------
    ; "FolderWindows" [UserPictureFolder "\(_PopUpMenu_)\(_Windows_)"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; "FolderOfl" [UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"]
    ; -------------------------------------------
    FileCreateDir, %FolderOfl%
    ; -------------------------------------------
    FolderOfl_1_ZipFile := "C:\Program Files\PopUpMenu_PUM\image\ico\FolderOfl_1.zip"
    File_UnZip(FolderOfl_1_ZipFile, FolderOfl)
    ; -------------------------------------------
    Sleep, 500
    ; -------------------------------------------
    FolderOfl_2_ZipFile := "C:\Program Files\PopUpMenu_PUM\image\ico\FolderOfl_2.zip"
    File_UnZip(FolderOfl_2_ZipFile, FolderOfl)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [SET] Folder Icons
    ; -------------------------------------------
    Loop, Files, %FolderOfl%\*.ico, R
    {
      ; -------------------------------------------
      ThisIcon := A_LoopFileFullPath
      ; -------------------------------------------
      if (InStr(ThisIcon, "(FolderIco).ico") > 0)
      {
        ; -------------------------------------------
        SplitPath, ThisIcon, , IconFolder
        ; -------------------------------------------
        Folder_SetIcon(IconFolder, ThisIcon, 1)
        ; -------------------------------------------
      } ; [End] if (InStr(ThisIcon, "(FolderIco).ico") > 0)
    } ; [End] Loop, Files, %Folder_Ofl%\*.ico, R
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    File_ListFolderIcon := A_AppData "\PopUpMenu_PUM\system\File_ListFolderIcon.txt"
    FileDelete, %File_ListFolderIcon%
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    EndTime := A_TickCount - StartTime ; Ths Time for the zip file to decompress
    ; -------------------------------------------
    if (EndTime < 13000) ; the time needed for the Animation to finish
    {
      ; -------------------------------------------
      SleepTime := 13000 - EndTime
      Sleep, %SleepTime% ; Wait for until Animation to finish
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; "FolderOfl" [UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; if (!FileExist(Icons_Keyboard) or !FileExist(Icons_Windows) or !FileExist(Icons_Ofl))
  ; -------------------------------------------
  ; All Icons in [UserPictureFolder]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
} ; [End] [CHECK]/[CREATE]/[UNZIP] [FOLDER] (Folder_Key) (Folder_Windows) (Folder_Ofl)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
{ ; [CHECK]/[CREATE] [LIST] (File_ListKeyIcon.txt) (File_ListWindowsIcon.txt) (File_ListFolderIcon.txt)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; File_ListKeyIcon.txt
  ; -------------------------------------------
  File_ListKeyIcon  := A_AppData "\PopUpMenu_PUM\system\File_ListKeyIcon.txt"
  ; -------------------------------------------
  if !FileExist(File_ListKeyIcon)
  {
    ; -------------------------------------------
    ; ThisType = "FolderKey"       [FOLDER]  UserPictureFolder "\(_PopUpMenu_)\(_Keyboard_)"
    ; -------------------------------------------
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderKey", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FolderKey := ArrayOut.1
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    ; -------------------------------------------
    Loop, Files, %FolderKey%\*.ico, R
    {
      FileAppend, %A_LoopFileFullPath%`n, %File_ListKeyIcon% ; UTF-8
    }
    ; -------------------------------------------
  } ; [End] if !FileExist(File_ListKeyIcon)
  ; -------------------------------------------
  ; File_ListKeyIcon.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; File_ListWindowsIcon.txt
  ; -------------------------------------------
  File_ListWindowsIcon  := A_AppData "\PopUpMenu_PUM\system\File_ListWindowsIcon.txt"
  ; -------------------------------------------
  if !FileExist(File_ListWindowsIcon)
  {
    ; -------------------------------------------
    ; ThisType = "FolderWindows"   [FOLDER]  UserPictureFolder "\(_PopUpMenu_)\(_Windows_)"
    ; -------------------------------------------
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderWindows", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FolderWindows := ArrayOut.1
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    ; -------------------------------------------
    Loop, Files, %FolderWindows%\*.ico, R
    {
      FileAppend, %A_LoopFileFullPath%`n, %File_ListWindowsIcon% ; UTF-8
    }
    ; -------------------------------------------
  } ; [End] if !FileExist(File_ListWindowsIcon)
  ; -------------------------------------------
  ; File_ListWindowsIcon.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; File_ListFolderIcon.txt
  ; -------------------------------------------
  File_ListFolderIcon  := A_AppData "\PopUpMenu_PUM\system\File_ListFolderIcon.txt"
  ; -------------------------------------------
  if !FileExist(File_ListFolderIcon)
  {
    ; -------------------------------------------
    ; ThisType = "FolderOfl"       [FOLDER]  UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"
    ; -------------------------------------------
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FolderOfl", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FolderOfl := ArrayOut.1
    ; -------------------------------------------
    FileEncoding, UTF-8 ; UTF-8
    ; -------------------------------------------
    Loop, Files, %FolderOfl%\*.ico, R
    {
      FileAppend, %A_LoopFileFullPath%`n, %File_ListFolderIcon% ; UTF-8
    }
    ; -------------------------------------------
  } ; [End] if !FileExist(File_ListFolderIcon)
  ; -------------------------------------------
  ; File_ListFolderIcon.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
} ; [End] [CHECK]/[CREATE] [LIST] (File_ListKeyIcon.txt) (File_ListWindowsIcon.txt) (File_ListFolderIcon.txt)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (UserLang)
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; if Current User has Admin Rights
; [RUN] Script_StartUp.ahk [UPDATE] PopUpMenu Program
; -------------------------------------------
if (A_IsAdmin == 1) ; User is Admin
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if There ia a Internet Connection
  ; -------------------------------------------
	HasConnection := InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
  ; -------------------------------------------
  ; Check if There ia a Internet Connection
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (HasConnection == 1)
  {
    ; -------------------------------------------
    Pc_FileUpdateLastTxt := "C:\Program Files\PopUpMenu_PUM\update\last_pum.txt"
    FileReadLine, BeforeUpdateNum, %Pc_FileUpdateLastTxt%, 1
    Sleep, 250
    ; -------------------------------------------
    RunWait, C:\Program Files\PopUpMenu_PUM\SysConfig.ahk
    ; -------------------------------------------
    Pc_FileUpdateLastTxt := "C:\Program Files\PopUpMenu_PUM\update\last_pum.txt"
    FileReadLine, AfterUpdateNum, %Pc_FileUpdateLastTxt%, 1
    Sleep, 250
    ; -------------------------------------------
  }
  else
  {
    ; -------------------------------------------
    ; Skip Update
    ; -------------------------------------------
    BeforeUpdateNum := 0
    AfterUpdateNum  := 0
    ; -------------------------------------------
  }
} ; [End] if (A_IsAdmin == 1) ; User is Admin
else  ; User is NOT Admin
{
  ; -------------------------------------------
  ; Skip Update
  ; -------------------------------------------
  BeforeUpdateNum := 0
  AfterUpdateNum  := 0
  ; -------------------------------------------
} ; [End] else  ; User is NOT Admin
; -------------------------------------------
; [RUN] Script_StartUp.ahk [UPDATE] PopUpMenu Program
; if Current User has Admin Rights
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; if There was a Update Reload PopUpMenu.ahk
; -------------------------------------------
if (BeforeUpdateNum == AfterUpdateNum) ; No New Update -OR- User is NOT Admin
{
  ; -------------------------------------------
  if (Current_UserHotKey == "" && Use_ContextMenu == 1) ; [NO UserHotKey] and [ContextMenu is OFF 1] run Hotkey_gui
  {
    ; -------------------------------------------
    Splash_Script("Off", 0) ; (Just Before) (Start of) Hotkey_gui.ahk
    Sleep, 250
    ; -------------------------------------------
    Run C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk
    ; -------------------------------------------
    Sleep, 250
    return
    ; -------------------------------------------
  } ; [End] run Hotkey_gui
  else ; [UserHotKey is Set] or [ContextMenu is ON 2]
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Start (PopUpMenu)
    ; -------------------------------------------
    BreakTime := A_TickCount + 5000
    ; -------------------------------------------
    File_PopUpMenu := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
    Run, %File_PopUpMenu%,,, Process_SysTray
    Sleep, 500
    Process, Priority, %Process_SysTray%, High
    ; -------------------------------------------
    while !WinExist("Shortcut_Pop_Up_Menu" . "ahk_exe AutoHotkey.exe") ; (NOT Running)
    {
      ; -------------------------------------------
      Sleep, 100
      ; -------------------------------------------
      if (A_TickCount > BreakTime)
      {
        break
      }
      ; -------------------------------------------
    } ; [End] while (Script_Running(File_PopUpMenu) == 0) ; (NOT Running)
    ; -------------------------------------------
    return
    ; -------------------------------------------
  } ; [End] [EXIST] Hotkey for PopUpMenu
  ; -------------------------------------------
} ; [End] if (BeforeUpdateNum == AfterUpdateNum) ; No New Update -OR- User is NOT Admin
else ; There was a New Update
{
  ; -------------------------------------------
  Reload
  ; -------------------------------------------
} ; There was a New Update
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FolderIcon(ThisFolder, ThisIcon)
{
  ; -------------------------------------------
  DesktopIni := ThisFolder "\desktop.ini"
  ; -------------------------------------------
  if FileExist(DesktopIni)
  {
    FileDelete, %DesktopIni%
    Sleep, 100
  }
  ; -------------------------------------------
  Line_1 := "[.ShellClassInfo]"
  Line_2 := "IconFile=" ThisIcon
  Line_3 := "IconResource=" ThisIcon ",0"
  Line_4 := "[ViewState]"
  Line_5 := "FolderType=Generic"
  Line_6 := "Mode="
  Line_7 := "Vid="
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %Line_1%`n, %DesktopIni% ; UTF-8
FileAppend, %Line_2%`n, %DesktopIni% ; UTF-8
  FileAppend, %Line_3%`n, %DesktopIni% ; UTF-8
  FileAppend, %Line_4%`n, %DesktopIni% ; UTF-8
  FileAppend, %Line_5%`n, %DesktopIni% ; UTF-8
  FileAppend, %Line_6%`n, %DesktopIni% ; UTF-8
  FileAppend, %Line_7%`n, %DesktopIni% ; UTF-8
  Sleep, 100
  FileSetAttrib, +SH, %DesktopIni%, 0
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
internetconnectcheck.txt
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
Label_InternetConnectCheck.txt
{
  ; -------------------------------------------
  File_InternetConnectCheck := A_Temp "\internetconnectcheck.txt"
  ; -------------------------------------------
  
  
}
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
