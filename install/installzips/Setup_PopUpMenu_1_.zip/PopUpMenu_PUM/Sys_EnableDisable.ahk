﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Sys_EnableDisable(EnableDisable) ; "Enable" or "Disable"
{
  ; -------------------------------------------
  GuiControl, PopUpMenu:%EnableDisable%, g_084 ; (084_1)(Obj_Tom_FileUrlFolder)
  GuiControl, PopUpMenu:%EnableDisable%, g_086 ; (086_1)(Obj_Tom_MenuControlKey)
  GuiControl, PopUpMenu:%EnableDisable%, g_083 ; (083_1)(Obj_Tom_Pum)
  ; -------------------------------------------
  GuiControl, PopUpMenu:%EnableDisable%, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
  GuiControl, PopUpMenu:%EnableDisable%, g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
  GuiControl, PopUpMenu:%EnableDisable%, g_188 ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
  GuiControl, PopUpMenu:%EnableDisable%, g_189 ; (189_1)(Obj_Pum_EditFeild_ContactName)
  GuiControl, PopUpMenu:%EnableDisable%, g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
  GuiControl, PopUpMenu:%EnableDisable%, g_272 ; (272_1)(Obj_Pum_PumColumn)
  GuiControl, PopUpMenu:%EnableDisable%, g_266 ; (266_1)(Obj_Pum_PumRow)
  ; -------------------------------------------
  GuiControl, PopUpMenu:%EnableDisable%, g_116 ; (116_1)(Obj_CplMnu_List100)
  GuiControl, PopUpMenu:%EnableDisable%, g_117 ; (117_1)(Obj_CplMnu_ListRight60)
  GuiControl, PopUpMenu:%EnableDisable%, g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
  GuiControl, PopUpMenu:%EnableDisable%, g_120 ; (120_1)(Obj_CplMnu_ListCenter30)
  GuiControl, PopUpMenu:%EnableDisable%, g_121 ; (121_1)(Obj_CplMnu_ListRight30)
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
