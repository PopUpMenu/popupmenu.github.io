﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\XmlValidate.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Copies a Backup of All Pum XML Files
; -------------------------------------------
XmlBackup() ; > Nothing
{
	; -------------------------------------------
	Folder_AllPums := A_AppData "\PopUpMenu_PUM\pums"
	; -------------------------------------------
	if FileExist(Folder_AllPums) ; if Pum Folder Exist
	{
		; -------------------------------------------
	  Loop Files, %Folder_AllPums%\pum_*.exe, R
	  {
  		; -------------------------------------------
		  File_PumExe := A_LoopFileFullPath
		  SplitPath, File_PumExe, , Folder_Pum
		  ; -------------------------------------------
		  BackupFolder_PumXml := StrReplace(Folder_Pum, "\pums", "\pums_backup")
		  BackupFolder_PumXml := BackupFolder_PumXml "\settings"
		  ; -------------------------------------------
		  BackupFile_PumXml := BackupFolder_PumXml "\toolbox0.xml"
		  ; -------------------------------------------
		  if !FileExist(BackupFile_PumXml) ; IF Backup DOES NOT Exist, Then Copy
		  {
  			; -------------------------------------------
			  File_PumXml := Folder_Pum "\settings\toolbox0.xml"
				; -------------------------------------------
				if FileExist(File_PumXml)
				{
					; -------------------------------------------
			    OK_XmlBackup := XmlValidate(File_PumXml) ; > [1, 0]
			    ; -------------------------------------------
			    if (OK_XmlBackup == 1)
			    {
    				; -------------------------------------------
				    if !FileExist(BackupFolder_PumXml)
				    {
    					; -------------------------------------------
					    FileCreateDir, %BackupFolder_PumXml%
					    Sleep, 100
					    ; -------------------------------------------
				    } ; if !FileExist(BackupFolder_PumXml)
				    ; -------------------------------------------
				    ;
				    ; -------------------------------------------
				    FileCopy, %File_PumXml%, %BackupFile_PumXml%, 1
				    ; -------------------------------------------
			    } ; if (OK_XmlBackup == 1)
				} ; if FileExist(File_PumXml)
		  } ; if !FileExist(BackupFile_PumXml)
    } ; Loop Files, %Folder_AllPums%\pum_*.exe, R
	} ; if FileExist(Folder_AllPums) ; if Pum Folder Exist
} ; XmlBackup(File_ThisXml) ; > Nothing
; -------------------------------------------
