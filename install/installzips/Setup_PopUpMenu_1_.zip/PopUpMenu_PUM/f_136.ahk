﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\f_085.ahk ; (085_1)(Obj_Key_Keyboard)
#Include C:\Program Files\PopUpMenu_PUM\f_082.ahk ; (082_1)(Obj_Ofl_Folder)
#Include C:\Program Files\PopUpMenu_PUM\f_159.ahk ; (159_1)(Obj_Pum_Contact)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_136(DataArray) ; (136_1)(Obj_ImageSelect3)
{
  ; -------------------------------------------
  if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_085(DataArray) ; (085_1)(Obj_Key_Keyboard)
  }
  else if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_082(DataArray) ; (082_1)(Obj_Ofl_Folder)
  }
  else if (DataArray.366.5 == "pumtom" or DataArray.366.5 == "pumApplication") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_159(DataArray) ; (159_1)(Obj_Pum_Contact)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
