﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Numbers.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Display.ahk
#Include C:\Program Files\PopUpMenu_PUM\String_Reverse.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_Info(DataArray)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Remove any File that is not a *.exe or *.ini Extension
  ; ThisPumProcessFolder
  ; -------------------------------------------
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Loop Files, %ThisPumProcessFolder%
  {
    ; -------------------------------------------
    ThisFilePath := A_LoopFileFullPath
    ; -------------------------------------------
    SplitPath, ThisFilePath, , , ThisFilePath_Ext
    StringLower, ThisFilePath_Ext, ThisFilePath_Ext
    ; -------------------------------------------
    if (ThisFilePath_Ext != "exe" or ThisFilePath_Ext != "ini")
    {
      FileDelete, %ThisFilePath%
    }
  } ; [End] Loop Files, %ThisPumProcessFolder%
  ; -------------------------------------------
  ; Remove any File that is not a *.exe or *.ini Extension
  ; ThisPumProcessFolder
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  { ; Reset Vars
    ; -------------------------------------------
    ; [cpl]
    ; -------------------------------------------
    DataArray.72.2   := "" ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    DataArray.73.2   := "" ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray.300.2  := "" ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    DataArray.300.3  := "" ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
    DataArray.300.4  := "" ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    DataArray.300.5  := "" ; (300_5)(Cpl_Number_000x [X_X_X_#])
    ; (NOT Needed Here) (300_6)(Cpl_MenuSize [#])
    ; (Number NOT Used) (300_7)(Empty)
    DataArray.300.8  := "" ; (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [key]
    ; -------------------------------------------
    DataArray.301.2  := "" ; (301_2)(Key_ArrayNumbers [Array])
    DataArray.301.5  := "" ; (301_5)(KeyMnu_Class)
    DataArray.301.6  := "" ; (301_6)(keyMnu_ProcessName)
    DataArray.301.7  := "" ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
    DataArray.301.8  := "" ; (301_8)(Key_KeyArrayShortcut [Array])
    DataArray.123.3  := "" ; (123_3)(Obj_Key_EditFeild_TextInput_Val [Text Value])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [mnu]
    ; -------------------------------------------
    DataArray.302.2  := "" ; (302_2)(Mnu_Number_x000 [#_X_X_X])
    DataArray.302.3  := "" ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
    DataArray.302.4  := "" ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
    DataArray.302.5  := "" ; (302_5)(Mnu_Number_000x [X_X_X_#])
    ; (NOT Needed Here) (302_6)(Mnu_MenuSize [#])
    ; (NOT Needed Here) (302_7)(Mnu_ActiveAddonInstalled [0/1])
    DataArray.302.8  := "" ; (302_8)(Mnu_ComNum [Com_#### or Mkb_#### Used for Icon and Link/ahk Name])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [ofl]
    ; -------------------------------------------
    DataArray.303.2  := "" ; (303_2)(ofl_FolderPathName [Folder Name With Path])
    DataArray.303.3  := "" ; (303_3)(ofl_FolderName [Folder Name NO Path])
    ; -------------------------------------------
    ; [run]
    ; -------------------------------------------
    DataArray.305.2  := "" ; (305_2)(Run_FileName [Selected File] [Name])
    DataArray.305.3  := "" ; (305_3)(Run_FileNameExt [Selected File] [Name,Ext])
    DataArray.305.11  := "" ; (305_11)(Run_OutTarget [PathExtName])
    DataArray.305.12  := "" ; (305_12)(Run_Arguments [Executable Arguments])
    DataArray.305.13  := "" ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [rwh]
    ; -------------------------------------------
    DataArray.305.5  := "" ; (305_5)(Rwh_OpeningApp [Full File Path])
    DataArray.305.9  := "" ; (305_9)(Run_FolderPath [Folder Path])
    DataArray.305.10 := "" ; (305_10)(Run_FileExt WithOut [.])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [url]
    ; -------------------------------------------
    DataArray.307.2  := "" ; (307_2)(Url_Address)
    DataArray.307.9  := "" ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [cpl][mnu]
    ; -------------------------------------------
    DataArray.366.4  := "" ; (366_4)(cplmnu_IsDivider [Selected List Item is a Divider] [0/1])
    ; -------------------------------------------
  } ; End Reset Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; StartUp Vars
    ; -------------------------------------------
    ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    TbXml_ShortcutPath := DataArray.370.8 ; (370_8)(XmlScriptPath [Full File Path])
    DataArray.370.9 := DataArray.370.8 ; (370_9)(XmlOldScriptPath [Full File Path])/(370_8)(XmlScriptPath [Full File Path])
    ; -------------------------------------------
  } ; End StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; Pum Read Shortcut Script
    ; -------------------------------------------
    FileReadLine, Script_Line_2, %TbXml_ShortcutPath%, 2
    FileReadLine, Script_Line_3, %TbXml_ShortcutPath%, 3
    FileReadLine, Script_Line_4, %TbXml_ShortcutPath%, 4
    FileReadLine, Script_Line_5, %TbXml_ShortcutPath%, 5
    FileReadLine, Script_Line_6, %TbXml_ShortcutPath%, 6
    ; -------------------------------------------
    if (InStr(Script_Line_2, "Script_Line_") > 0)
    {
      Script_Line_2 := StrReplace(Script_Line_2, "Script_Line_2 := ", "")
      Script_Line_3 := StrReplace(Script_Line_3, "Script_Line_3 := ", "")
      Script_Line_4 := StrReplace(Script_Line_4, "Script_Line_4 := ", "")
      Script_Line_5 := StrReplace(Script_Line_5, "Script_Line_5 := ", "")
      Script_Line_6 := StrReplace(Script_Line_6, "Script_Line_6 := ", "")
    }
    else if (InStr(Script_Line_2, "Var_1") > 0)
    {
      Script_Line_2 := StrReplace(Script_Line_2, "Var_1 := ", "")
      Script_Line_3 := StrReplace(Script_Line_3, "Var_2 := ", "")
      Script_Line_4 := StrReplace(Script_Line_4, "Var_3 := ", "")
      Script_Line_5 := StrReplace(Script_Line_5, "Var_4 := ", "")
      Script_Line_6 := StrReplace(Script_Line_6, "Var_5 := ", "")
    }
    ; -------------------------------------------
  } ; End Pum XML Info (<filename>) / Read Script.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ScriptType = "cpl")
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ; Script_Line_2 := "Com_####"                 (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ; Script_Line_3 := ""                         *** EMPTY ***
    ; Script_Line_4 := ""                         *** EMPTY ***
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ;
    ; ------------------------------------------- Script_Line_2
    cpl_ComNum := Script_Line_2
    cpl_ComNum := StrReplace(cpl_ComNum, """", "")
    cpl_ComNum := StrReplace(cpl_ComNum, A_Space, "")
    ; ------------------------------------------- Script_Line_2
    ;
    ; -------------------------------------------
    File_Cpl_Number := "C:\Program Files\PopUpMenu_PUM\menu\cpl\cpl_number.txt"
    Array_Cpl_Number := Array_FromFile(File_Cpl_Number) ; > Array
    ; -------------------------------------------
    for Index, CplLine in Array_Cpl_Number
    {
      if (InStr(CplLine, cpl_ComNum) > 0)
      {
        Cpl_MenuNumEnd := InStr(CplLine, "|")
        Cpl_MenuNum := SubStr(CplLine, 1, Cpl_MenuNumEnd - 1)
      }
    }
    ; -------------------------------------------
    Pos_UnderScore1 := InStr(Cpl_MenuNum, "_",,, 1)
    Pos_UnderScore2 := InStr(Cpl_MenuNum, "_",,, 2)
    Pos_UnderScore3 := InStr(Cpl_MenuNum, "_",,, 3)
    ; -------------------------------------------
    if (Pos_UnderScore3 > 0)
    {
      ; -------------------------------------------
      Cpl_Number_x000 := SubStr(Cpl_MenuNum, 1, Pos_UnderScore1 - 1)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 1
      ThisEnd   := Pos_UnderScore2
      ThisLen   := ThisEnd - ThisStart
      Cpl_Number_0x00 := SubStr(Cpl_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore2 + 1
      ThisEnd   := Pos_UnderScore3
      ThisLen   := ThisEnd - ThisStart
      Cpl_Number_00x0 := SubStr(Cpl_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore3 + 2
      Cpl_Number_000x := SubStr(Cpl_MenuNum, ThisStart)
      Cpl_Number_000x := StrReplace(Cpl_Number_000x, ")", "")
      ; -------------------------------------------
    }
    else if (Pos_UnderScore2 > 0)
    {
      ; -------------------------------------------
      Cpl_Number_x000 := SubStr(Cpl_MenuNum, 1, Pos_UnderScore1 - 1)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 1
      ThisEnd   := Pos_UnderScore2
      ThisLen   := ThisEnd - ThisStart
      Cpl_Number_0x00 := SubStr(Cpl_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      Cpl_Number_00x0 := 0
      ; -------------------------------------------
      ThisStart := Pos_UnderScore2 + 2
      Cpl_Number_000x := SubStr(Cpl_MenuNum, ThisStart)
      Cpl_Number_000x := StrReplace(Cpl_Number_000x, ")", "")
      ; -------------------------------------------
    }
    else if (Pos_UnderScore1 > 0)
    {
      ; -------------------------------------------
      Cpl_Number_x000 := SubStr(Cpl_MenuNum, 1, Pos_UnderScore1 - 1)
      Cpl_Number_0x00 := 0
      Cpl_Number_00x0 := 0
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 2
      Cpl_Number_000x := SubStr(Cpl_MenuNum, ThisStart)
      Cpl_Number_000x := StrReplace(Cpl_Number_000x, ")", "")
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ;
    ;
    ; ------------------------------------------- [UPDATE] DataArray
    DataArray.300.8 := cpl_ComNum ; (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ;
    DataArray.300.2 := Cpl_Number_x000 ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    DataArray.300.3 := Cpl_Number_0x00 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
    DataArray.300.4 := Cpl_Number_00x0 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    DataArray.300.5 := Cpl_Number_000x ; (300_5)(Cpl_Number_000x [X_X_X_#])
    ; ------------------------------------------- [UPDATE] DataArray
  } ; End (Script Type)(cpl)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "key")
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; Script_Line_2 := 1/2                        (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
    ; Script_Line_3 := ["[Key]", "~X~"]           (301_8)(Key_KeyArrayShortcut [Array])
    ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
    ; Script_Line_5 := "App ProcessPathNameExt"   (301_10)(KeyMnu_ProcessPathExtName)
    ; Script_Line_6 := 0/1                        (301_11)(Key_ShortcutInAppPum [0,1])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ;
    ; ------------------------------------------- Script_Line_2
    Obj_KeyMnu_AppOnly_Sel := Script_Line_2
    ; ------------------------------------------- Script_Line_2
    ;
    ; ------------------------------------------- Script_Line_3
    key_KeyArrayShortcut_Temp := Script_Line_3
    NextKey_Pos := InStr(key_KeyArrayShortcut_Temp, "`,")
    ; -------------------------------------------
    if (NextKey_Pos == 0)
    {
      ThisKey := SubStr(key_KeyArrayShortcut_Temp, 2, NextKey_Pos - 1)
      ThisKey := StrReplace(ThisKey, """", "")
      Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, ThisKey, "End")
    } ; End (NextKey_Pos == 0)
    else ; (NextKey_Pos > 0)
    {
      ; -------------------------------------------
      while (NextKey_Pos > 0)
      {
        ThisKey := SubStr(key_KeyArrayShortcut_Temp, 2, NextKey_Pos - 3)
        key_KeyArrayShortcut_Temp := SubStr(key_KeyArrayShortcut_Temp, NextKey_Pos + 2)
        ThisKey := StrReplace(ThisKey, """", "")
        Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, ThisKey, "End")
        NextKey_Pos := InStr(key_KeyArrayShortcut_Temp, "`,")
        if (NextKey_Pos == 0)
        {
          ThisKey := SubStr(key_KeyArrayShortcut_Temp, 2, NextKey_Pos - 1)
          ThisKey := StrReplace(ThisKey, """", "")
          Key_KeyArrayShortcut := Array_Add(Key_KeyArrayShortcut, ThisKey, "End")
        } ; End (NextKey_Pos == 0)
      } ; End while (NextKey_Pos > 0)
    } ; End (NextKey_Pos > 0)
    ; ------------------------------------------- Script_Line_3
    ;
    ; ------------------------------------------- Script_Line_4
    KeyMnu_Class := Script_Line_4
    KeyMnu_Class := StrReplace(KeyMnu_Class, """", "")
    ; ------------------------------------------- Script_Line_4
    ;
    ; ------------------------------------------- Script_Line_5
    KeyMnu_ProcessPathNameExt := Script_Line_5
    KeyMnu_ProcessPathNameExt := StrReplace(KeyMnu_ProcessPathNameExt, """", "")
    ; -------------------------------------------
    SplitPath, KeyMnu_ProcessPathExtName, KeyMnu_ProcessExtName, , , KeyMnu_ProcessName
    ; ------------------------------------------- [UPDATE] DataArray
    ; (Value) (key)
    DataArray.72.2   := Obj_KeyMnu_AppOnly_Sel ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    DataArray.301.5  := KeyMnu_Class ; (301_5)(KeyMnu_Class)
    DataArray.301.6  := KeyMnu_ProcessName ; (301_6)(keyMnu_ProcessName)
    DataArray.301.8  := Key_KeyArrayShortcut ; (301_8)(Key_KeyArrayShortcut [Array])
    DataArray.301.9  := KeyMnu_ProcessExtName ; (301_9)(KeyMnu_ProcessExtName)
    DataArray.301.10 := KeyMnu_ProcessPathNameExt ; (301_10)(KeyMnu_ProcessPathExtName)
    ; -------------------------------------------
    ; Creates
    ; (301_2)([key] (key_ArrayNumbers) [Array])
    ; From
    ; (301_8)([key] (Key_KeyArrayShortcut) [Array])
    DataArray := KeyArray_Numbers(DataArray) ; > DataArray
    ; -------------------------------------------
    ; Creates
    ; (301_7)([key] (key_KeyArrayDisplay) [String] [by Lang])
    ; From
    ; (301_2)([key] (key_ArrayNumbers) [Array])
    DataArray := KeyArray_Display(DataArray) ; > DataArray
    ; -------------------------------------------
    ; [SET] Below
    ; (122_1)(Obj_EditFeild_StatusBar)
    ; (102_1)(Obj_DisplayedIcon)
    ; ------------------------------------------- [UPDATE] DataArray
  } ; End (Script Type)(key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "mnu") ; (366_5)((ScriptType) [cpl,key,mnu,ofl,pum,run,rwh])
  {
    ; -------------------------------------------
    ; Shortcut_Info.ahk
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
    ; Script_Line_3 := "Com_####" or "Mkb_####"   (302_8)(Mnu_ComNum [Com_#### Used for Icon and Link/ahk Name])
    ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
    ; Script_Line_5 := "KeyMnu_ProcessExtName"    (301)(09)(KeyMnu_ProcessExtName)
    ; Script_Line_6 := "Lang"                     (365_2)(UserLang [Current User language])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
    ; -------------------------------------------
    Mkb_KeyStroke := Script_Line_2
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
    ; -------------------------------------------
    Mnu_ComNum := Script_Line_3
    Mnu_ComNum := StrReplace(Mnu_ComNum, """", "")
    Mnu_ComNum := StrReplace(Mnu_ComNum, A_Space, "")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
    ; -------------------------------------------
    KeyMnu_Class := Script_Line_4
    KeyMnu_Class := StrReplace(KeyMnu_Class, """", "")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Script_Line_5 := "KeyMnu_ProcessExtName"    (301)(09)(KeyMnu_ProcessExtName)
    ; -------------------------------------------
    KeyMnu_ProcessExtName := Script_Line_5
    KeyMnu_ProcessExtName := StrReplace(KeyMnu_ProcessExtName, """", "")
    KeyMnu_ProcessName := SubStr(KeyMnu_ProcessExtName, 1, StrLen(KeyMnu_ProcessExtName) - 4)
    StringLower, Lower_KeyMnu_ProcessName, KeyMnu_ProcessName
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Script_Line_6 := "Lang"                      (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    Script_UserLang := Script_Line_6
    Script_UserLang := StrReplace(Script_UserLang, """", "")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Read File
    ; Addon (Com_XXXX, Mbk_XXXX) 
    ; Menu Location [#_#_#_#]
    ; -------------------------------------------
    File_Mnu_Number := "C:\Program Files\PopUpMenu_PUM\menu\mnu\" Lower_KeyMnu_ProcessName "\" Script_UserLang "\number_" Lower_KeyMnu_ProcessName "_" Script_UserLang ".txt"
    Array_Mnu_Number := Array_FromFile(File_Mnu_Number) ; > Array
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Set Mnu_Number_x000, Mnu_Number_0x00, Mnu_Number_00x0, Mnu_Number_000x
    ; -------------------------------------------
    for Index, MnuLine in Array_Mnu_Number
    {
      if (InStr(MnuLine, Mnu_ComNum) > 0)
      {
        Mnu_MenuNumEnd := InStr(MnuLine, "|")
        Mnu_MenuNum := SubStr(MnuLine, 1, Mnu_MenuNumEnd - 1)
      }
    }
    ; -------------------------------------------
    Pos_UnderScore1 := InStr(Mnu_MenuNum, "_",,, 1)
    Pos_UnderScore2 := InStr(Mnu_MenuNum, "_",,, 2)
    Pos_UnderScore3 := InStr(Mnu_MenuNum, "_",,, 3)
    ; -------------------------------------------
    if (Pos_UnderScore3 > 0)
    {
      ; -------------------------------------------
      Mnu_Number_x000 := SubStr(Mnu_MenuNum, 1, Pos_UnderScore1 - 1)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 1
      ThisEnd   := Pos_UnderScore2
      ThisLen   := ThisEnd - ThisStart
      Mnu_Number_0x00 := SubStr(Mnu_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore2 + 1
      ThisEnd   := Pos_UnderScore3
      ThisLen   := ThisEnd - ThisStart
      Mnu_Number_00x0 := SubStr(Mnu_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore3 + 2
      Mnu_Number_000x := SubStr(Mnu_MenuNum, ThisStart)
      Mnu_Number_000x := StrReplace(Mnu_Number_000x, ")", "")
      ; -------------------------------------------
    }
    else if (Pos_UnderScore2 > 0)
    {
      ; -------------------------------------------
      Mnu_Number_x000 := SubStr(Mnu_MenuNum, 1, Pos_UnderScore1 - 1)
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 1
      ThisEnd   := Pos_UnderScore2
      ThisLen   := ThisEnd - ThisStart
      Mnu_Number_0x00 := SubStr(Mnu_MenuNum, ThisStart, ThisLen)
      ; -------------------------------------------
      Mnu_Number_00x0 := 0
      ; -------------------------------------------
      ThisStart := Pos_UnderScore2 + 2
      Mnu_Number_000x := SubStr(Mnu_MenuNum, ThisStart)
      Mnu_Number_000x := StrReplace(Mnu_Number_000x, ")", "")
      ; -------------------------------------------
    }
    else if (Pos_UnderScore1 > 0)
    {
      ; -------------------------------------------
      Mnu_Number_x000 := SubStr(Mnu_MenuNum, 1, Pos_UnderScore1 - 1)
      Mnu_Number_0x00 := 0
      Mnu_Number_00x0 := 0
      ; -------------------------------------------
      ThisStart := Pos_UnderScore1 + 2
      Mnu_Number_000x := SubStr(Mnu_MenuNum, ThisStart)
      Mnu_Number_000x := StrReplace(Mnu_Number_000x, ")", "")
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; Set Mnu_Number_x000, Mnu_Number_0x00, Mnu_Number_00x0, Mnu_Number_000x
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [UPDATE] DataArray
    ; -------------------------------------------
    DataArray.72.2   := 2 ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
    DataArray.301.5  := KeyMnu_Class ; (301_5)(KeyMnu_Class)
    DataArray.301.6  := KeyMnu_ProcessName ; (301_6)(keyMnu_ProcessName)
    DataArray.301.10 := KeyMnu_ProcessPathExtName ; (301_10)(KeyMnu_ProcessPathExtName)
    ;
    DataArray.302.8 := Mnu_ComNum ; (302_8)(Mnu_ComNum [Com_#### or Mkb_#### Used for Icon and Link/ahk Name])
    DataArray.302.2 := Mnu_Number_x000 ; (302_2)(Mnu_Number_x000 [#_X_X_X])
    DataArray.302.3 := Mnu_Number_0x00 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
    DataArray.302.4 := Mnu_Number_00x0 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
    DataArray.302.5 := Mnu_Number_000x ; (302_5)(Mnu_Number_000x [X_X_X_#])
    ; -------------------------------------------
    ; [UPDATE] DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End (Script Type)(mnu)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "ofl") ; (366_5)((ScriptType) [cpl,key,mnu,ofl,pum,run,rwh])
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; Script_Line_2 := ""                         *** EMPTY ***
    ; Script_Line_3 := "x:\Folder"                (303_2)(ofl_FolderPathName [Folder Name With Path])
    ; Script_Line_4 := ""                         *** EMPTY ***
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ;
    ; ------------------------------------------- Script_Line_3
    ofl_FolderPathName := Script_Line_3
    ofl_FolderPathName := StrReplace(ofl_FolderPathName, """", "")
    ; ------------------------------------------- Script_Line_3
    ;
    ; ------------------------------------------- [UPDATE] DataArray
    ofl_FolderName := String_Reverse(ofl_FolderPathName)
    ;
    ofl_FolderName := InStr(ofl_FolderName, "\")
    ofl_FolderName := SubStr(ofl_FolderName, 1, Backslash_Position - 1)
    ofl_FolderName := String_Reverse(ofl_FolderName)
    ; -------------------------------------------
    DataArray.303.2 := ofl_FolderPathName ; (303_2)(ofl_FolderPathName [Folder Name With Path])
    DataArray.303.3 := ofl_FolderName ; (303_3)(ofl_FolderName [Folder Name NO Path])
    ; ------------------------------------------- [UPDATE] DataArray
  } ; End (Script Type)(ofl)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "run")
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
    ; Script_Line_4 := "Run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
    ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; Script_Line_6 := ""                         (Empty)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ;
    ; ------------------------------------------- Script_Line_2
    Obj_Run_AsAdmin_Sel := Script_Line_2
    ; ------------------------------------------- Script_Line_2
    ;
    ; ------------------------------------------- Script_Line_3
    Run_OutTarget := Script_Line_3
    ; ------------------------------------------- Script_Line_3
    if (InStr(run_OutTarget, "Shortcut_RunDefault.ahk") > 0)
    {
      ; -------------------------------------------
      ; In a Short to the Default pum
      ; -------------------------------------------
      ScriptType := "xxx"
      DataArray.366.5 := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      Obj_Run_AsAdmin_Sel := 1
      Run_OutTarget := ""
      Run_Arguments := ""
      Run_OutUseLink := 0
      ; -------------------------------------------
      DataArray.305.17 := 1 ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      ; -------------------------------------------
    }
    else if (InStr(run_OutTarget, "CatPaw.ahk") > 0)
    {
      ; -------------------------------------------
      ; In a Short to the Default pum
      ; -------------------------------------------
      ScriptType := "xxx"
      DataArray.366.5 := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      Obj_Run_AsAdmin_Sel := 1
      Run_OutTarget := ""
      Run_Arguments := ""
      Run_OutUseLink := 0
      ; -------------------------------------------
      DataArray.305.18 := 1 ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
      ; -------------------------------------------
    }
    else
    {
      ; ------------------------------------------- Script_Line_4
      Run_Arguments := Script_Line_4
      ; ------------------------------------------- Script_Line_4
      ;
      ; ------------------------------------------- Script_Line_5
      Run_OutUseLink := Script_Line_5
      ; ------------------------------------------- Script_Line_5
      ;
      Run_OutTarget := StrReplace(run_OutTarget, """", "")
      Run_Arguments := StrReplace(run_Arguments, """", "")
      ;
    }
    ; ------------------------------------------- [UPDATE] DataArray
    DataArray.73.2   := Obj_Run_AsAdmin_Sel ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray.305.11 := Run_OutTarget ; (305_11)(Run_OutTarget [PathExtName])
    DataArray.305.12 := Run_Arguments ; (305_12)(Run_Arguments [Executable Arguments])
    DataArray.305.13 := Run_OutUseLink ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
    ArrayIn := [DataArray.305.11, "", "", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
    FileDel135   := Img_Del135(ArrayIn)
    FileDel254   := Img_Del254(ArrayIn)
    FileError440 := Img_Error440(ArrayIn)
    FileError450 := Img_Error450(ArrayIn)
    FileError460 := Img_Error460(ArrayIn)
    FileError470 := Img_Error470(ArrayIn)
    FileMnu134   := Img_Mnu134(ArrayIn)
    FileMnu137   := Img_Mnu137(ArrayIn)
    FileNew135   := Img_New135(ArrayIn)
    FileNew254   := Img_New254(ArrayIn)
    FileOflIco   := Img_OflIco(ArrayIn)
    FileRunIco   := Img_RunIco(ArrayIn)
    FileRwhIco   := Img_RwhIco(ArrayIn)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    SplitPath, Run_OutTarget, Run_FileNameExt, Run_FolderPath, Run_FileExt, Run_FileName
    ; -------------------------------------------
    Run_FolderPath := Run_FolderPath
    StringLower, Run_FileExt, Run_FileExt
    ; -------------------------------------------
    DataArray.305.2  := Run_FileName ; (305_2)(Run_FileName [Selected File] [Name])
    DataArray.305.3  := Run_FileNameExt ; (305_3)(Run_FileNameExt [Selected File] [Name,Ext])
    DataArray.305.9  := Run_FolderPath ; (305_9)(Run_FolderPath [Folder Path])
    DataArray.305.10 := Run_FileExt ; (305_10)(Run_FileExt WithOut [.])
    ; ------------------------------------------- [UPDATE] DataArray
  } ; End (Script Type)(run)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "rwh")
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\File.ext"              (305_4)(run_FilePathNameExt [Selected File] [Path,Name,Ext])
    ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
    ; Script_Line_5 := ""                         *** EMPTY ***
    ; Script_Line_6 := ""                         *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ;
    ; ------------------------------------------- Script_Line_2
    Obj_Run_AsAdmin_Sel := Script_Line_2
    ; ------------------------------------------- Script_Line_2
    ;
    ; ------------------------------------------- Script_Line_3
    Run_FilePathNameExt := Script_Line_3
    Run_FilePathNameExt := StrReplace(run_FilePathNameExt, """", "")
    ; ------------------------------------------- Script_Line_3
    ;
    ; ------------------------------------------- Script_Line_4
    Rwh_OpeningApp := Script_Line_4
    Rwh_OpeningApp := StrReplace(Rwh_OpeningApp, """", "")
    ; ------------------------------------------- Script_Line_4
    ;
    ; ------------------------------------------- [UPDATE] DataArray
    DataArray.73.2 := Obj_Run_AsAdmin_Sel ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray.305.4 := Run_FilePathNameExt ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
    DataArray.305.5 := Rwh_OpeningApp ; (305_5)(Rwh_OpeningApp [Full File Path])
    ; ------------------------------------------- [UPDATE] DataArray
    ;
    ; -------------------------------------------
    ; ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
    ArrayIn := [DataArray.305.5, "", "", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
    FileDel135   := Img_Del135(ArrayIn)
    FileDel254   := Img_Del254(ArrayIn)
    FileError440 := Img_Error440(ArrayIn)
    FileError450 := Img_Error450(ArrayIn)
    FileError460 := Img_Error460(ArrayIn)
    FileError470 := Img_Error470(ArrayIn)
    FileMnu134   := Img_Mnu134(ArrayIn)
    FileMnu137   := Img_Mnu137(ArrayIn)
    FileNew135   := Img_New135(ArrayIn)
    FileNew254   := Img_New254(ArrayIn)
    FileOflIco   := Img_OflIco(ArrayIn)
    FileRunIco   := Img_RunIco(ArrayIn)
    FileRwhIco   := Img_RwhIco(ArrayIn)
    ; -------------------------------------------
  } ; End (Script Type)(rwh)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (ScriptType = "url") ; (366_5)((ScriptType) [cpl,key,mnu,ofl,pum,run,rwh])
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; Script_Line_2 := "Browser Name from Title"  (307_11)(Url_BrowserTitle [Browser Name from Window Title])
    ; Script_Line_3 := "https://Site.com/"        (307_2)(Url_Address)
    ; Script_Line_4 := *** EMPTY ***
    ; Script_Line_5 := 0/1                        (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
    ; Script_Line_6 := "Web Page Title"           (307)(04)(Url_Title [Web Page Title])
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ;
    ; ------------------------------------------- Script_Line_2
    Url_BrowserTitle := Script_Line_2
    ; ------------------------------------------- Script_Line_2
    ;
    ; ------------------------------------------- Script_Line_3
    ; (307_2)(Url_Address)
    Url_Address := Script_Line_3
    Url_Address := StrReplace(Url_Address, """", "")
    ; ------------------------------------------- Script_Line_3
    ;
    ; ------------------------------------------- Script_Line_5
    ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
    Url_NewTab := Script_Line_5
    ; ------------------------------------------- Script_Line_5
    ;
    ; ------------------------------------------- Script_Line_6
    ; (307)(04)(Url_Title [Web Page Title])
    Url_Title := Script_Line_6
    ; ------------------------------------------- Script_Line_6
    ;
    ; ------------------------------------------- [UPDATE] DataArray
    DataArray.307.11 := Url_BrowserTitle ; (307_11)(Url_BrowserTitle [Browser Name from Window Title])
    DataArray.307.2  := Url_Address ; (307_2)(Url_Address)
    DataArray.307.9  := Url_NewTab ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
    DataArray.307.4  := Url_Title ; (307_4)(Url_Title [Web Page Title])
    ; ------------------------------------------- [UPDATE] DataArray
  } ; End (Script Type)(url)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
