﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Default_Browser.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_069(DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
{
  ; -------------------------------------------
  if (DataArray.69.2 == 2) ; (069_2)(Obj_RwhUrl_OpenWithReset_Sel [0,1,2])
  {
    ; -------------------------------------------
    ; Reset to Default
    ; -------------------------------------------
    if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      ; 1 = Is Use Default
      DataArray.305.8 := 1 ; (305_8)(Rwh_UseAppDefault [0/1])
      DataArray.305.5 := DataArray.305.6 ; (305_5)(Rwh_OpeningApp [Full File Path])/(305_6)(Rwh_DefaultApp [Full File Path])
      ; -------------------------------------------
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (rwh)
    ; -------------------------------------------
  } ; End (069_2) = 2
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
