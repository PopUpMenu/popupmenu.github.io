﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_ItemPosition.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_ReplaceItem.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Subtract.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Display.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Shortcut.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Validate.ahk
#Include C:\Program Files\PopUpMenu_PUM\Gui_AdjustTextWidth.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyArray_SelectKey(Var_Num, DataArray)
{
  ; -------------------------------------------
  if (Var_Num != "")
  {
    ; -------------------------------------------
    GuiControlGet, Obj_EditFeild_StatusBar_Val , , g_122 ; (122_1)(Obj_EditFeild_StatusBar)
    DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    Key_ArrayNumbers := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
    ; Remove Leading 0
    if (Substr(Var_Num, 1, 1) == "0")
    {
      This_Var_Num := Substr(Var_Num, 2)
    }
    ; -------------------------------------------
    if (Substr(Var_Num, 1, 1) == "0")
    {
      This_Var_Num := Substr(Var_Num, 2)
    }
    ; -------------------------------------------
    IsSelected := DataArray[This_Var_Num][2]
    ; -------------------------------------------
    if (IsSelected == 1) ; Select / Disable
    {
      ; -------------------------------------------
      if (Var_Num == "008") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "009") ; (009_1)(GUI Object: [key] Alt Down)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(008)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(008)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(010)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("010", 3, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(011)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("011", 3, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 3, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        DataArray := Image_GuiControl("009", 3, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        DataArray := Image_GuiControl("012", 1, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "010") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(008)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(008)", "(010)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(011)", "(010)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(010)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(009)") == Array_ItemExist(Key_ArrayNumbers, "(012)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
          DataArray := Image_GuiControl("010", 2, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
          DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        else
        {
          DataArray := Image_GuiControl("008", 3, 1, DataArray) ; (008_1)(Obj_Key_Alt)
          DataArray := Image_GuiControl("010", 3, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
          DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "011") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(008)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(008)", "(011)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(010)", "(011)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(011)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(009)") == Array_ItemExist(Key_ArrayNumbers, "(012)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
          DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
          DataArray := Image_GuiControl("011", 2, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        else
        {
          DataArray := Image_GuiControl("008", 3, 1, DataArray) ; (008_1)(Obj_Key_Alt)
          DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
          DataArray := Image_GuiControl("011", 3, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "012") ; (012_1)(GUI Object: [key] Alt Up)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(008)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(010)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(011)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        DataArray := Image_GuiControl("009", 2, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        DataArray := Image_GuiControl("012", 2, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(010)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("010", 2, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        }
        if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("011", 2, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "013") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(013)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("013", 2, 1, DataArray) ; (013_1)(Obj_Key_CapsLock)
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (Var_Num == "014") ; (014_1)(GUI Object: [key] Ctrl Down)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(074)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(074)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(015)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("015", 3, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(016)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("016", 3, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 3, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        DataArray := Image_GuiControl("014", 3, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        DataArray := Image_GuiControl("017", 1, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "015") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(074)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(074)", "(015)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(016)", "(015)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(015)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(014)") == Array_ItemExist(Key_ArrayNumbers, "(017)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
          DataArray := Image_GuiControl("015", 2, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
          DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        else
        {
          DataArray := Image_GuiControl("074", 3, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
          DataArray := Image_GuiControl("015", 3, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
          DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "016") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(074)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(074)", "(016)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(015)", "(016)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(016)", "") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(014)") == Array_ItemExist(Key_ArrayNumbers, "(017)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
          DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
          DataArray := Image_GuiControl("016", 2, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        else
        {
          DataArray := Image_GuiControl("074", 3, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
          DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
          DataArray := Image_GuiControl("016", 3, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "017") ; (017_1)(GUI Object: [key] Ctrl Up)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(074)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(015)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(016)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        DataArray := Image_GuiControl("014", 2, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        DataArray := Image_GuiControl("017", 2, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        
        if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("015", 2, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        }
        if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("016", 2, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "018") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(018)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("018", 2, 1, DataArray) ; (018_1)(Obj_Key_Enter)
        DataArray := Image_GuiControl("019", 1, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        ; -------------------------------------------
      } ; End (018_2)([key] Enter: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "019") ; (019_1)(GUI Object: [key] Enter X2)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(018)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("018", 2, 1, DataArray) ; (018_1)(Obj_Key_Enter)
        DataArray := Image_GuiControl("019", 2, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        ; -------------------------------------------
      } ; End (019_1)(GUI Object: [key] Enter X2)
      ; -------------------------------------------
      else if (Var_Num == "020") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(020)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("020", 2, 1, DataArray) ; (020_1)(Obj_Key_Esc)
        DataArray := Image_GuiControl("021", 1, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        ; -------------------------------------------
      } ; End (020_2)([key] Esc: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "021") ; (021_1)(GUI Object: [key] Esc X2)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(020)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("020", 2, 1, DataArray) ; (020_1)(Obj_Key_Esc)
        DataArray := Image_GuiControl("021", 2, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        ; -------------------------------------------
      } ; End (021_1)(GUI Object: [key] Esc X2)
      ; -------------------------------------------
      else if (Var_Num == "022") ; (022_1)(GUI Object: [key] F1)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(022)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("022", 2, 0, DataArray) ; (022_1)(Obj_Key_F1)
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (Var_Num == "023") ; (023_1)(GUI Object: [key] F2)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(023)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("023", 2, 0, DataArray) ; (023_1)(Obj_Key_F2)
      } ; End (023_1)(GUI Object: [key] F2)
      ; -------------------------------------------
      else if (Var_Num == "024") ; (024_1)(GUI Object: [key] F3)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(024)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("024", 2, 0, DataArray) ; (024_1)(Obj_Key_F3)
      } ; End (024_1)(GUI Object: [key] F3)
      ; -------------------------------------------
      else if (Var_Num == "025") ; (025_1)(GUI Object: [key] F4)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(025)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("025", 2, 0, DataArray) ; (025_1)(Obj_Key_F4)
      } ; End (025_1)(GUI Object: [key] F4)
      ; -------------------------------------------
      else if (Var_Num == "026") ; (026_1)(GUI Object: [key] F5)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(026)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("026", 2, 0, DataArray) ; (026_1)(Obj_Key_F5)
      } ; End (026_1)(GUI Object: [key] F5)
      ; -------------------------------------------
      else if (Var_Num == "027") ; (027_1)(GUI Object: [key] F6)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(027)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("027", 2, 0, DataArray) ; (027_1)(Obj_Key_F6)
      } ; End (027_1)(GUI Object: [key] F6)
      ; -------------------------------------------
      else if (Var_Num == "028") ; (028_1)(GUI Object: [key] F7)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(028)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("028", 2, 0, DataArray) ; (028_1)(Obj_Key_F7)
      } ; End (028_1)(GUI Object: [key] F7)
      ; -------------------------------------------
      else if (Var_Num == "029") ; (029_1)(GUI Object: [key] F8)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(029)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("029", 2, 0, DataArray) ; (029_1)(Obj_Key_F8)
      } ; End (029_1)(GUI Object: [key] F8)
      ; -------------------------------------------
      else if (Var_Num == "030") ; (030_1)(GUI Object: [key] F9)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(030)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("030", 2, 0, DataArray) ; (030_1)(Obj_Key_F9)
      } ; End (030_1)(GUI Object: [key] F9)
      ; -------------------------------------------
      else if (Var_Num == "031") ; (031_1)(GUI Object: [key] F10)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(031)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("031", 2, 0, DataArray) ; (031_1)(Obj_Key_F10)
      } ; End (031_1)(GUI Object: [key] F10)
      ; -------------------------------------------
      else if (Var_Num == "032") ; (032_1)(GUI Object: [key] F11)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(032)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("032", 2, 0, DataArray) ; (032_1)(Obj_Key_F11)
      } ; End (032_1)(GUI Object: [key] F11)
      ; -------------------------------------------
      else if (Var_Num == "033") ; (033_1)(GUI Object: [key] F12)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(033)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("033", 2, 0, DataArray) ; (033_1)(Obj_Key_F12)
      } ; End (033_1)(GUI Object: [key] F12)
      ; -------------------------------------------
      else if (Var_Num == "034") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(034)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("034", 2, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
      } ; End (034_1)(GUI Object: [key] Numpad 0)
      ; -------------------------------------------
      else if (Var_Num == "035") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(035)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("035", 2, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
      } ; End (035_1)(GUI Object: [key] Numpad 1)
      ; -------------------------------------------
      else if (Var_Num == "036") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(036)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("036", 2, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
      } ; End (036_1)(GUI Object: [key] Numpad 2)
      ; -------------------------------------------
      else if (Var_Num == "037") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(037)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("037", 2, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
      } ; End (037_1)(GUI Object: [key] Numpad 3)
      ; -------------------------------------------
      else if (Var_Num == "038") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(038)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("038", 2, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
      } ; End (038_1)(GUI Object: [key] Numpad 4)
      ; -------------------------------------------
      else if (Var_Num == "039") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(039)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("039", 2, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
      } ; End (039_1)(GUI Object: [key] Numpad 5)
      ; -------------------------------------------
      else if (Var_Num == "040") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(040)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("040", 2, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
      } ; End (040_1)(GUI Object: [key] Numpad 6)
      ; -------------------------------------------
      else if (Var_Num == "041") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(041)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("041", 2, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
      } ; End (041_1)(GUI Object: [key] Numpad 7)
      ; -------------------------------------------
      else if (Var_Num == "042") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(042)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("042", 2, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
      } ; End (042_1)(GUI Object: [key] Numpad 8)
      ; -------------------------------------------
      else if (Var_Num == "043") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(043)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("043", 2, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
      } ; End (043_1)(GUI Object: [key] Numpad 9)
      ; -------------------------------------------
      else if (Var_Num == "044") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(044)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("044", 2, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
      } ; End (044_1)(GUI Object: [key] Numpad Add)
      ; -------------------------------------------
      else if (Var_Num == "045") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(045)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("045", 2, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
      } ; End (045_1)(GUI Object: [key] Numpad Divide)
      ; -------------------------------------------
      else if (Var_Num == "046") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(046)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("046", 2, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
      } ; End (046_1)(GUI Object: [key] Numpad Dot)
      ; -------------------------------------------
      else if (Var_Num == "047") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(047)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("047", 2, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
      } ; End (047_1)(GUI Object: [key] Numpad Enter)
      ; -------------------------------------------
      else if (Var_Num == "048") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(048)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("048", 2, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
      } ; End (048_1)(GUI Object: [key] Numpad Multiply)
      ; -------------------------------------------
      else if (Var_Num == "049") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(049)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        DataArray := Image_GuiControl("049", 2, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
      } ; End (049_1)(GUI Object: [key] Numpad Subtract)
      ; -------------------------------------------
      else if (Var_Num == "050") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "051") ; (051_1)(GUI Object: [key] Shift Down)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(050)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(050)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(052)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("052", 3, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(053)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("053", 3, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 3, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        DataArray := Image_GuiControl("051", 3, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        DataArray := Image_GuiControl("054", 1, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "052") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(050)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(050)", "(052)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(053)", "(052)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(052)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(051)") == Array_ItemExist(Key_ArrayNumbers, "(054)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
          DataArray := Image_GuiControl("052", 2, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
          DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        else
        {
          DataArray := Image_GuiControl("050", 3, 1, DataArray) ; (050_1)(Obj_Key_Shift)
          DataArray := Image_GuiControl("052", 3, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
          DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "053") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(050)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(050)", "(053)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(052)", "(053)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(053)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(051)") == Array_ItemExist(Key_ArrayNumbers, "(054)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
          DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
          DataArray := Image_GuiControl("053", 2, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        else
        {
          DataArray := Image_GuiControl("050", 3, 1, DataArray) ; (050_1)(Obj_Key_Shift)
          DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
          DataArray := Image_GuiControl("053", 3, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "054") ; (054_1)(GUI Object: [key] Shift Up)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(050)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(052)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(053)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        DataArray := Image_GuiControl("051", 2, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        DataArray := Image_GuiControl("054", 2, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        
        if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("052", 2, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        }
        if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("053", 2, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "055") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(055)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("055", 2, 1, DataArray) ; (055_1)(Obj_Key_Tab)
        DataArray := Image_GuiControl("056", 1, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        ; -------------------------------------------
      } ; End (055_2)([key] Tab: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "056") ; (056_1)(GUI Object: [key] Tab X2)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(055)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("055", 2, 1, DataArray) ; (055_1)(Obj_Key_Tab)
        DataArray := Image_GuiControl("056", 2, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        ; -------------------------------------------
      } ; End (056_1)(GUI Object: [key] Tab X2)
      ; -------------------------------------------
      else if (Var_Num == "057") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 2, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "058") ; (058_1)(GUI Object: [key] Windows Key Down)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(057)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(057)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(059)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("059", 3, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(060)", 1) ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", ThisPos + 1) ; (301_2)(Key_ArrayNumbers [Array])
          ; -------------------------------------------
          DataArray := Image_GuiControl("060", 3, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 3, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        DataArray := Image_GuiControl("058", 3, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        DataArray := Image_GuiControl("061", 1, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "059") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(057)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(057)", "(059)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(060)", "(059)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(059)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(058)") == Array_ItemExist(Key_ArrayNumbers, "(061)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("057", 2, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
          DataArray := Image_GuiControl("059", 2, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
          DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        else
        {
          DataArray := Image_GuiControl("057", 3, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
          DataArray := Image_GuiControl("059", 3, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
          DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "060") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(057)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(057)", "(060)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(059)", "(060)") ; (301_2)(Key_ArrayNumbers [Array])
        }
        else
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(060)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(058)") == Array_ItemExist(Key_ArrayNumbers, "(061)")) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("057", 2, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
          DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
          DataArray := Image_GuiControl("060", 2, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        else
        {
          DataArray := Image_GuiControl("057", 3, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
          DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
          DataArray := Image_GuiControl("060", 3, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "061") ; (061_1)(GUI Object: [key] Windows Key Up)
      {
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(057)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(061)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(059)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(061)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        else if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(060)", "End") ; (301_2)(Key_ArrayNumbers [Array])
          Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(061)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 2, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        DataArray := Image_GuiControl("058", 2, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        DataArray := Image_GuiControl("061", 2, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        
        if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("059", 2, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        }
        if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("060", 2, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "074") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "075") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(075)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("075", 2, 1, DataArray) ; (075_1)(Obj_Key_Delete)
        ; -------------------------------------------
      } ; End (075_1)(GUI Object: [key] Delete)
      ; -------------------------------------------
      else if (Var_Num == "076") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(076)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("076", 2, 1, DataArray) ; (076_1)(Obj_Key_End)
        ; -------------------------------------------
      } ; End (076_1)(GUI Object: [key] End)
      ; -------------------------------------------
      else if (Var_Num == "077") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(077)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("077", 2, 1, DataArray) ; (077_1)(Obj_Key_Home)
        ; -------------------------------------------
      } ; End (077_1)(GUI Object: [key] Home)
      ; -------------------------------------------
      else if (Var_Num == "078") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(078)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("078", 2, 1, DataArray) ; (078_1)(Obj_Key_Insert)
        ; -------------------------------------------
      } ; End (078_1)(GUI Object: [key] Insert)
      ; -------------------------------------------
      else if (Var_Num == "079") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(079)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("079", 2, 1, DataArray) ; (079_1)(Obj_Key_PgDn)
        ; -------------------------------------------
      } ; End (079_1)(GUI Object: [key] Page Down)
      ; -------------------------------------------
      else if (Var_Num == "080") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(080)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("080", 2, 1, DataArray) ; (080_1)(Obj_Key_PgUp)
        ; -------------------------------------------
      } ; End (080_1)(GUI Object: [key] Page Up)
      ; -------------------------------------------
    } ; End if (IsSelected == 1) ; Select
    ; -------------------------------------------
    else if (IsSelected == 2 or IsSelected == 3) ; UnSelect / Disable
    {
      ; -------------------------------------------
      if (Var_Num == "008") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(008)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(009)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(010)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(011)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(012)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 1, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        DataArray := Image_GuiControl("009", 1, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        DataArray := Image_GuiControl("012", 0, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        ; -------------------------------------------
      } ; End (008_1)(GUI Object: [key] Alt)
      ; -------------------------------------------
      else if (Var_Num == "009") ; (009_1)(GUI Object: [key] Alt Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(009)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(012)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(008)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(010)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(011)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        DataArray := Image_GuiControl("009", 1, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        DataArray := Image_GuiControl("012", 0, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("010", 2, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("011", 2, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        ; -------------------------------------------
      } ; End (009_1)(GUI Object: [key] Alt Down)
      ; -------------------------------------------
      else if (Var_Num == "010") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(010)", "(008)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        ; -------------------------------------------
      } ; End (010_1)(GUI Object: [key] Alt Left)
      ; -------------------------------------------
      else if (Var_Num == "011") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(011)", "(008)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        ; -------------------------------------------
      } ; End (011_1)(GUI Object: [key] Alt Right)
      ; -------------------------------------------
      else if (Var_Num == "012") ; (012_1)(GUI Object: [key] Alt Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(008)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(010)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(011)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(012)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("010", 3, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("011", 3, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("008", 3, 1, DataArray) ; (008_1)(Obj_Key_Alt)
        DataArray := Image_GuiControl("009", 3, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        DataArray := Image_GuiControl("012", 1, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        ; -------------------------------------------
      } ; End (012_1)(GUI Object: [key] Alt Up)
      ; -------------------------------------------
      else if (Var_Num == "013") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(013)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("013", 1, 1, DataArray) ; (013_1)(Obj_Key_CapsLock)
        ; -------------------------------------------
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (Var_Num == "014") ; (014_1)(GUI Object: [key] Ctrl Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(014)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(017)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(015)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(016)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(074)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        DataArray := Image_GuiControl("014", 1, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        DataArray := Image_GuiControl("017", 0, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("015", 2, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("016", 2, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "015") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(015)", "(074)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "016") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(016)", "(074)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "017") ; (017_1)(GUI Object: [key] Ctrl Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(074)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(015)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(016)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(017)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("015", 3, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("016", 3, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 3, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        DataArray := Image_GuiControl("014", 3, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        DataArray := Image_GuiControl("017", 1, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "018") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(018)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("018", 1, 1, DataArray) ; (018_1)(Obj_Key_Enter)
        DataArray := Image_GuiControl("019", 0, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        ; -------------------------------------------
      } ; End (018_2)([key] Enter: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "019") ; (019_1)(GUI Object: [key] Enter X2)
      {
        ; -------------------------------------------
        ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(018)", 1) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(018)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(018)", ThisPos) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("018", 2, 1, DataArray) ; (018_1)(Obj_Key_Enter)
        DataArray := Image_GuiControl("019", 1, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        ; -------------------------------------------
      } ; End (019_1)(GUI Object: [key] Enter X2)
      ; -------------------------------------------
      else if (Var_Num == "020") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(020)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("020", 1, 1, DataArray) ; (020_1)(Obj_Key_Esc)
        DataArray := Image_GuiControl("021", 0, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        ; -------------------------------------------
      } ; End (020_2)([key] Esc: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "021") ; (021_1)(GUI Object: [key] Esc X2)
      {
        ; -------------------------------------------
        ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(020)", 1) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(020)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(020)", ThisPos) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("020", 2, 1, DataArray) ; (020_1)(Obj_Key_Esc)
        DataArray := Image_GuiControl("021", 1, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        ; -------------------------------------------
      } ; End (021_1)(GUI Object: [key] Esc X2)
      ; -------------------------------------------
      else if (Var_Num == "022") ; (022_1)(GUI Object: [key] F1)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(022)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("022", 1, 0, DataArray) ; (022_1)(Obj_Key_F1)
        ; -------------------------------------------
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (Var_Num == "023") ; (023_1)(GUI Object: [key] F2)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(023)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("023", 1, 0, DataArray) ; (023_1)(Obj_Key_F2)
        ; -------------------------------------------
      } ; End (023_1)(GUI Object: [key] F2)
      ; -------------------------------------------
      else if (Var_Num == "024") ; (024_1)(GUI Object: [key] F3)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(024)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("024", 1, 0, DataArray) ; (024_1)(Obj_Key_F3)
        ; -------------------------------------------
      } ; End (024_1)(GUI Object: [key] F3)
      ; -------------------------------------------
      else if (Var_Num == "025") ; (025_1)(GUI Object: [key] F4)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(025)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("025", 1, 0, DataArray) ; (025_1)(Obj_Key_F4)
        ; -------------------------------------------
      } ; End (025_1)(GUI Object: [key] F4)
      ; -------------------------------------------
      else if (Var_Num == "026") ; (026_1)(GUI Object: [key] F5)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(026)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("026", 1, 0, DataArray) ; (026_1)(Obj_Key_F5)
        ; -------------------------------------------
      } ; End (026_1)(GUI Object: [key] F5)
      ; -------------------------------------------
      else if (Var_Num == "027") ; (027_1)(GUI Object: [key] F6)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(027)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("027", 1, 0, DataArray) ; (027_1)(Obj_Key_F6)
        ; -------------------------------------------
      } ; End (027_1)(GUI Object: [key] F6)
      ; -------------------------------------------
      else if (Var_Num == "028") ; (028_1)(GUI Object: [key] F7)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(028)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("028", 1, 0, DataArray) ; (028_1)(Obj_Key_F7)
        ; -------------------------------------------
      } ; End (028_1)(GUI Object: [key] F7)
      ; -------------------------------------------
      else if (Var_Num == "029") ; (029_1)(GUI Object: [key] F8)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(029)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("029", 1, 0, DataArray) ; (029_1)(Obj_Key_F8)
        ; -------------------------------------------
      } ; End (029_1)(GUI Object: [key] F8)
      ; -------------------------------------------
      else if (Var_Num == "030") ; (030_1)(GUI Object: [key] F9)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(030)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("030", 1, 0, DataArray) ; (030_1)(Obj_Key_F9)
        ; -------------------------------------------
      } ; End (030_1)(GUI Object: [key] F9)
      ; -------------------------------------------
      else if (Var_Num == "031") ; (031_1)(GUI Object: [key] F10)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(031)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("031", 1, 0, DataArray) ; (031_1)(Obj_Key_F10)
        ; -------------------------------------------
      } ; End (031_1)(GUI Object: [key] F10)
      ; -------------------------------------------
      else if (Var_Num == "032") ; (032_1)(GUI Object: [key] F11)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(032)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("032", 1, 0, DataArray) ; (032_1)(Obj_Key_F11)
        ; -------------------------------------------
      } ; End (032_1)(GUI Object: [key] F11)
      ; -------------------------------------------
      else if (Var_Num == "033") ; (033_1)(GUI Object: [key] F12)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(033)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("033", 1, 0, DataArray) ; (033_1)(Obj_Key_F12)
        ; -------------------------------------------
      } ; End (033_1)(GUI Object: [key] F12)
      ; -------------------------------------------
      else if (Var_Num == "034") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(034)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("034", 1, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
        ; -------------------------------------------
      } ; End (034_1)(GUI Object: [key] Numpad 0)
      ; -------------------------------------------
      else if (Var_Num == "035") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(035)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("035", 1, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
        ; -------------------------------------------
      } ; End (035_1)(GUI Object: [key] Numpad 1)
      ; -------------------------------------------
      else if (Var_Num == "036") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(036)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("036", 1, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
        ; -------------------------------------------
      } ; End (036_1)(GUI Object: [key] Numpad 2)
      ; -------------------------------------------
      else if (Var_Num == "037") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(037)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("037", 1, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
        ; -------------------------------------------
      } ; End (037_1)(GUI Object: [key] Numpad 3)
      ; -------------------------------------------
      else if (Var_Num == "038") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(038)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("038", 1, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
        ; -------------------------------------------
      } ; End (038_1)(GUI Object: [key] Numpad 4)
      ; -------------------------------------------
      else if (Var_Num == "039") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(039)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("039", 1, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
        ; -------------------------------------------
      } ; End (039_1)(GUI Object: [key] Numpad 5)
      ; -------------------------------------------
      else if (Var_Num == "040") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(040)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("040", 1, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
        ; -------------------------------------------
      } ; End (040_1)(GUI Object: [key] Numpad 6)
      ; -------------------------------------------
      else if (Var_Num == "041") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(041)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("041", 1, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
        ; -------------------------------------------
      } ; End (041_1)(GUI Object: [key] Numpad 7)
      ; -------------------------------------------
      else if (Var_Num == "042") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(042)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("042", 1, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
        ; -------------------------------------------
      } ; End (042_1)(GUI Object: [key] Numpad 8)
      ; -------------------------------------------
      else if (Var_Num == "043") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(043)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("043", 1, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
        ; -------------------------------------------
      } ; End (043_1)(GUI Object: [key] Numpad 9)
      ; -------------------------------------------
      else if (Var_Num == "044") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(044)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("044", 1, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
        ; -------------------------------------------
      } ; End (044_1)(GUI Object: [key] Numpad Add)
      ; -------------------------------------------
      else if (Var_Num == "045") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(045)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("045", 1, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
        ; -------------------------------------------
      } ; End (045_1)(GUI Object: [key] Numpad Divide)
      ; -------------------------------------------
      else if (Var_Num == "046") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(046)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("046", 1, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
        ; -------------------------------------------
      } ; End (046_1)(GUI Object: [key] Numpad Dot)
      ; -------------------------------------------
      else if (Var_Num == "047") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(047)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("047", 1, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
        ; -------------------------------------------
      } ; End (047_1)(GUI Object: [key] Numpad Enter)
      ; -------------------------------------------
      else if (Var_Num == "048") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(048)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("048", 1, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
        ; -------------------------------------------
      } ; End (048_1)(GUI Object: [key] Numpad Multiply)
      ; -------------------------------------------
      else if (Var_Num == "049") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(049)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("049", 1, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
        ; -------------------------------------------
      } ; End (049_1)(GUI Object: [key] Numpad Subtract)
      ; -------------------------------------------
      else if (Var_Num == "050") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(050)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(051)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(054)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(052)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(053)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 1, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        DataArray := Image_GuiControl("051", 1, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        DataArray := Image_GuiControl("054", 0, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "051") ; (051_1)(GUI Object: [key] Shift Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(051)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(054)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(050)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(052)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(053)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        DataArray := Image_GuiControl("051", 1, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        DataArray := Image_GuiControl("054", 0, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("052", 2, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("053", 2, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "052") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(052)", "(050)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "053") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(053)", "(050)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "054") ; (054_1)(GUI Object: [key] Shift Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(050)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(052)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(053)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(054)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("052", 3, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("053", 3, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("050", 3, 1, DataArray) ; (050_1)(Obj_Key_Shift)
        DataArray := Image_GuiControl("051", 3, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        DataArray := Image_GuiControl("054", 1, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "055") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(055)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("055", 1, 1, DataArray) ; (055_1)(Obj_Key_Tab)
        DataArray := Image_GuiControl("056", 0, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        ; -------------------------------------------
      } ; End (055_2)([key] Tab: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "056") ; (056_1)(GUI Object: [key] Tab X2)
      {
        ; -------------------------------------------
        ThisPos := Array_ItemPosition(Key_ArrayNumbers, "(055)", 1) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(055)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(055)", ThisPos) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("055", 2, 1, DataArray) ; (055_1)(Obj_Key_Tab)
        DataArray := Image_GuiControl("056", 1, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        ; -------------------------------------------
      } ; End (056_1)(GUI Object: [key] Tab X2)
      ; -------------------------------------------
      else if (Var_Num == "057") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(057)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(058)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(061)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(059)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(060)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 1, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        DataArray := Image_GuiControl("058", 1, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        DataArray := Image_GuiControl("061", 0, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "058") ; (058_1)(GUI Object: [key] Windows Key Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(058)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(061)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(057)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(059)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(060)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 2, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        DataArray := Image_GuiControl("058", 1, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        DataArray := Image_GuiControl("061", 0, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("059", 2, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("060", 2, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "059") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(059)", "(057)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "060") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, "(060)", "(057)") ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "061") ; (061_1)(GUI Object: [key] Windows Key Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(057)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(059)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(060)", 2) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(061)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("059", 3, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        }
        else if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0) ; (301_2)(Key_ArrayNumbers [Array])
        {
          DataArray := Image_GuiControl("060", 3, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("057", 3, 1, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        DataArray := Image_GuiControl("058", 3, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        DataArray := Image_GuiControl("061", 1, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "074") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(074)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(014)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(017)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(015)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(016)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("074", 1, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
        DataArray := Image_GuiControl("014", 1, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        DataArray := Image_GuiControl("017", 0, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "075") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(075)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("075", 1, 1, DataArray) ; (075_1)(Obj_Key_Delete)
        ; -------------------------------------------
      } ; End (075_1)(GUI Object: [key] Delete)
      ; -------------------------------------------
      else if (Var_Num == "076") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(076)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("076", 1, 1, DataArray) ; (076_1)(Obj_Key_End)
        ; -------------------------------------------
      } ; End (076_1)(GUI Object: [key] End)
      ; -------------------------------------------
      else if (Var_Num == "077") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(077)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("077", 1, 1, DataArray) ; (077_1)(Obj_Key_Home)
        ; -------------------------------------------
      } ; End (077_1)(GUI Object: [key] Home)
      ; -------------------------------------------
      else if (Var_Num == "078") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(078)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("078", 1, 1, DataArray) ; (078_1)(Obj_Key_Insert)
        ; -------------------------------------------
      } ; End (078_1)(GUI Object: [key] Insert)
      ; -------------------------------------------
      else if (Var_Num == "079") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(079)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("079", 1, 1, DataArray) ; (079_1)(Obj_Key_PgDn)
        ; -------------------------------------------
      } ; End (079_1)(GUI Object: [key] Page Down)
      ; -------------------------------------------
      else if (Var_Num == "080") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, "(080)", 0) ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        DataArray := Image_GuiControl("080", 1, 1, DataArray) ; (080_1)(Obj_Key_PgUp)
        ; -------------------------------------------
      } ; End (080_1)(GUI Object: [key] Page Up)
      ; -------------------------------------------
    } ; End else if (IsSelected == 2 or IsSelected == 3) ; Was (2 == Sel)/(3 == Dis) [SET] (1 == Nor)
    ; -------------------------------------------
    DataArray.301.2 := Key_ArrayNumbers ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
    if (DataArray.301.2.1 != "") ; (301_2)(Key_ArrayNumbers [Array])
    {
      ; -------------------------------------------
      ; Creates
      ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Display(DataArray) ; > DataArray
      ; -------------------------------------------
      ; Creates
      ; (301_8)([key] KeyArray_Keystroke [Array] for Shortcut)
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Shortcut(DataArray) ; > DataArray
      ; -------------------------------------------
      Key_KeyArrayDisplay := DataArray.301.7 ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
      ; -------------------------------------------
      DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
      DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
      ; -------------------------------------------
      DataArray := KeyArray_Validate(DataArray)
      Key_ArrayValid := DataArray.301.3 ; (301_3)(Key_ArrayValid [1,3])
      ; -------------------------------------------
      if (Key_ArrayValid == 1) ; (301_3)(Key_ArrayValid [1,3])
      {
        FontColor := "199524" ; (Green)
        DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      }
      else
      {
        FontColor := "a30404" ; (Red)
        if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
        }
      }
      FontSize := 12
      MaxWidth := 480
      ; (105_1)(GUI Object: <Displayed Text> Top 2)
      Gui_AdjustTextWidth("g_105", Key_KeyArrayDisplay, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
      ; -------------------------------------------
    } ; (301_2)([key] KeyArray_Numbers [Array]) [IS NOT EMPTY]
    ; -------------------------------------------
    else ; (301_2)([key] KeyArray_Numbers [Array]) [IS EMPTY]
    {
      ; -------------------------------------------
      DataArray.301.7 := "" ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
      DataArray.301.8 := "" ; (301_8)(Key_KeyArrayShortcut [Array])
      DataArray := Image_GuiControl("105", 0, 0, DataArray) ; (105_1)(Obj_DisplayText_Top2)
      ; -------------------------------------------
    } ; End (301_2)([key] KeyArray_Numbers [Array]) [IS EMPTY]
    ; -------------------------------------------
  } ; End if (Var_Num != "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
