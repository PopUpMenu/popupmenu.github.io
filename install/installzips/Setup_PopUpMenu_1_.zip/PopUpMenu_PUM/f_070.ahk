﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Cpl_MenuArray.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_070(DataArray) ; (070_1)(Obj_Cpl_WinControl)
{
  ; -------------------------------------------
  v_070_2 := DataArray.70.2 ; (070_2)(Obj_Cpl_WinControl_Sel [0,1,2,3])
  if (v_070_2 == 1) ; (070_2)(Obj_Cpl_WinControl_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.366.5 := "cpl" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    if (DataArray.300.2 == 0 or DataArray.300.2 == "") ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    {
      DataArray.300.2 := 0 ; (300_2)(Cpl_Number_x000 [#_X_X_X])
      DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
      DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
      DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
      DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
      DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
      DataArray := Image_GuiControl("110", 0, 0, DataArray) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
      DataArray := Image_GuiControl("111", 0, 0, DataArray) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
      DataArray := Image_GuiControl("112", 0, 0, DataArray) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
    }
    ; -------------------------------------------
    DataArray := Cpl_MenuArray(DataArray)
    ; -------------------------------------------
    ; (087_1)(Obj_Mnu_Menu)
    DataArray := Image_GuiControl("070", 2, 1, DataArray) ; (070_1)(Obj_Cpl_WinControl)
    DataArray := Image_GuiControl("085", 1, 1, DataArray) ; (085_1)(Obj_Key_Keyboard)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (070_2)([cpl] Select Control: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
