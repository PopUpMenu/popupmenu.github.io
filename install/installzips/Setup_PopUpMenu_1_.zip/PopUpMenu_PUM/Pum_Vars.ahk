﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Vars(DataArray) ; > DataArray
{ ; Pum Image Settings
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [START UP]  Vars
    ; -------------------------------------------
    { ; [GET] Vars
      ; -------------------------------------------
      ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
      XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
      ; -------------------------------------------
      Img_W          := DataArray.362.34 ; (362_34)(Img_W)
      Img_H          := DataArray.362.35 ; (362_35)(Img_H)
      Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
      Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
      bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
      Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
      Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
      Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
      Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
      PumBody_H      := DataArray.362.43 ; (362_43)((ImgChange_Array [Image Change [Array])
      Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
      Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
      Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
      Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
      Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
      Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
      Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
      Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
      bg_Selected_Rotate    := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
      ; -------------------------------------------
    } ; End [GET] Vars
    ; -------------------------------------------
    ImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
    ; -------------------------------------------
    Info_bg := ThisPumProcessFolder "\image\Info_bg.txt" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    File_PumFrame := "C:\Program Files\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
    ; -------------------------------------------
    bg_Selected_Bmp     := ThisPumProcessFolder "\image\bg_Selected_Bmp.bmp" ; (361)(8)(Pum [Specific Folder Path])
    bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Selected_Fit     := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
    Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    bg_Display_Img       := ThisPumProcessFolder "\image\bg_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Display_Txt_Col   := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    bg_Display_Txt_Img   := ThisPumProcessFolder "\image\bg_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    File_Pum_Gui         := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
  } ; End [START UP] Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  FileDelete, %File_Pum_Gui%
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (bg_Image_Type == "C")
  {
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] (Img_Gui_[W,H]) (Pum_[W,H] | [SET] (Pum_Gui_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
    ; -------------------------------------------
    WinInWin_Array := Pum_WinInWinMaxSize(Img_Gui_W, Img_Gui_H, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
    ; -------------------------------------------
    Pum_Gui_W := WinInWin_Array.1
    Pum_Gui_H := WinInWin_Array.2
    ; -------------------------------------------
    Pum_Gui_Max_W := WinInWin_Array.1
    Pum_Gui_Max_H := WinInWin_Array.2
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_[W,H]) | [SET] (Pum_Gui_[X,Y])
    ; -------------------------------------------
    Pum_Gui_X := (Img_Gui_W - Pum_Gui_W) / 2
    Pum_Gui_Y := (Img_Gui_H - Pum_Gui_H) / 2
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End (bg_Image_Type == "C")
  else if (bg_Image_Type == "F")
  {
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] (Pum_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
    ; -------------------------------------------
    WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
    ; -------------------------------------------
    Pum_Gui_Max_W := WinInWin_Array.1
    Pum_Gui_Max_H := WinInWin_Array.2
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End (bg_Image_Type == "F")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [UPDATE] Vars
    ; -------------------------------------------
    DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ; -------------------------------------------
    DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
    DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
    DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
    ; -------------------------------------------
    DataArray.362.34 := Img_W ; (362_34)(Img_W)
    DataArray.362.35 := Img_H ; (362_35)(Img_H)
    DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
    DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
    DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
    DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
    DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
    DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
    DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
    DataArray.362.43 := PumBody_H ; (362_43)((ImgChange_Array [Image Change [Array])
    DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
    DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
    DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
    DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
    DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
    DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
    DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
    DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
    ; -------------------------------------------
  } ; End [UPDATE] Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum Image Settings
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
