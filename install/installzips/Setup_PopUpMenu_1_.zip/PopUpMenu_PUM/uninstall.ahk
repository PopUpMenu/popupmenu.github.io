﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Uninstall PopUpMenu
; Text Color 2e0e0e
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Vars
; -------------------------------------------
TextColor := "47023C" ; Purple/Black
ColorTrans := "000000" ; Black
ImagePath := "C:\Program Files\PopUpMenu_PUM\image\uninstall"
; -------------------------------------------
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
GuiFont := "Arial"
global KeepData := 1
; -------------------------------------------
; Vars
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; User Language [GET] (UserLang)
; -------------------------------------------
if FileExist(File_UserLang)
{
  FileReadLINE, UserLang, %File_UserLang%, 1
}
if (UserLang == "")
{
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileDelete, %File_UserLang%
    Sleep, 100
  } ; [End] if FileExist(File_UserLang)
  ; -------------------------------------------
  if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
  {
    ; -------------------------------------------
    UserLang := "de"
    ; -------------------------------------------
  } ; [End] German (de)
  ; -------------------------------------------
  else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] English (en)
  ; -------------------------------------------
  else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
  {
    ; -------------------------------------------
    UserLang := "es"
    ; -------------------------------------------
  } ; [End] Spanish (es)
  ; -------------------------------------------
  else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
  {
    ; -------------------------------------------
    UserLang := "fr"
    ; -------------------------------------------
  } ; [End] French (fr)
  ; -------------------------------------------
  else if (A_Language == "0410" or A_Language == "0810")
  {
    ; -------------------------------------------
    UserLang := "it"
    ; -------------------------------------------
  } ; [End] Italian (it)
  ; -------------------------------------------
  else if (A_Language == "0415")
  {
    ; -------------------------------------------
    UserLang := "pl"
    ; -------------------------------------------
  } ; [End] Polish (pl)
  ; -------------------------------------------
  else if (A_Language == "0416" or A_Language == "0816")
  {
    ; -------------------------------------------
    UserLang := "pt"
    ; -------------------------------------------
  } ; [End] Portuguese (pt)
  ; -------------------------------------------
  else if (A_Language == "0419")
  {
    ; -------------------------------------------
    UserLang := "ru"
    ; -------------------------------------------
  } ; [End] Russian (ru)
  ; -------------------------------------------
  else if (A_Language == "041d" or A_Language == "081d")
  {
    ; -------------------------------------------
    UserLang := "sv"
    ; -------------------------------------------
  } ; [End] Swedish (sv)
  ; -------------------------------------------
  else if (A_Language == "041f")
  {
    ; -------------------------------------------
    UserLang := "tr"
    ; -------------------------------------------
  } ; [End] Turkish (tr)
  ; -------------------------------------------
  else ; English (en)
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] else ; English (en)
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
} ; [End] if (UserLang == "")
; -------------------------------------------
; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Display Gui
; -------------------------------------------
if (A_IsAdmin == 1) ; UUser Has AdMin Rights
{
  ; -------------------------------------------
  Gui, Margin , 0, 0
  ; -------------------------------------------
  Gui, Add, Picture, x0   y0   w460 h354 vGUI_BackgroundImage,                           %ImagePath%\Background.png
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Gui, Add, Picture, x10  y120 w440 h40  vGUI_TextUnInstall,                             %ImagePath%\TextUninstall_%UserLang%.png
  Gui, Add, Picture, x10  y161 w440 h50  vGUI_TextUserData     gLABEL_TextUserData,      %ImagePath%\TextKeep_%UserLang%.png
  Gui, Add, Picture, x10  y213 w440 h80  vGUI_TextInfo,                                  %ImagePath%\TextInfo_%UserLang%.png
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Gui, Add, Picture, x30  y300 w100 h35  vGUI_Cancel            gLABEL_ButtonCancel,     %ImagePath%\ButtonCancel.png
  Gui, Add, Picture, x330 y300 w100 h35  vGUI_Ok                gLABEL_ButtonOk,         %ImagePath%\ButtonOk.png
  ; -------------------------------------------
  Gui, Color, %ColorTrans%
  ; -------------------------------------------
  Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
  Winset, TransColor, %ColorTrans%,
  Gui, Show
  ; -------------------------------------------
  return
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  LABEL_TextUserData:
  {
    ; -------------------------------------------
    if (KeepData == 1)
    {
      global KeepData := 0
      GuiControl, , GUI_TextUserData, %ImagePath%\TextDelete_%UserLang%.png
    }
    else if (KeepData == 0)
    {
      global KeepData := 1
      GuiControl, , GUI_TextUserData, %ImagePath%\TextKeep_%UserLang%.png
    }
    ; -------------------------------------------
    GuiControl, Show, GUI_TextUserData
    ; -------------------------------------------
  }
  return
  ; -------------------------------------------
  LABEL_ButtonOk:
  {
    ; -------------------------------------------
    TempPath := A_Temp "\PopUpMenu_Uninstall"
    if !FileExist(TempPath)
    {
      FileCreateDir, %TempPath%
      Sleep, 500
    }
    ; -------------------------------------------
    FileExtName := "Uninstalling_" UserLang ".png"
    CopyThis := ImagePath "\" FileExtName
    CopyHere := TempPath "\" FileExtName
    ; -------------------------------------------
    FileCopy, %CopyThis%, %CopyHere%, 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    GuiControl, Hide, GUI_Ok
    GuiControl, Hide, GUI_Cancel
    GuiControl, Hide, GUI_TextUnInstall
    GuiControl, Hide, GUI_TextUserData
    GuiControl, Hide, GUI_TextInfo
    ; -------------------------------------------
    GuiControl, , GUI_BackgroundImage, %CopyHere%
    GuiControl, Show, GUI_BackgroundImage
    Sleep, 500
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Close scripts
    ; -------------------------------------------
    ThisScript := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
    DetectHiddenWindows, On
    PostMessage, 0x111, 65305,,, %ThisScript% ahk_class AutoHotkey  ; Suspend
    PostMessage, 0x111, 65306,,, %ThisScript% ahk_class AutoHotkey  ; Pause
    WinClose, %ThisScript% ahk_class AutoHotkey
    ; -------------------------------------------
    ; Close scripts
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (KeepData == 0) ; Delete User Data
    {
			; -------------------------------------------
      FilePath := A_AppData
      SplitPath, FilePath, , , , , OutDrive
      ; -------------------------------------------
      FilePath := OutDrive "\Users\*.*"
      Array_PumFolder := ""
      ; -------------------------------------------
		  ;
      ; -------------------------------------------
      Loop Files, %FilePath%, D ; (Array_PumFolder) All User Pum Folder Array
      {
    	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	      ; REMOVE (pums)
        ; -------------------------------------------
        ThisFolderPath := A_LoopFileFullPath
        SplitPath, ThisFolderPath, , , , UserName
        ; -------------------------------------------
        ThisFile := OutDrive "\Users\" UserName "\AppData\Roaming\PopUpMenu_PUM"
        if FileExist(ThisFile)
        {
          FileRemoveDir, %ThisFile%, 1
          BreakTime := A_TickCount + 2000
          while FileExist(ThisFile)
          {
            Sleep, 100
            if (A_TickCount > BreakTime)
            {
              break
            }
          }
        }
	      ; -------------------------------------------
	      ; REMOVE (pums)
	      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; REMOVE (Pictures)
        ; -------------------------------------------
			  ThisFile := OutDrive "\Users\" UserName "\Pictures\(_PopUpMenu_)"
			  if FileExist(ThisFile)
			  {
  				FileRemoveDir, %ThisFile%, 1
				  BreakTime := A_TickCount + 2000
				  while FileExist(ThisFile)
				  {
  					Sleep, 100
					  if (A_TickCount > BreakTime)
					  {
  						break
					  }
				  }
			  }
			  ; -------------------------------------------
			  ; REMOVE (Pictures)
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			} ; Loop Files, %FilePath%, D ; (Array_PumFolder) All User Pum Folder Array
		} ; if (KeepData == 0) ; Delete User Data
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; REMOVE (Startmenu)
		; -------------------------------------------
    ThisFile := OutDrive "\Users\" A_UserName "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\PopUpMenu"
    if FileExist(ThisFile)
    {
      FileRemoveDir, %ThisFile%, 1
      BreakTime := A_TickCount + 2000
      while FileExist(ThisFile)
      {
        Sleep, 100
        if (A_TickCount > BreakTime)
        {
          break
        }
      }
    }
    ; -------------------------------------------
		; REMOVE (Startmenu)
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; REMOVE (Desktop)
    ; -------------------------------------------
    ThisFile := OutDrive "\Users\" A_UserName "\Desktop\PopUpMenu.lnk"
    if FileExist(ThisFile)
    {
      Filedelete, %ThisFile%
      BreakTime := A_TickCount + 2000
      while FileExist(ThisFile)
      {
        Sleep, 100
        if (A_TickCount > BreakTime)
        {
          break
        }
      }
    }
    ; -------------------------------------------
	  ; REMOVE (Desktop)
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    FileRemoveDir, %TempPath%, 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  }
  return
  ; -------------------------------------------
  LABEL_ButtonCancel:
  {
    ExitApp
  }
  return
  ; -------------------------------------------
} ; [End] else if (A_IsAdmin == 1)
else ; User Does NOT have AdMin Rights
{
  ; -------------------------------------------
  Gui, Margin , 0, 0
  ; -------------------------------------------
  Gui, Add, Picture, x0   y0   w460 h354 vGUI_BackgroundImage,                           %ImagePath%\NoAdmin_%UserLang%.png
  ; -------------------------------------------
  Gui, Color, %ColorTrans%
  ; -------------------------------------------
  Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
  Winset, TransColor, %ColorTrans%,
  Gui, Show
  ; -------------------------------------------
  SetTimer, Label_AutoClose, 3000
  ; -------------------------------------------
  return
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Label_AutoClose:
  {
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return
  ; -------------------------------------------
}
; -------------------------------------------
; Display Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
