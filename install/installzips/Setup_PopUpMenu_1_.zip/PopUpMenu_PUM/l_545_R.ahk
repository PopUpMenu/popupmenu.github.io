﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_545_R: ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
{
  ; -------------------------------------------
  ; Rotate Main Icon Right
  ; -------------------------------------------
  ;
  ; (w80_x_80)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Rotate Main Icon Right)
  ; global n_545_R := 0 ; Start Frame Number
  ; global s_545_R := 1 ; Show
  ; SetTimer, l _ 5 4 5_R, 100 ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Rotate Main Icon Right)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Rotate Main Icon Right)
  ; global s_545_R := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Rotate Main Icon Right)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Image_ConvertToIco.ahk
  ; Image_ImgToIco.ahk
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 24
  ; -------------------------------------------
  if (s_545_R == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_545_R > Total_Images)
    {
      global n_545_R := 1
    }
    else
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_102, C:\Program Files\PopUpMenu_PUM\image\gui\(545)_%n_545%.png ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      Gui_ObjectSize("102", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_102 ; (102_1)(Obj_DisplayedIcon)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_545_R := n_545_R + 1
      ; -------------------------------------------
    }
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_545_R, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (545_1)(Display Icon (w80_x_80) Rotate Icon)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
