﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
;~ #NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (525)(01)(Splash Anamated: PopUpMenu Working)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Breaktime := A_TickCount + 10000 ; Max Display Time 10 Seconds > ExitApp
; -------------------------------------------
; This Splash Animation Ran In
; PopUpMenu_Start
; -------------------------------------------
ColorTrans := "000000" ; Black
; -------------------------------------------
; Anamation
; -------------------------------------------
;
; -------------------------------------------
ProcessImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
; -------------------------------------------
Gui, Add, Picture, vSplash_Animate, %ProcessImagePath%\(525)_1.png
; -------------------------------------------
Gui, Color, %ColorTrans%
Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, %ColorTrans%,
Gui, Show, , pumworking
SetTimer, Splash_Animate, 100
Return
; -------------------------------------------
Splash_Animate:
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SetTitleMatchMode, 1
  WinGet, pumworking_Id, ID , pumworking ahk_class AutoHotkeyGUI
  WinSet, AlwaysOnTop, On, ahk_id %pumworking_Id%
  ; -------------------------------------------
  if (A_TickCount > BreakTime)
  {
    SetTimer, Splash_Animate, Off
    ExitApp
  }
  ; -------------------------------------------
  if (Image_Num == "")
  {
    Image_Num := 1
  }
  ; -------------------------------------------
  if (Image_Num == 16)
  {
    Image_Num := 1
  }
  else
  {
    Image_Num := Image_Num + 1
  }
  ThisImage := ProcessImagePath "\(525)_" Image_Num ".png"
  GuiControl, , Splash_Animate, %ThisImage%
  ;~ GuiControl, MoveDraw, Splash_Animate
  ; -------------------------------------------  
} ; [End] Splash_Animate:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Insert::
{
  Reload
}
return
