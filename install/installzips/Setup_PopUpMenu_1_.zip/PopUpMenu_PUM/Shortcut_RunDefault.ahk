﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Shortcut_RunDefault.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ThisPumProcessPath := A_AppData "\PopUpMenu_PUM\pums\pumdefault\pum_pumdefault.exe"
ThisPumProcessExe  := "pum_pumdefault.exe"
; -------------------------------------------
Run,  %ThisPumProcessPath%,,, ThisPumProcessPriority
WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
; -------------------------------------------
ExitApp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
