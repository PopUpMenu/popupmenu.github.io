﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\XmlValidate.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_MoveShortcut(ThisPumXml, From_ShortcutPosX, From_ShortcutPosY, To_ShortcutPosX, To_ShortcutPosY) ; Pum_MoveShortcut(ThisPumXml, From_ShortcutPosX, From_ShortcutPosY, To_ShortcutPosX, To_ShortcutPosY) > Nothing
{
	; -------------------------------------------
	ThisPumProcessArray := Array_FromFile(ThisPumXml)
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; [CHECK] IF (PreShortcut) Exist
	; -------------------------------------------
	String_PreShortcut := "row=""" From_ShortcutPosY """ column=""" From_ShortcutPosX """"
	Exist_PreShortcut := 0 ; Set to 0 to check if Extising shortcut line exist
	; ------------------------------------------
	for Index, ThisLine in ThisPumProcessArray
	{
		if (InStr(ThisLine, String_PreShortcut) > 0) ; (PreShortcut) Exist
		{
			; -------------------------------------------
			Exist_PreShortcut := 1
			Number_PreShortcut := Index
			Line_PreShortcut := ThisLine
			; -------------------------------------------
			break
			; -------------------------------------------
		} ; (PreShortcut) Exist
	} ; for Index, ThisLine in ThisPumProcessArray
	; -------------------------------------------
	; [CREATE ARRAY] of (PreShortcut)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (PreShortcut) Exist
	; -------------------------------------------
	if (Exist_PreShortcut == 1) ; (PreShortcut) Exist
	{
		; -------------------------------------------
		String_NewShortcut := "row=""" To_ShortcutPosY """ column=""" To_ShortcutPosX """"
		Exist_NewShortcut := 0 ; Set to 0 to check if New shortcut line exist
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; [CHECK] if there is an existing Shortcut, in the place USER wants to Move To
		; -------------------------------------------
		for Index, ThisLine in ThisPumProcessArray
		{
			if (InStr(ThisLine, String_NewShortcut) > 0) ; There IS another shortcut already in this place to Move To
			{
				; -------------------------------------------
				Exist_NewShortcut := 1
				Number_NewShortcut := Index
				Line_NewShortcut := ThisLine
				; -------------------------------------------
			}
		}
		; -------------------------------------------
		; [CHECK] if there is an existing Shortcut, in the place USER wants to Move To
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; -------------------------------------------
		if (Exist_NewShortcut == 0) ; There was NO Other Shortcut in the place to Move To
		{
			; -------------------------------------------
			for Index, ThisLine in ThisPumProcessArray
			{
				; -------------------------------------------
				if (InStr(ThisLine, String_PreShortcut) > 0)
				{
					ThisLine := StrReplace(ThisLine, String_PreShortcut, String_NewShortcut)
				}
				;
				; -------------------------------------------
				if (StrLen(ThisLine) == 0)
				{
					ThisLine := "`r"
				}
				; -------------------------------------------
				NewPumProcessArray := Array_Add(NewPumProcessArray, ThisLine, ThisPos) ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
				; -------------------------------------------
			}
			; -------------------------------------------
		} ; if (Exist_NewShortcut == 0) ; There was NO Other Shortcut in the place to Move To
		else if (Exist_NewShortcut == 1) ; There IS another shortcut already in this place to Move To
		{
			; -------------------------------------------
			NewPumProcessArray := ""
			; -------------------------------------------
			for Index, ThisLine in ThisPumProcessArray
			{
				; -------------------------------------------
				if (Number_PreShortcut == Index)
				{
					ThisLine := Line_NewShortcut
				}
				; -------------------------------------------
				if (Number_NewShortcut == Index)
				{
					ThisLine := Line_PreShortcut
				}
				; -------------------------------------------
				;
				; -------------------------------------------
				if (StrLen(ThisLine) == 0)
				{
					ThisLine := "`r"
				}
				; -------------------------------------------
				NewPumProcessArray := Array_Add(NewPumProcessArray, ThisLine, ThisPos) ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
				; -------------------------------------------
			} ; for Index, ThisLine in ThisPumProcessArray
			; -------------------------------------------
		} ; else if (Exist_NewShortcut == 1) ; There IS another shortcut already in this place to Move To
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Write XML
		; -------------------------------------------
		XmlWrite(NewPumProcessArray, ThisPumXml) ; Array_PumXml, ThisPumXml > [0,1] 1 = Ok , 0 Xml Error
		; -------------------------------------------
		; Write XML
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	} ; if (Exist_PreShortcut == 1) ; (PreShortcut) Exist
	; -------------------------------------------
	; (PreShortcut) Exist
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [FUNCTION]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
