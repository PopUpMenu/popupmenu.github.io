﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Select_FileFolder.ahk
#Include C:\Program Files\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_251(DataArray) ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
{
  ; -------------------------------------------
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; (Image_PathFolderOrName) This Script just sets Paths
  ; -------------------------------------------
  ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderOfl", DataArray.365.2, DataArray.363.12]
  ArrayOut := Image_PathFolderOrName(ArrayIn)
  StartFolder := ArrayOut.1
  ; -------------------------------------------
  ; (Image_PathFolderOrName) This Script just sets Paths
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Selected_Array := Select_FileFolder(DataArray.365.2, "AnyImage", StartFolder, ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
  ThisFolderIcon := Selected_Array.1
  ; -------------------------------------------
  if FileExist(ThisFolderIcon)
  {
    ; -------------------------------------------
    DataArray := f_102(ThisFolderIcon, DataArray) ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  } ; [End] if FileExist(ThisFolderIcon)
  ; -------------------------------------------
  Send, {Home}
  ; -------------------------------------------
  GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
