﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
pum_ColorSelect(ColorGrid, DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Delete_1 := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png"
  Delete_2 := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png"
  Delete_3 := ThisPumProcessFolder "\image\Temp_Display_Img.png"
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Color_Array := Pum_ColorVarConvert("ColorGrid", ColorGrid, DataArray) ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
  VarNum    := Color_Array.1
  ColorGrid := Color_Array.2
  HexColor  := Color_Array.3
  HexMobileTextColor  := Color_Array.3
  HexMobileBgColor  := Color_Array.3
  MsColor   := Color_Array.4
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  This_VarNum := 190
  Loop 48
  {
    ; -------------------------------------------
    This_VarNum := This_VarNum + 1
    ; -------------------------------------------
    if (VarNum == This_VarNum)
    {
      ; -------------------------------------------
      GridImage := "C:\Program Files\PopUpMenu_PUM\image\pum\ColorGrid_" ColorGrid "_2.png"
      ; -------------------------------------------
      DataArray[VarNum][2] := 2
      DataArray[VarNum][3] := GridImage
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_%VarNum%, %GridImage% ; (182_1)(GUI Object: [pum] Transparency [Image] Color)
      GuiControl, PopUpMenu:Show, g_%VarNum%
    } ; End (VarNum == This_VarNum)
    else ; (VarNum != This_VarNum)
    {
      ; -------------------------------------------
      Color_Array := Pum_ColorVarConvert("VarNum", This_VarNum, DataArray) ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
      This_VarNum    := Color_Array.1
      This_ColorGrid := Color_Array.2
      ; -------------------------------------------
      This_GridImage := "C:\Program Files\PopUpMenu_PUM\image\pum\ColorGrid_" This_ColorGrid "_1.png"
      ; -------------------------------------------
      DataArray[This_VarNum][2] := 1
      Check_This_GridImage := DataArray[This_VarNum][3]
      if (Check_This_GridImage != This_GridImage)
      {
        DataArray[This_VarNum][3] := This_GridImage
        GuiControl, PopUpMenu:, g_%This_VarNum%, %This_GridImage% ; (182_1)(GUI Object: [pum] Transparency [Image] Color)
        GuiControl, PopUpMenu:Show, g_%This_VarNum%
      }
      ; -------------------------------------------
    } ; End (VarNum != This_VarNum)
  } ; End Loop 48
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(DataArray.366.5, "pumMobileTextColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    Mobile_TextColor_HexColor := DataArray.362.25 ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    ; -------------------------------------------
    if (Mobile_TextColor_HexColor != HexColor)
    {
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileDelete, %Delete_1%
      FileDelete, %Delete_2%
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
      {
        DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
      DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
      DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
    DataArray.362.25 := HexMobileTextColor ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    ; -------------------------------------------
  } ; End "pumMobileTextColor")
  else if (InStr(DataArray.366.5, "pumMobileBgColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    Mobile_BgColor_HexColor := DataArray.362.26 ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
    if (Mobile_BgColor_HexColor != HexColor)
    {
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileDelete, %Delete_1%
      FileDelete, %Delete_2%
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
      {
        DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
      DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
      DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
    DataArray.362.26 := HexMobileBgColor ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
  } ; End "pumMobileBgColor"
  else if (InStr(DataArray.366.5, "pumBgColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
    ; -------------------------------------------
    if (XmlBgColor != MsColor)
    {
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileDelete, %Delete_1%
      FileDelete, %Delete_2%
      FileDelete, %Delete_3%
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
      {
        DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
      DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
      DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
      DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
    DataArray.362.27 := MsColor ; (362_27)(XmlBgColor [Background color])
    ; -------------------------------------------
    XmlBgColor := MsColor
    BgColor_Opicity     := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
    ; -------------------------------------------
    Color_Array         := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
    Pum_BgColor_GridNum := Color_Array.2
    ; -------------------------------------------
    if (BgColor_Opicity == 0)
    {
      DataArray := Image_GuiControl("181", "Zero", 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
    }
    else
    {
      Opicity_GridNum  := BgColor_Opicity "_" Pum_BgColor_GridNum
      DataArray := Image_GuiControl("181", Opicity_GridNum, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
    }
    ; -------------------------------------------
  } ; End "pumBgColor"
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End pum_ColorSelect(ColorGrid, DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
