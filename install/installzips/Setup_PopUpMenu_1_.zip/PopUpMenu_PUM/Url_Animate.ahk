﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_Animate(StartStopUrlAnimate)
{
  ; -------------------------------------------
  Loop ; Infinate Loop
  {
    ; -------------------------------------------
    if (ImageNum == "")
    {
      ImageNum := 1
    }
    else
    {
      ImageNum := ImageNum + 1
    }
    ; -------------------------------------------
    if (StartStopUrlAnimate == 1)
    {
      GuiControl, PopUpMenu:, g_137, C:\Program Files\PopUpMenu_PUM\image\gui\(520)_%ImageNum%.png ; (137_1)(Obj_MsgImg480x270)
      Sleep, 100
    }
    else
    {
      break
    }
  } ; [End] Loop ; Infinate Loop
  ; -------------------------------------------
} ; [End] Url_Animate()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
