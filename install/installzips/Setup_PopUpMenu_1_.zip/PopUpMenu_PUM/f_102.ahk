﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ImgToIco.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\l_545_R.ahk ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
#Include C:\Program Files\PopUpMenu_PUM\Img_RunIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RwhIco.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_102(ThisIcon, DataArray) ; (102_1)(Obj_DisplayedIcon)
{
  ; -------------------------------------------
  global LockKeys := 1
  ; -------------------------------------------
  ; Will Hide (102_1)(Obj_DisplayedIcon)
  ; (ScriptType [pum,xxx,run_rwh_url_ofl,mnu_cpl_key])
  ; -------------------------------------------
  PopUpMenuIcon := 0
  TempIcon := ""
  ; -------------------------------------------
  ;
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  CurrentIcon := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
  SplitPath,  CurrentIcon, CurrentIcon_NameExt, CurrentIcon_Folder, CurrentIcon_Ext, CurrentIcon_Name
  StringLower, CurrentIcon_Ext, CurrentIcon_Ext
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ThisIcon, ThisIcon_NameExt, ThisIcon_Folder, ThisIcon_Ext, ThisIcon_Name
  StringLower, ThisIcon_Ext, ThisIcon_Ext
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; User Folder Theme
  ; -------------------------------------------
  if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    FolderThemes := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"
    if (InStr(ThisIcon, FolderThemes) > 0)
    {
      ; -------------------------------------------
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, ThisIcon, , Folder_UserTheme
      Icon_UserTheme := Folder_UserTheme "\(1).ico"
      ; -------------------------------------------
      File_UserTheme := A_AppData "\PopUpMenu_PUM\system\File_UserTheme.txt"
      if FileExist(File_UserTheme)
      {
        FileDelete, %File_UserTheme%
        Sleep, 100
      } ; [End] if FileExist(File_UserTheme)
      ; -------------------------------------------
      FileEncoding, UTF-8
      FileAppend, %Icon_UserTheme%, %File_UserTheme% ; UTF-8
      ; -------------------------------------------
    } ; [End] if (InStr(ThisIcon, FolderThemes)
    ; -------------------------------------------
  } ; [End] (ScriptType [ofl])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [IF] (ThisIcon =! "Default" or ThisIcon == "ScriptError")
  ; ThisIcon := "Default", CurrentIcon := ""
  if !FileExist(ThisIcon)
  {
    if (ThisIcon != "ScriptError")
    {
      ThisIcon := "Default"
    } ; [End] if (ThisIcon != "ScriptError")
  } ; [End] if !FileExist(ThisIcon)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(DataArray.366.5, "pum") == 1 or DataArray.366.5 == "xxx" or DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "mnu_cpl_key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    DataArray.102.2  := 0 ; (102_2)(Obj_DisplayedIcon_Sel [0,1,2,3])
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  else
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [IF] (ThisIcon == "Default") or (ThisIcon == "ScriptError")
    ; [SET] ThisIcon, CurrentIcon := ""
    ; -------------------------------------------
    if (ThisIcon == "Default")
    {
      ; -------------------------------------------
      CurrentIcon := ""
      ; -------------------------------------------
      if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ThisIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\key.ico"
        ; -------------------------------------------
      } ; [End] (ScriptType [key)
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ThisIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\ofl.ico"
        ; -------------------------------------------
      } ; [End] (ScriptType [ofl)
      else if (DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          run_OutTarget := DataArray.305.11 ; (305_11)(run_OutTarget [PathExtName])
          ; -------------------------------------------
          ArrayIn := [DataArray.305.11, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          ThisIcon := Img_RunIco(ArrayIn)
          ; -------------------------------------------
        } ; [End] (ScriptType [run])
        else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          run_OutTarget := DataArray.305.5 ; (305_5)(Rwh_OpeningApp [Full File Path])
          ; -------------------------------------------
          ArrayIn := [DataArray.305.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          FileRwhIco := Img_RwhIco(ArrayIn)
          PopUpMenuIcon := FileRwhIco
          ; -------------------------------------------
        } ; [End] (ScriptType [rwh])
        ; -------------------------------------------
        ;
        ; -------------------------------------------
      } ; [End] (ScriptType [run,rwh)
      ; -------------------------------------------
      else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        Url_Browser := Default_Browser()
        ; -------------------------------------------
        ArrayIn  := [Url_Browser, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        ThisIcon := Img_RunIco(ArrayIn)
        ; -------------------------------------------
      } ; [End] (ScriptType [url])
      else
      {
        ; -------------------------------------------
        ThisIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\PopUpMenu.ico"
        PopUpMenuIcon := A_AppData "\PopUpMenu_PUM\temp\PopUpMenu.ico"
        ; -------------------------------------------
      } ; [End] else
      ; -------------------------------------------
    } ; [End] if (ThisIcon == "Default" or ThisIconExist == 0)
    else if (ThisIcon == "ScriptError")
    {
      ; -------------------------------------------
      CurrentIcon := ""
      ; -------------------------------------------
      ThisIcon := "C:\Program Files\PopUpMenu_PUM\image\ico\PopUpMenu_Error.ico"
      PopUpMenuIcon := A_AppData "\PopUpMenu_PUM\temp\PopUpMenu_Error.ico"
      ; -------------------------------------------
    } ; [End] else if (ThisIcon == "ScriptError")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;  [SET] TempIcon
    ; -------------------------------------------
    if (PopUpMenuIcon == 0)
    {
      ; -------------------------------------------
      FormatTime, TimeRightNow , , yyyyMMddHHmmss
      ThisYear := SubStr(TimeRightNow, 1, 4)
      ThisMonth := SubStr(TimeRightNow, 5, 2)
      ThisDay := SubStr(TimeRightNow, 7, 2)
      ThisHour := SubStr(TimeRightNow, 9, 2)
      ThisMinute := SubStr(TimeRightNow, 11, 2)
      ThisSecond := SubStr(TimeRightNow, 13, 2)
      TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond A_TickCount
      ; -------------------------------------------
      TempIcon := A_AppData "\PopUpMenu_PUM\temp\" TimeRightNow ".ico" ; (386_2)(Temporary Icon [System Folder Path])
      ; -------------------------------------------
      if (ThisIcon_Ext == "exe")
      {
        ; -------------------------------------------
        ArrayIn  := [run_OutTarget, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        ThisIcon := Img_RunIco(ArrayIn)
        ; -------------------------------------------
        FileCopy, %ThisIcon%, %TempIcon%, 1
        Sleep, 10
        ; -------------------------------------------
      } ; [End] if (ThisIcon_Ext == "exe")
      ; -------------------------------------------
      else if (ThisIcon_Ext != "ico")
      {
        ; -------------------------------------------
        TempIcon := Image_ImgToIco(ThisIcon, TempIcon) ; (ImageIn, ImageOut) > ImageOut
        ; -------------------------------------------
      } ; [End] if (ThisIcon_Ext == "exe")
      ; -------------------------------------------
      else
      {
        FileCopy, %ThisIcon%, %TempIcon%, 1
        Sleep, 10
      }
      ; -------------------------------------------
    } ; [End] if (PopUpMenuIcon == 0)
    else ; Display (PopUpMenu.ico) or (PopUpMenu_Error.ico)
    {
      ; -------------------------------------------
      TempIcon := PopUpMenuIcon
      if (ThisIcon != TempIcon)
      {
        FileCopy, %ThisIcon%, %TempIcon%, 1
        Sleep, 10
      }
      ; -------------------------------------------
    } ; [End] (PopUpMenu.ico) or (PopUpMenu_Error.ico)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray.102.3 := TempIcon ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_102, %TempIcon% ; (102_1)(Obj_DisplayedIcon)
    ; (102_1)(Obj_DisplayedIcon)
    GuiControl, PopUpMenu:Show, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    DataArray.102.2  := 1 ; (102_2)(Obj_DisplayedIcon_Sel [0,1,2,3])
    GuiControl, PopUpMenu:Show, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  } ; [End] (ScriptType) NOT [pum])
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
